#include "stdafx.h"

#include "sceneobj.h"
#include "Photonix.h"
#include "PhotonixDoc.h"
SceneObj::~SceneObj()
{
	int count=m_SceneObjects.GetSize ();
	for(int i=0;i<count;i++)
	{
		ISceneObject* pObject=(ISceneObject *)m_SceneObjects[i];
		delete (SceneObjectData*)m_MapSceneObjects[pObject->pRenderable->Name];
		DeleteRenderable (pObject->pRenderable );
		delete pObject;
	}
count=m_SceneCameras.GetSize ();
	for(i=0;i<count;i++)
	{
		ISceneObject* pObject=(ISceneObject *)m_SceneCameras[i];
		delete (SceneObjectData*)m_MapSceneObjects[pObject->pRenderable->Name];
		DeleteRenderable (pObject->pRenderable );
		delete pObject;

	}
	m_SceneCameras .RemoveAll ();
	m_SceneObjects.RemoveAll ();
	m_MapSceneObjects.RemoveAll ();
}
void SceneObj::GenerateScene()
{
	//int count =m_AllObjects.GetSize ();
	
	int count =m_SceneObjects.GetSize ();
	for(int i=0;i<count;i++)
	{
	//	IRenderable * o=(IRenderable*)m_AllObjects[i];
	//	ISceneObject *pObject=(ISceneObject *)o->pReserved ;
		ISceneObject *pObject=(ISceneObject *)m_SceneObjects[i];
		pObject->UpdateObject();
		OBJECT * obj=pObject->Generate();
		Post_Process (obj, NULL);//used next object
		Link_To_Frame (obj);
	}
}
SceneObjectData* SceneObj::AddSceneObject(ISceneObject * pObject)
{
	SceneObjectData* data=0;
	if(pObject->ObjectType ==OBJ_CAMERA)
	{
		int index=m_SceneCameras.Add (pObject);
		data=new SceneObjectData(0,pObject);
		m_MapSceneObjects[pObject->pRenderable->Name]=data;
	}
	else
	{
		int index=m_SceneObjects.Add (pObject);
		data=new SceneObjectData(0,pObject);
		m_MapSceneObjects[pObject->pRenderable->Name]=data;
	}
	return data;
}
void SceneObj::DeleteSceneObject(ISceneObject * pObject)
{
	//DeleteSceneObject(pObject->pRenderable ->Name );
	int count=m_SceneObjects.GetSize ();
	for(int i=0;i<count;i++)
	{
		ISceneObject * m_Object=(ISceneObject *)m_SceneObjects[i];
		if(m_Object==pObject)
		{
			delete (SceneObjectData*)m_MapSceneObjects[pObject->pRenderable ->Name];
			m_MapSceneObjects.RemoveKey (pObject->pRenderable ->Name);
			if(pObject->ObjectType ==OBJ_CAMERA)
			{
				m_SceneCameras.RemoveAt (i);
			}
			else
			{
				m_SceneObjects.RemoveAt (i);
			}

			delete m_Object;
			break;
		}
	}
}
void SceneObj::DeleteSceneObject(CString ObjectName)
{

	int count=m_SceneObjects.GetSize ();
	for(int i=0;i<count;i++)
	{
		ISceneObject * m_Object=(ISceneObject *)m_SceneObjects[i];
		if(m_Object->pRenderable ->Name==ObjectName)
		{
			delete (SceneObjectData*)m_MapSceneObjects[m_Object->pRenderable ->Name];
			m_MapSceneObjects.RemoveKey (ObjectName);
			if(m_Object->ObjectType ==OBJ_CAMERA)
			{
				m_SceneCameras.RemoveAt (i);
			}
			else
			{
				m_SceneObjects.RemoveAt (i);
			}
			delete m_Object;
			break;
		}
	}
}
int SceneObj::GetCameraCount()
{
return m_SceneCameras.GetSize ();
}
int  SceneObj::GetObjectsCount()
{
return m_SceneObjects.GetSize ();
}
int SceneObj::GetLightCount()
{
	int num=0;
	int count=m_SceneObjects.GetSize ();
	for(int i=0;i<count;i++)
	{
		if(((ISceneObject *)m_SceneObjects[i])->ObjectType >=OBJ_LIGHT)
		{
			num++;
		}
		
	}
return num;
}