#if !defined(AFX_LIGHTPHOTONS_H__3C1DD9A4_82CF_4749_854F_075CB1D511D0__INCLUDED_)
#define AFX_LIGHTPHOTONS_H__3C1DD9A4_82CF_4749_854F_075CB1D511D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LightPhotons.h : header file
//
#include "AccessDialog.h"
#include "enggenclasses.h"

/////////////////////////////////////////////////////////////////////////////
// CLightPhotons dialog

class CLightPhotons : public CAccessDialog//CDialog
{
// Construction
public:
	CLightPhotons(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLightPhotons)
	enum { IDD = IDD_LIGHT_PHOTONS };
	BOOL	m_reflection;
	BOOL	m_refraction;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLightPhotons)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLightPhotons)
afx_msg void OnReflection();
afx_msg void OnRefraction();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LIGHTPHOTONS_H__3C1DD9A4_82CF_4749_854F_075CB1D511D0__INCLUDED_)
