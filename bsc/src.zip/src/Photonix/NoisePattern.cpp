// NoisePattern.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "NoisePattern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNoisePattern dialog
IMPLEMENT_SERIAL(CNoisePattern,CAccessDialog,1)

CNoisePattern::CNoisePattern(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CNoisePattern::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNoisePattern)
	m_bump_depth = 0.0f;
	m_agate_turb = 0.0f;
	m_gx = FALSE;
	m_gy = FALSE;
	m_gz = FALSE;
	m_mandel_iter = 50;
	m_arms = 1;
	m_c0 = 0.0f;
	m_c1 = 0.0f;
	m_sel_pat = 6;
	//}}AFX_DATA_INIT
}


void CNoisePattern::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNoisePattern)
	DDX_Text(pDX, IDC_BUMP_DEPTH, m_bump_depth);
	DDX_Text(pDX, IDC_AGATE_TURB, m_agate_turb);
	DDV_MinMaxFloat(pDX, m_agate_turb, 0.f, 10.f);
	DDX_Check(pDX, IDC_GRADIENT_X, m_gx);
	DDX_Check(pDX, IDC_GRADIENT_Y, m_gy);
	DDX_Check(pDX, IDC_GRADIENT_Z, m_gz);
	DDX_Text(pDX, IDC_MANDEL_ITER, m_mandel_iter);
	DDV_MinMaxInt(pDX, m_mandel_iter, 1, 200);
	DDX_Text(pDX, IDC_NUM_ARMS, m_arms);
	DDV_MinMaxInt(pDX, m_arms, 1, 50);
	DDX_Text(pDX, IDC_QUILTED_C0, m_c0);
	DDV_MinMaxFloat(pDX, m_c0, 0.f, 2.f);
	DDX_Text(pDX, IDC_QUILTED_C1, m_c1);
	DDV_MinMaxFloat(pDX, m_c1, 0.f, 2.f);
	DDX_CBIndex(pDX, IDC_PAT_TYPE, m_sel_pat);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNoisePattern, CDialog)
	//{{AFX_MSG_MAP(CNoisePattern)
	ON_CBN_SELCHANGE(IDC_PAT_TYPE, OnSelchangePatType)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNoisePattern message handlers

void CNoisePattern::OnSelchangePatType() 
{
	// TODO: Add your control notification handler code here
this->UpdateData ();
	//	sel_pat_type=((CComboBox*)this->GetDlgItem (IDC_PAT_TYPE))->GetCurSel();
	SetupWindows();	
}
void CNoisePattern::Serialize(CArchive &ar)
{
	if(ar.IsStoring ())
	{
		ar<<m_sel_pat<<	m_bump_depth<<m_agate_turb<<	m_gx<<	m_gy<<	m_gz<<	m_mandel_iter<<	m_arms<<	m_c0<<m_c1;
	}
	else
	{
		ar>>m_sel_pat>>	m_bump_depth>>m_agate_turb>>	m_gx>>	m_gy>>	m_gz>>	m_mandel_iter>>	m_arms>>	m_c0>>m_c1;	
	}
}

BOOL CNoisePattern::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CComboBox * combo=((CComboBox*)this->GetDlgItem (IDC_PAT_TYPE));
combo->AddString ("agate");
combo->AddString ("bozo");
combo->AddString ("crackle");
combo->AddString ("gradient");
combo->AddString ("granite");
combo->AddString ("leopord");
combo->AddString ("mandel");
combo->AddString ("marble");
combo->AddString ("onion");
combo->AddString ("radial");
combo->AddString ("spiral1");
combo->AddString ("spiral2");
combo->AddString ("spotted");
combo->AddString ("wood");
combo->AddString ("bump");
combo->AddString ("ripple");
combo->AddString ("dents");
combo->AddString ("waves");
combo->AddString ("wrinkles");
combo->AddString ("quilted");
combo->AddString ("boxed");
combo->AddString ("cylindrical");
combo->AddString ("planar");
combo->AddString ("spherical");

this->UpdateData (false);
SetupWindows();	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CNoisePattern::SetupWindows()
{

}
