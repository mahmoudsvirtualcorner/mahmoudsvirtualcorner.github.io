// PhotonixView.h : interface of the CPhotonixView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PHOTONIXVIEW_H__0A596A1B_F10C_41FE_A47F_610A58D6244B__INCLUDED_)
#define AFX_PHOTONIXVIEW_H__0A596A1B_F10C_41FE_A47F_610A58D6244B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "myapplication.h"
#include "RenderWnd.h"

class CPhotonixView : public CView
{
protected: // create from serialization only
	CPhotonixView();
	DECLARE_DYNCREATE(CPhotonixView)

// Attributes
public:
	CPhotonixDoc* GetDocument();
	void Free();
CRenderWnd *RenderWnd;
RenderWindow *win;
static int ViewPortCounter;
//CString s;
CString InitCameraName;
SceneDetailLevel  mInitialSceneDetail;
// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPhotonixView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPhotonixView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPhotonixView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual void OnInitialUpdate();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
protected:
	virtual void OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/);
public:
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
};

#ifndef _DEBUG  // debug version in PhotonixView.cpp
inline CPhotonixDoc* CPhotonixView::GetDocument()
   { return (CPhotonixDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PHOTONIXVIEW_H__0A596A1B_F10C_41FE_A47F_610A58D6244B__INCLUDED_)
