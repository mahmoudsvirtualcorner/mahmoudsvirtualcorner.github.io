// PictureDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "PictureDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPictureDialog dialog


CPictureDialog::CPictureDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CPictureDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPictureDialog)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CPictureDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPictureDialog)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPictureDialog, CDialog)
	//{{AFX_MSG_MAP(CPictureDialog)
	ON_WM_SIZE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_WM_ERASEBKGND()
	ON_WM_SIZING()
	ON_WM_WINDOWPOSCHANGING()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPictureDialog message handlers

BOOL CPictureDialog::OnInitDialog() 
{
	CDialog::OnInitDialog();
	maxreached=false;
	CRect r;
	GetClientRect (r);	
	CRect r1=m_Window.GetPictureRect ();
	m_Window.Create (this,r1,10,WS_CHILD|WS_VISIBLE);
	 
	int Width= r1.Width()<r.Width ()?r1.Width():r.Width();
	int Height= r1.Height()<r.Height ()?r1.Height():r.Height();
		
	CRect rect;
	//	this->GetWindowRect (&rect);
	//this->SetWindowPos (0,rect.left ,rect.top,Width,Height,SWP_NOMOVE   );
	GetClientRect (&rect);
	this->SetWindowPos (0,0 ,0,rect.Width (),rect.Width (),SWP_NOMOVE   );
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPictureDialog::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	if(IsWindow (m_Window))
	{

		CRect r;
		GetClientRect (r);
			m_Window .SetWindowPos (NULL,0,0 ,r.Width (),r.Height () ,  SWP_NOZORDER );//| SWP_NOREDRAW  |SWP_NOCOPYBITS      
//	CRect r2=m_Window .GetPictureRect ();
	//	int neww,newh;
	//	if(r2.Width ()<r.Width ()+cx)
	//	{neww= r1}
	//	BITMAP bit;
	//	m_Window.m_ScrBitmap.GetBitmap(&bit);
	//	neww=bit.bmWidth<r.Width ()?bit.bmWidth:r.Width ();
	//	newh=bit.bmHeight<r.Height()?bit.bmHeight:r.Height ();

	//	m_Window .SetWindowPos (NULL,0,0,neww,newh ,SWP_NOMOVE   );
	
		
		//	m_Window.SendMessage (WM_SIZE,0,0);
	//	ClipCursor(NULL);
	//	maxreached=0;

	}
}

void CPictureDialog::OnDestroy() 
{
	CDialog::OnDestroy();
	
	//m_Window .DestroyWindow ();	
}

BOOL CPictureDialog::OnEraseBkgnd(CDC* pDC)
{
	// TODO: Add your message handler code here and/or call default
return true;
//	return CDialog::OnEraseBkgnd(pDC);
}

void CPictureDialog::OnSizing(UINT fwSide, LPRECT pRect)
{
			CDialog::OnSizing(fwSide, pRect);
	
/*	CRect r;
		GetClientRect (r);
	//	CRect r2=m_Window .GetPictureRect ();
		int neww,newh;
	BITMAP bit;
		m_Window.m_ScrBitmap.GetBitmap(&bit);
		neww=bit.bmWidth<r.Width ()?bit.bmWidth:r.Width ();
		newh=bit.bmHeight<r.Height()?bit.bmHeight:r.Height ();

		if( (r.Width ()>neww || r.Height()>newh))
		{
			
		//	SetWindowPos (NULL, 0,0 ,neww,newh ,SWP_NOMOVE   );
			maxreached=true;
		CRect rect;
			this->GetWindowRect (&rect);
			rect=CRect(CPoint(rect.left ,rect.top) ,CSize());
			this->ClientToScreen (&rect);
			ClipCursor(rect);
		}	
		else
		{
		//	maxreached=0;
		}

	*/
	
		/*
			//the idea of clip cursor
			if(!maxreached)
			{
				CRect rect;
				this->GetClientRect (&rect);
				this->ClientToScreen (&rect);
				CRect picrect =m_Window .GetPictureRect ();
				if(fwSide==WMSZ_TOPLEFT ||fwSide==WMSZ_TOP ||fwSide==WMSZ_LEFT )
				{
				rect=CRect(CPoint(rect.right -picrect.Width () ,rect.bottom -picrect.Height ()) ,CSize(picrect.Width (),picrect.Height ()));

				}
				if(fwSide== WMSZ_TOPRIGHT || fwSide==WMSZ_RIGHT)
				{
					rect=CRect(CPoint(rect.left ,rect.bottom -picrect.Height ()) ,CSize(picrect.Width (),picrect.Height ()));
				}
				if(fwSide==WMSZ_BOTTOMLEFT ||fwSide==WMSZ_BOTTOM ) 
				{
				rect=CRect(CPoint(rect.right-picrect.Width (),rect.top) ,CSize(picrect.Width (),picrect.Height ()));
				}
				if(fwSide==WMSZ_BOTTOMRIGHT)
				{
				rect=CRect(CPoint(rect.left ,rect.top) ,CSize(picrect.Width (),picrect.Height ()));
				}
				
//picrect.right += GetSystemMetrics(SM_CXVSCROLL) + GetSystemMetrics(SM_CXBORDER);
//picrect.bottom += GetSystemMetrics(SM_CYHSCROLL) + GetSystemMetrics(SM_CYBORDER);
				ClipCursor(rect);
				maxreached=true;
			}
			*/

}
	

void CPictureDialog::OnWindowPosChanging(WINDOWPOS* lpwndpos)
{
	CDialog::OnWindowPosChanging(lpwndpos);
	//lpwndpos->
/*	if(lpwndpos->cy >this->m_Window .m_PictureRect .Height() && lpwndpos->cx >this->m_Window .m_PictureRect .Width ())
	{
		lpwndpos->flags &=~SWP_NOSIZE;
	}
	else*/
	{
CRect r;
GetClientRect(&r);
		if((lpwndpos->cx+GetSystemMetrics(SM_CXBORDER)) >this->m_Window .m_PictureRect .Width ())
		{
			lpwndpos->cx =this->m_Window .m_PictureRect .Width ();
		}
		if((lpwndpos->cy+GetSystemMetrics(SM_CYBORDER)) >this->m_Window .m_PictureRect .Height())
		{
			lpwndpos->cy =this->m_Window .m_PictureRect .Height();
		}
	
	}
}
