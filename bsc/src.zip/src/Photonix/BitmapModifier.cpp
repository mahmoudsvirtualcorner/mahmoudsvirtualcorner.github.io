// BitmapModifier.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "BitmapModifier.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBitmapModifier dialog
IMPLEMENT_SERIAL(CBitmapModifier,CAccessDialog,1)


CBitmapModifier::CBitmapModifier(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CBitmapModifier::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBitmapModifier)
	m_filename = _T("");
	m_maptype = 0;
	m_interpolation = 0;
	m_once = FALSE;
	m_useindex = FALSE;
	//}}AFX_DATA_INIT
}


void CBitmapModifier::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBitmapModifier)
	DDX_Text(pDX, IDC_FILENAME, m_filename);
	DDX_CBIndex(pDX, IDC_MAPTYPE, m_maptype);
	DDX_CBIndex(pDX, IDC_INTERPOLATION, m_interpolation);
	DDX_Check(pDX, IDC_ONCE, m_once);
	DDX_Check(pDX, IDC_USE_INDEX, m_useindex);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBitmapModifier, CDialog)
	//{{AFX_MSG_MAP(CBitmapModifier)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBitmapModifier message handlers

void CBitmapModifier::OnBrowse() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(true,"bitmap|*.bmp");
	dlg.DoModal ();
	m_filename=dlg.m_ofn .lpstrFile;
	this->UpdateData (false);
}
void CBitmapModifier::Serialize(CArchive &ar)
{
	if(ar.IsStoring ())
	{
		ar<<m_filename<<m_maptype<<m_interpolation<<m_once<<m_useindex;
	}
	else
	{
		ar>>m_filename>>m_maptype>>m_interpolation>>m_once>>m_useindex;
	}
}


BOOL CBitmapModifier::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CComboBox * m=((CComboBox*)this->GetDlgItem (IDC_MAPTYPE));
	m->AddString ("planer");
	m->AddString ("spherical");
	m->AddString ("cylindrical");
	m->AddString ("toroidal");
	m->AddString ("parametric");

	CComboBox * m1=((CComboBox*)this->GetDlgItem (IDC_INTERPOLATION));
	m1->AddString ("none");
	m1->AddString ("bilinear");
	m1->AddString ("normalized distance");

	this->UpdateData (false);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

