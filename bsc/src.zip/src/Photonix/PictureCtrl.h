

#ifndef _PICTURECTRL_H__INCLUDED_
#define _PICTURECTRL_H__INCLUDED_


// scrollbar selection
#define FCSB_NONE				0L
#define FCSB_HORZ				1L
#define FCSB_VERT				2L
#define FCSB_BOTH				3L


/////////////////////////////////////////////////////////////////////////////
// CPictureCtrl window

class CPictureCtrl : public CWnd
{
    DECLARE_DYNCREATE(CPictureCtrl)
public:
//	CBitmap  m_ScrBitmap;      // Offscreen bitmap
	CBitmap m_BitmapSaved;
	Bitmap *m_ScrBitmap;

// Construction
public:
	CPictureCtrl();
	virtual ~CPictureCtrl();
	

// Attributes
public:

	// some scrolling attributes
    int	m_BarState;
    int m_VScrollMax;
	int m_HScrollMax;
	int m_RowsPerWheelNotch;
	CRect m_PictureRect;
	BOOL m_Redraw;
// Operations
public:
	BOOL Create(CWnd* pParentWnd, const RECT& rect, UINT nID, DWORD dwStyle = WS_VISIBLE);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPictureCtrl)
	public:
	protected:
	//}}AFX_VIRTUAL
	
public:
// Implementation
	CRect GetPictureRect();
	void CPictureCtrl::SetPictureRect(CRect rect);
	void EnableScrollBars(int nBar, BOOL bEnable /*=TRUE*/);
	void ResetScrollBars();
	int  GetScrollPos(int nBar, BOOL bGetTrackPos = FALSE);
    BOOL SetScrollPos(int nBar, int nPos, BOOL bRedraw = TRUE);
    BOOL IsVisibleVScroll() { return ( (m_BarState & FCSB_VERT) > 0); } 
    BOOL IsVisibleHScroll() { return ( (m_BarState & FCSB_HORZ) > 0); }
	
///////////////////////////////////////////////////////////////////////////////////
// Clipboard, drag and drop, and cut n' paste operations
///////////////////////////////////////////////////////////////////////////////////
protected:
    BOOL RegisterWindowClass();
	LRESULT SendMessageToParent(int nMessage) const;
  
	// Drawing 
    virtual void  OnDraw(CDC* pDC);
	
	// Transformation of coordinates (supports scrolling)

	// Generated message map functions
public:
	//{{AFX_MSG(CPictureCtrl)
	afx_msg void OnPaint();
    afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
    afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnSize(UINT nType, int nCx, int nCy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	CDC MemDC;
//	bool first;
   void Plot_Pixel(int x, int y, int r, int g, int b, int a);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnDestroy();
	void ReconstructBitmap(void);
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif
