// SlopeMapEntry.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "SlopeMapEntry.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSlopeMapEntry dialog


CSlopeMapEntry::CSlopeMapEntry(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CSlopeMapEntry::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSlopeMapEntry)
	m_height = 0.0f;
	m_number = 0.0f;
	m_slope = 0.0f;
	//}}AFX_DATA_INIT
}


void CSlopeMapEntry::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSlopeMapEntry)
	DDX_Text(pDX, IDC_HEIGHT, m_height);
	DDX_Text(pDX, IDC_NUMBER, m_number);
	DDV_MinMaxFloat(pDX, m_number, 0.f, 1.f);
	DDX_Text(pDX, IDC_SLOPE, m_slope);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSlopeMapEntry, CDialog)
	//{{AFX_MSG_MAP(CSlopeMapEntry)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSlopeMapEntry message handlers
