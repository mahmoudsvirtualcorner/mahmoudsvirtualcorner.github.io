// RenderProgress.cpp : implementation file
//

#include "stdafx.h"
#include "photonix.h"
#include "RenderProgress.h"
#include "photonixdoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRenderProgress dialog


CRenderProgress::CRenderProgress(CWnd* pParent /*=NULL*/)
	: CDialog(CRenderProgress::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRenderProgress)
	m_antialiasing = _T("");
	m_elapsedtime = _T("");
	m_height = _T("");
	m_numlights = _T("");
	m_numobjects = _T("");
	m_remainingtime = _T("");
	m_useparticipatingmedia = _T("");
	m_usephoton = _T("");
	m_viewport = _T("");
	m_width = _T("");
	//}}AFX_DATA_INIT
	pDoc=NULL;
}


void CRenderProgress::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRenderProgress)
	DDX_Control(pDX, IDC_PAUSE, m_pause);
	DDX_Control(pDX, IDC_TASKPROGRESS, m_progress);
	DDX_Control(pDX, IDC_CURRENTTASK, m_curtask);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRenderProgress, CDialog)
	//{{AFX_MSG_MAP(CRenderProgress)
	ON_BN_CLICKED(IDC_PAUSE, OnPause)
	//}}AFX_MSG_MAP
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_ENDDIALOG, OnClose)
	ON_MESSAGE (WM_USER_THREAD_FINISHED, FinishDialog)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRenderProgress message handlers



void CRenderProgress::OnPause() 
{
	// TODO: Add your control notification handler code here
	CString s;
	m_pause.GetWindowText (s);
	
	if(s=="Pause")
	{
		win->SuspendThread();
		m_pause.SetWindowText ("Resume");
	}
	else
	{
		win->ResumeThread();
		m_pause.SetWindowText ("Pause");

	}
}

BOOL CRenderProgress::OnInitDialog()
{
	CDialog::OnInitDialog();
if(!CPhotonixDoc::RenderDlg.IsWindowVisible ())
	{
//CWnd *OldParent=CPhotonixDoc::RenderDlg.SetParent (this);
	//	CPhotonixDoc::RenderDlg.Create (IDD_DIALOG1,this);
		CPhotonixDoc::RenderDlg.ShowWindow (SW_SHOW);
//CPhotonixDoc::RenderDlg.SetWindowPos (
	}
m_progress.SetRange (0,100);
	win=AfxBeginThread (CPhotonixDoc::Render,(LPVOID)this);

	this->GetDlgItem (IDC_ANTIALIASING)->SetWindowText (m_antialiasing);
	this->GetDlgItem (IDC_WIDTH)->SetWindowText (m_width);
	this->GetDlgItem (IDC_HEIGHT)->SetWindowText (m_height);
	this->GetDlgItem (IDC_NUMLIGHTS)->SetWindowText (m_numlights);
	this->GetDlgItem (IDC_NUMOBJECTS)->SetWindowText (m_numobjects);
	this->GetDlgItem (IDC_USEPARTICIPATINGMEDIA)->SetWindowText (m_useparticipatingmedia);
	this->GetDlgItem (IDC_USEPHOTON)->SetWindowText (m_usephoton);
	this->GetDlgItem (IDC_VIEWPORT)->SetWindowText (m_viewport);

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
void CRenderProgress::SetStatus(CString status)
{
	if(status=="Rendering")
	{
		tasktimer.start ();
	}
	m_curtask.SetWindowText (status);
}
void CRenderProgress::SetProgress(int value)
{
	m_progress.SetPos(value);

	if(tasktimer.isRunning())
	{
		//	this->UpdateData ();
		tasktimer.updateProgress (value);
		tasktimer.getRemainingTime(m_remainingtime);
		tasktimer.getElapsedTime(m_elapsedtime);
		this->GetDlgItem (IDC_ELAPSEDTIME)->SetWindowText (m_elapsedtime);
		this->GetDlgItem (IDC_REMAININGTIME)->SetWindowText (m_remainingtime);
		//	this->UpdateData (false);
	}
}
void CRenderProgress::OnDestroy()
{
	CDialog::OnDestroy();
	//CPhotonixDoc::RenderDlg.SetParent (OldParent);

}
LRESULT CRenderProgress::FinishDialog(WPARAM wParam, LPARAM lParam)
{
	EndDialog (0);
	return 0;
}

void CRenderProgress::OnClose()
{
	Stop_Flag=true;
	CString s;
	m_pause.GetWindowText (s);

	if(s!="Pause")
	{
		win->ResumeThread();
		m_pause.SetWindowText ("Pause");

	}
}

void CRenderProgress::OnCancel()
{
	Stop_Flag=true;
	CString s;
	m_pause.GetWindowText (s);

	if(s!="Pause")
	{
		win->ResumeThread();
		m_pause.SetWindowText ("Pause");

	}
//	CDialog::OnCancel();
}
