#pragma once

#include "AccessDialog.h"

////////////////////////////////////////////////////////////////////////////
// CNoiseModifier dialog

class CNoiseModifier : public CAccessDialog//CDialog
{
// Construction
public:
	DECLARE_SERIAL(CNoiseModifier)
	CNoiseModifier(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNoiseModifier)
	enum { IDD = IDD_NOISE_MODIFIER };
	BOOL	m_is_uniform;
	float	m_uniform;
	float	m_uniform_x;
	float	m_uniform_y;
	float	m_uniform_z;
	int		m_wavetype;
	int		m_octaves;
	float	m_phase;
	float	m_omega;
	float	m_lambda;
	float	m_frequency;
	float	m_exp;
	//}}AFX_DATA

virtual void Serialize(CArchive &ar);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNoiseModifier)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNoiseModifier)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
