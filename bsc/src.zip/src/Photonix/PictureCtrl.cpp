

#include "stdafx.h"
#include "resource.h"
#include "Picturectrl.h"
#include "timer.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CPictureCtrl, CWnd)

UINT GetMouseScrollLines()
{
	int nScrollLines = 3;
	SystemParametersInfo (SPI_GETWHEELSCROLLLINES, 0, &nScrollLines, 0);
	return nScrollLines;
}

/////////////////////////////////////////////////////////////////////////////
// CPictureCtrl
CPictureCtrl::CPictureCtrl()
{
//	first=false;
}

CPictureCtrl::~CPictureCtrl()
{
	//	if(m_ScrBitmap .m_hObject )
	//		m_ScrBitmap .DeleteObject ();
}


// Register the window class if it has not already been registered.
BOOL CPictureCtrl::RegisterWindowClass()
{
	WNDCLASS wndcls;
	HINSTANCE hInst = AfxGetInstanceHandle();

	if (!(::GetClassInfo(hInst, "PictureCtrl", &wndcls)))
	{
		// otherwise we need to register a new class
		wndcls.style            = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW|CS_PARENTDC|CS_OWNDC;
		wndcls.lpfnWndProc      = ::DefWindowProc;
		wndcls.cbClsExtra       = wndcls.cbWndExtra = 0;
		wndcls.hInstance        = hInst;
		wndcls.hIcon            = NULL;
		wndcls.hCursor          = AfxGetApp()->LoadStandardCursor(IDC_ARROW);
		wndcls.hbrBackground    = ::GetSysColorBrush(COLOR_WINDOW);
		wndcls.lpszMenuName     = NULL;
		wndcls.lpszClassName    = "PictureCtrl";

		if (!AfxRegisterClass(&wndcls))
		{
			AfxThrowResourceException();
			return FALSE;
		}
	}

	return TRUE;
}

BEGIN_MESSAGE_MAP(CPictureCtrl, CWnd)
	//{{AFX_MSG_MAP(CPictureCtrl)
	ON_WM_PAINT()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP

	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CPictureCtrl message handlers
void CPictureCtrl::OnDraw(CDC* pDC)
{

}
#include "memdc.h"
void CPictureCtrl::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CRect rect=m_PictureRect;
	/*
	CBitmap* pOldBitmap;
	if(!first)
	{
	MemDC.CreateCompatibleDC(&dc);
	MemDC.SetWindowOrg(rect.left, rect.top);
	first=true;
	}
	{

	pOldBitmap = MemDC.SelectObject(&m_BitmapSaved);


	dc.BitBlt(rect.left, 
	rect.top, 
	rect.Width(), 
	rect.Height(),
	&MemDC, 
	GetScrollPos(SB_HORZ),//rect.left,
	GetScrollPos(SB_VERT),//rect.top, 
	SRCCOPY);

	MemDC.SelectObject(pOldBitmap);
	}
	*/
	//	Timer t;
	//	t.reset ();
	//	unsigned long l;CString s ;
	//	CMemDC memdc(&dc);
	{
		Graphics graphics(dc.GetSafeHdc ());
		CRect r;
		this->GetClientRect (&r);
		if(m_ScrBitmap)
		{
			graphics.DrawImage(m_ScrBitmap,m_PictureRect.left,m_PictureRect.top,GetScrollPos(SB_HORZ),GetScrollPos(SB_VERT),r.Width(),r.Height(),UnitPixel);
		}

		//	l=t.getMilliseconds ();
		//	s.Format ("%d",l);
	}
	/*
	{
	CRect re;
	if(NULLREGION   !=dc.GetClipBox(&re))
	{
	Graphics graphics(dc.GetSafeHdc ());
	CRect r;
	this->GetClientRect (&r);
	if(m_ScrBitmap)
	{
	graphics.DrawImage(m_ScrBitmap,m_PictureRect.left+re.left ,m_PictureRect.top+re.top ,GetScrollPos(SB_HORZ),GetScrollPos(SB_VERT),re.Width(),re.Height(),UnitPixel);
	}
	}
	else
	{
	Graphics graphics(dc.GetSafeHdc ());
	CRect r;
	this->GetClientRect (&r);
	if(m_ScrBitmap)
	{
	graphics.DrawImage(m_ScrBitmap,m_PictureRect.left,m_PictureRect.top,GetScrollPos(SB_HORZ),GetScrollPos(SB_VERT),r.Width(),r.Height(),UnitPixel);
	}
	}
	}*/
}


////////////////////////////////////////////////////////////////////////////
// CPictureCtrl methods

BOOL CPictureCtrl::Create(CWnd* pParentWnd, const RECT& rect, UINT nID, DWORD dwStyle /*=WS_VISIBLE*/)
{
	RegisterWindowClass();    

	m_BarState = FCSB_NONE;
	m_VScrollMax         = 0;          // Scroll position
	m_HScrollMax         = 0;
	m_RowsPerWheelNotch  = GetMouseScrollLines();

	m_Redraw = true;

	/*	HBITMAP h;
	m_ScrBitmap->GetHBITMAP (Color(0,0,0),&h);
	if(m_BitmapSaved.m_hObject !=NULL)
	m_BitmapSaved.Detach ();
	m_BitmapSaved.Attach (h);
	*/
	ReconstructBitmap();
	// for dc
	BOOL B=CWnd::Create("PictureCtrl", _T(""), dwStyle, rect, pParentWnd, nID);
	//m_ScrBitmap.CreateCompatibleBitmap (this->GetDC (),	W,H);

	return B;
}

void CPictureCtrl::EnableScrollBars(int nBar, BOOL bEnable /*=TRUE*/)
{
	if (bEnable)
	{
		if (!IsVisibleHScroll() && (nBar == SB_HORZ || nBar == SB_BOTH))
		{
			CWnd::EnableScrollBarCtrl(SB_HORZ, bEnable);
			m_BarState |= SB_HORZ;
		}

		if (!IsVisibleVScroll() && (nBar == SB_VERT || nBar == SB_BOTH))
		{
			CWnd::EnableScrollBarCtrl(SB_VERT, bEnable);
			m_BarState |= SB_VERT;
		}
	}
	else
	{
		if ( IsVisibleHScroll() && (nBar == SB_HORZ || nBar == SB_BOTH))
		{
			CWnd::EnableScrollBarCtrl(SB_HORZ, bEnable);
			m_BarState &= ~SB_HORZ; 
		}

		if ( IsVisibleVScroll() && (nBar == SB_VERT || nBar == SB_BOTH))
		{
			CWnd::EnableScrollBarCtrl(SB_VERT, bEnable);
			m_BarState &= ~SB_VERT;
		}
	}
}

// Get/Set scroll position
int CPictureCtrl::GetScrollPos(int nBar, BOOL bGetTrackPos /* = FALSE */)
{
	SCROLLINFO si;
	si.cbSize = sizeof(SCROLLINFO);

	if (bGetTrackPos)
	{
		if (GetScrollInfo(nBar, &si, SIF_TRACKPOS))
			return si.nTrackPos;
	}
	else
	{
		if (GetScrollInfo(nBar, &si, SIF_POS))
			return si.nPos;
	}

	return 0;
}


BOOL CPictureCtrl::SetScrollPos(int nBar, int nPos, BOOL bRedraw /* = TRUE */)
{
	SCROLLINFO si;
	si.cbSize = sizeof(SCROLLINFO);
	si.fMask  = SIF_POS;
	si.nPos   = nPos;
	return SetScrollInfo(nBar, &si, bRedraw);
}

// Handle horz scrollbar notifications
void CPictureCtrl::OnHScroll(UINT nSBCode, UINT /*nPos*/, CScrollBar* /*pScrollBar*/)
{
	int scrollPos = GetScrollPos(SB_HORZ);

	CRect rect;
	GetClientRect(rect);

	switch (nSBCode)
	{
	case SB_LINERIGHT:
		{
			SetScrollPos(SB_HORZ, (scrollPos<m_HScrollMax-10) ? (scrollPos+10) :m_HScrollMax );
			Invalidate ();

		}
		break;
	case SB_PAGERIGHT:
		{
			SetScrollPos(SB_HORZ, (scrollPos<m_HScrollMax-rect.Width()) ? (scrollPos+rect.Width()) :m_HScrollMax );
			Invalidate ();
		}
		break;
	case SB_LINELEFT:
		{
			SetScrollPos(SB_HORZ, (scrollPos>10) ? (scrollPos-10) :0 );
			Invalidate ();
		}
		break;        
	case SB_PAGELEFT:
		{
			SetScrollPos(SB_HORZ, (scrollPos>rect.Width()) ? (scrollPos-rect.Width()) :0 );
			Invalidate ();
		}
		break;        
	case SB_THUMBPOSITION:
	case SB_THUMBTRACK:
		{
			SetScrollPos(SB_HORZ, GetScrollPos(SB_HORZ, TRUE));
			Invalidate ();
		}
		break;

	case SB_LEFT:
		if (scrollPos > 0)
		{
			SetScrollPos(SB_HORZ, 0);
			Invalidate ();
		}
		break;

	case SB_RIGHT:
		if (scrollPos < m_HScrollMax)
		{
			SetScrollPos(SB_HORZ, m_HScrollMax);
			Invalidate ();
		}
		break;

	default: 
		break;
	}
	m_Redraw = false;
}

// Handle vert scrollbar notifications
void CPictureCtrl::OnVScroll(UINT nSBCode, UINT /*nPos*/, CScrollBar* /*pScrollBar*/)
{
	int scrollPos = GetScrollPos(SB_VERT);

	CRect rect;
	GetClientRect(rect);

	switch (nSBCode)
	{
	case SB_LINEDOWN:
		{
			SetScrollPos(SB_VERT, (scrollPos<m_VScrollMax-10) ? (scrollPos+10) : m_VScrollMax );
			Invalidate ();
		}
		break;
	case SB_PAGEDOWN:
		{
			SetScrollPos(SB_VERT, (scrollPos<m_VScrollMax-rect.Height()) ? (scrollPos+rect.Height()) : m_VScrollMax );
			Invalidate ();
		}
		break;
	case SB_LINEUP:
		{
			SetScrollPos(SB_VERT, (scrollPos>10) ? (scrollPos-10) :0 );
			Invalidate ();
		}
		break;
	case SB_PAGEUP:
		{
			SetScrollPos(SB_VERT, (scrollPos>rect.Height()) ? (scrollPos-rect.Height()) :0 );
			Invalidate ();
		}
		break;
	case SB_THUMBPOSITION:
	case SB_THUMBTRACK:
		{
			SetScrollPos(SB_VERT, GetScrollPos(SB_VERT, TRUE));
			Invalidate ();
		}
		break;

	case SB_TOP:
		if (scrollPos > 0)
		{
			SetScrollPos(SB_VERT, 0);
			Invalidate ();
		}
		break;

	case SB_BOTTOM:
		if (scrollPos < m_VScrollMax)
		{
			SetScrollPos(SB_VERT, m_VScrollMax);
			Invalidate ();
		}

	default: 
		break;
	}

	m_Redraw = false;
}

CRect CPictureCtrl::GetPictureRect()
{
	return m_PictureRect;
}

void CPictureCtrl::SetPictureRect(CRect rect)
{
	if(rect!=m_PictureRect)
	{
		m_PictureRect = rect;
		ReconstructBitmap();
	}
}

// If resizing or changes occur, call this - it'll fix up the scroll bars
void CPictureCtrl::ResetScrollBars()
{
	if (!::IsWindow(GetSafeHwnd())) 
		return;

	CRect rect;
	GetClientRect(rect);

	if (rect.left == rect.right || rect.top == rect.bottom)
		return;
//aiz-
/*	if (IsVisibleVScroll())
		rect.right += GetSystemMetrics(SM_CXVSCROLL) + GetSystemMetrics(SM_CXBORDER);

	if (IsVisibleHScroll())
		rect.bottom += GetSystemMetrics(SM_CYHSCROLL) + GetSystemMetrics(SM_CYBORDER);
*/
	if (rect.left >= rect.right || rect.top >= rect.bottom)
	{
		EnableScrollBarCtrl(SB_BOTH, FALSE);
		return;
	}

	CRect VisibleRect(0, 0, rect.right, rect.bottom);
	CRect PictureRect=GetPictureRect();

	// If vertical scroll bar, horizontal space is reduced
/*	if (VisibleRect.Height() < PictureRect.Height())
		VisibleRect.right -= ::GetSystemMetrics(SM_CXVSCROLL);
	// If horz scroll bar, vert space is reduced
	if (VisibleRect.Width() < PictureRect.Width())
		VisibleRect.bottom -= ::GetSystemMetrics(SM_CYHSCROLL);
*/
	// Recheck vertical scroll bar
	if (VisibleRect.Height() < PictureRect.Height())
	{
		EnableScrollBars(SB_VERT, TRUE); 
		m_VScrollMax = PictureRect.Height() - 1;
	}
	else
	{
		EnableScrollBars(SB_VERT, FALSE); 
		m_VScrollMax = 0;
	}

	if (VisibleRect.Width() < PictureRect.Width())
	{
		EnableScrollBars(SB_HORZ, TRUE); 
		m_HScrollMax = PictureRect.Width() - 1;
	}
	else
	{
		EnableScrollBars(SB_HORZ, FALSE); 
		m_HScrollMax = 0;
	}

	ASSERT(m_VScrollMax < INT_MAX && m_HScrollMax < INT_MAX); // This should be fine

	SCROLLINFO si;
	si.cbSize = sizeof(SCROLLINFO);
	si.fMask = SIF_PAGE;
	si.nPage = (m_HScrollMax>0)? VisibleRect.Width() : 0;
	SetScrollInfo(SB_HORZ, &si, FALSE); 
	si.nPage = (m_VScrollMax>0)? VisibleRect.Height() : 0;
	SetScrollInfo(SB_VERT, &si, FALSE);

	SetScrollRange(SB_VERT, 0, m_VScrollMax, TRUE);
	SetScrollRange(SB_HORZ, 0, m_HScrollMax, TRUE);
		Invalidate (true);

}

void CPictureCtrl::OnSize(UINT nType, int nCx, int nCy) 
{
	if (::IsWindow(m_hWnd))
	{
	//	return;
	ResetScrollBars();
	}

	CWnd::OnSize(nType, nCx, nCy);

}



LRESULT CPictureCtrl::SendMessageToParent(int nMessage) const
{
	if (!IsWindow(m_hWnd))
		return 0;
	NMHDR hdr;

	hdr.hwndFrom = m_hWnd;
	hdr.idFrom   = GetDlgCtrlID();
	hdr.code     = nMessage;

	CWnd *pOwner = GetOwner();
	if (pOwner && IsWindow(pOwner->m_hWnd))
		return pOwner->SendMessage(WM_NOTIFY, hdr.idFrom, (LPARAM)&hdr);
	else
		return 0;
}

BOOL CPictureCtrl::OnEraseBkgnd(CDC* pDC)
{
	// TODO: Add your message handler code here and/or call default

	//	return CWnd::OnEraseBkgnd(pDC);
	return true;
}

void CPictureCtrl::OnDestroy()
{
	CWnd::OnDestroy();
	if(m_ScrBitmap)
	{
		delete m_ScrBitmap;
	}
}
void CPictureCtrl::Plot_Pixel(int x, int y, int r, int g, int b, int a)
{
	//	Timer t;
	//	t.reset ();
	//	unsigned long l;CString s ;
	Status s;
	do		
	{
		s=m_ScrBitmap->SetPixel(x,y ,Color(r,g,b));
	}while(s!=Ok);
	//new way
	//	int dx=GetScrollPos(SB_HORZ);
	//	int dy=GetScrollPos(SB_VERT);
	//	this->InvalidateRect (CRect(x-dx,y-dy,x-dx+1,y-dy+1),false);


	//	HBITMAP h;
	//m_ScrBitmap->GetHBITMAP (Color(0,0,0),&h);
	//if(m_BitmapSaved.m_hObject !=NULL)
	//	m_BitmapSaved.Detach ();

	//m_BitmapSaved.Attach (h);

	//

	/*CClientDC dc(this); // device context for painting
	CRect rect=m_PictureRect;

	Graphics graphics(dc.GetSafeHdc ());
	if(m_ScrBitmap)
	{
	graphics.DrawImage(m_ScrBitmap,rect.left,rect.top,GetScrollPos(SB_HORZ),GetScrollPos(SB_VERT),rect.Width(),rect.Height(),UnitPixel);
	}*/
	//CDC* mdc=this->GetDC ();

	CRect rr;
		this->GetClientRect (&rr);
	CRect r1(GetScrollPos(SB_HORZ),GetScrollPos(SB_VERT),GetScrollPos(SB_HORZ)+rr.Width(),GetScrollPos(SB_VERT)+rr.Height());
	if(r1.PtInRect(CPoint(x,y)))
	{
	CClientDC d(this);
	d.SetPixel (x-GetScrollPos(SB_HORZ),y-GetScrollPos(SB_VERT),RGB(r,g,b));
	}
	//this->ReleaseDC (mdc);
	//	l=t.getMilliseconds ();
	//		s.Format ("%d",l);


	//	MemDC.SetPixel (x,y,RGB(r,g,b));
	//	this->Invalidate ();
}

void CPictureCtrl::ReconstructBitmap(void)
{
	if(m_ScrBitmap)
	{
		delete m_ScrBitmap;
	}
	int W=m_PictureRect.Width (),H=m_PictureRect.Height ();

	UINT *pixelsn=new UINT[H*W];
	BYTE* pixels=(BYTE*)pixelsn;
	memset(pixels,0,H*W*sizeof(UINT));

	Bitmap  newbitmap (W,H);
	BitmapData bitmapData;
	bitmapData.Width = W,
		bitmapData.Height = H,
		bitmapData.Stride = 3*bitmapData.Width;
	bitmapData.PixelFormat = PixelFormat24bppRGB ; 
	bitmapData.Scan0 = (VOID*)pixels;
	bitmapData.Reserved = NULL;

	Rect rect2(0, 0, W, H);
	newbitmap.LockBits(
		&rect2,
		ImageLockModeWrite|ImageLockModeUserInputBuf,
		PixelFormat24bppRGB ,
		&bitmapData);

	for(UINT row = 0; row < H; ++row)
	{
		for(UINT col = 0; col < W; ++col)
		{
			pixels[3*(row * bitmapData.Stride / 3 + col)+0] =0;
			pixels[3*(row * bitmapData.Stride / 3 + col)+1] =0;
			pixels[3*(row * bitmapData.Stride / 3 + col)+2] =0;
		}
	}

	newbitmap.UnlockBits(&bitmapData); 
	m_ScrBitmap=newbitmap.Clone (rect2,PixelFormat24bppRGB );
	delete pixels;

}