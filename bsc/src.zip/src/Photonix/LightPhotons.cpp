// LightPhotons.cpp : implementation file
//

#include "stdafx.h"
#include "photonix.h"
#include "LightPhotons.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLightPhotons dialog


CLightPhotons::CLightPhotons(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CLightPhotons::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLightPhotons)
	m_reflection = FALSE;
	m_refraction = FALSE;
	//}}AFX_DATA_INIT
}


void CLightPhotons::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLightPhotons)
	DDX_Check(pDX, IDC_REFLECTION, m_reflection);
	DDX_Check(pDX, IDC_REFRACTION, m_refraction);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLightPhotons, CDialog)
	//{{AFX_MSG_MAP(CLightPhotons)
	ON_BN_CLICKED(IDC_REFLECTION, OnReflection)
	ON_BN_CLICKED(IDC_REFRACTION, OnRefraction)
	//}}AFX_MSG_MAP

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLightPhotons message handlers

void CLightPhotons::OnReflection()
{
	UpdateData(true);
	m_Object->Reflection=m_reflection;
}

void CLightPhotons::OnRefraction()
{
	UpdateData(true);
m_Object->Refraction=m_refraction;
}
