#ifndef SERIALIZEACCESS_H
#define SERIALIZEACCESS_H
#pragma warning(disable:4786)
#include <vector>
#include "GenericSerialize.h"
#include "TexMakerDlg.h"
#include "SelectColor.h"

struct TreeAccess{//user part for tree ctrl serialization
    TreeAccess(CTreeCtrl& rTree,CArchive& rAr):tree(rTree),ar(rAr){}

    typedef HTREEITEM   Type;   //'Type' is a mandatory member of any Access class

#define TA_eRoot       0
#define TA_eChild      1
#define TA_eSibling    2
    

    CTreeCtrl&  tree;   
    CArchive&   ar;     //'ar' is a mandatory member of any Access class
CRollupCtrl *rollup;
    HTREEITEM   Null()const    {return NULL;}
    void        GetNeighbors(HTREEITEM current,vector< pair<Type,int> >& vecNeighbors)const
    {
        if(current==NULL)
		{//get root items
            HTREEITEM   hItem= tree.GetRootItem();
            if(hItem)
			{
                vecNeighbors.push_back( make_pair(hItem,TA_eRoot));
            }
        }
		else
		{
            HTREEITEM hItem= tree.GetNextSiblingItem(current);
            if(hItem)
			{
                vecNeighbors.push_back(make_pair(hItem,TA_eSibling));
            }
            hItem= tree.GetChildItem(current);
            if(hItem)
			{
                vecNeighbors.push_back(make_pair(hItem,TA_eChild));
            }
        }
    }
    void    SerializeThis(HTREEITEM owner,HTREEITEM current,int nTyp)const
    {
        ar  <<  tree.GetItemText(current);
     //   ar  <<  tree.GetItemState(current,TVIF_STATE);	
		ItemDATA* d=(ItemDATA*)tree .GetItemData (current);
		ar<<d->menutype ;
		ar<<d->Name ;
		//if(d->menutype==I_TEX_COLOR)
	//	{
	//		((CDialog*)d->data )->Serialize (ar);
	//	}
		/*POSITION pos=d->data.GetStartPosition ();
		while (pos!=NULL)
		{
			CObject *dlg;CString key;
			d->data.GetNextAssoc (pos,key,dlg);
			((CDialog*)dlg)->Serialize (ar);
		}*/
		d->data .Serialize (ar);
    }
    HTREEITEM    DeserializeThis(HTREEITEM owner,int nTyp)const
    {
        CString strItemText,Name;
      //  UINT   nState;
        ar  >> strItemText;
      //  ar  >> nState;
		int menutype;
		ar>>menutype;
		ar>>Name ;
		
        HTREEITEM hItem;
        switch(nTyp){
        case TA_eRoot:     hItem= tree.InsertItem(strItemText);           break;
        case TA_eChild:    hItem= tree.InsertItem(strItemText,owner);     break;
        case TA_eSibling:  hItem= tree.InsertItem(strItemText,
                                    tree.GetParentItem(owner),owner);     break;
        }
		ItemDATA* d=new ItemDATA(menutype);
		d->Name =Name;
		d->data .Serialize (ar);
POSITION pos=d->data.GetStartPosition ();
		while (pos!=NULL)
		{
			CObject *dl;CString key;
			d->data.GetNextAssoc (pos,key,dl);
CAccessDialog* dlg=((CAccessDialog*)dl);
		dlg->Create (dlg->GetTemplate (),rollup);
		}
		/*if(menutype==I_TEX_COLOR)
		{
			CSelectColor * dlg=new CSelectColor();
		//	d->data=(LPVOID)dlg;
			dlg->Serialize (ar);
			d=new ItemDATA(menutype,dlg);
		}
		else
		{
		d=new ItemDATA(menutype);
        
		}*/
		tree.SetItemData(hItem,(DWORD)d);
        
		
		return hItem;
		return 0;
    }
    void    SetReference(HTREEITEM owner,HTREEITEM current,int nTyp)const
    {
    }
};


#endif