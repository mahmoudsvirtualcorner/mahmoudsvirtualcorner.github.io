#if !defined(AFX_NOISEPATTERN_H__ED179D49_D9DC_4BC7_AC2E_FF4129AE028C__INCLUDED_)
#define AFX_NOISEPATTERN_H__ED179D49_D9DC_4BC7_AC2E_FF4129AE028C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NoisePattern.h : header file
//
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CNoisePattern dialog

class CNoisePattern : public CAccessDialog//CDialog
{
// Construction
public:
	void SetupWindows();
	DECLARE_SERIAL(CNoisePattern)
	CNoisePattern(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNoisePattern)
	enum { IDD = IDD_NOISE_PATTERN };
	float	m_bump_depth;
	float	m_agate_turb;
	BOOL	m_gx;
	BOOL	m_gy;
	BOOL	m_gz;
	int		m_mandel_iter;
	int		m_arms;
	float	m_c0;
	float	m_c1;
	int		m_sel_pat;
	//}}AFX_DATA
virtual void Serialize(CArchive &ar);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNoisePattern)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNoisePattern)
	afx_msg void OnSelchangePatType();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NOISEPATTERN_H__ED179D49_D9DC_4BC7_AC2E_FF4129AE028C__INCLUDED_)
