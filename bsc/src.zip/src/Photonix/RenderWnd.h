#pragma once


// CRenderWnd
#include "myapplication.h"
#include "photonixdoc.h"
#include "viewport.h"
class CPhotonixView;
class CRenderWnd : public CWnd,public IMouseProvider,public IWindowMessageReciever,public IUpdateEventReciever
{
	DECLARE_DYNAMIC(CRenderWnd)

public:
	CRenderWnd();
	virtual ~CRenderWnd();
CPhotonixDoc *pDoc;
Camera *m_CurCamera;
CViewPort *m_CurViewPort;
CPhotonixView *m_Container;
void SetViewportCamera(Camera *cam);

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);

		virtual void OnClose();
virtual void OnDrawSelf();
virtual void OnRefresh();

afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
afx_msg void OnWireframe();
afx_msg void OnSmoothhighlight();
afx_msg void OnPoints();
protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
};


