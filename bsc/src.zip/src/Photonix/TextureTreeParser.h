// TextureTreeParser.h: interface for the CTextureTreeParser class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXTURETREEPARSER_H__5C2475FD_5FC7_49EC_9852_1EBF21836816__INCLUDED_)
#define AFX_TEXTURETREEPARSER_H__5C2475FD_5FC7_49EC_9852_1EBF21836816__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "noisemodifier.h"
#include "WarpDlg.h"
#include "transformation.h"
#include "NoisePattern.h"

class CTextureTreeParser  
{
public:

	void GenerateTexture();
	CTextureTreeParser();
	virtual ~CTextureTreeParser();
	CTreeCtrl * m_tree;
	//TEXTURE * tex;
	TEXTURE *Default_Texture;
	CMapStringToOb Textures;
	CMapStringToOb Interiors;
	CMapStringToOb Medias,Rainbows,SkySpheres;
//CMapStringToOb Ref;

	TEXTURE * ParseTexture(HTREEITEM hitem,INTERIOR **Interior);
	TEXTURE *ParseStanderdTexture( HTREEITEM );
	//TEXTURE * ParseTextureMap(HTREEITEM );
	//TEXTURE *ParseLayeredTexture(HTREEITEM );
	//TEXTURE *ParseMaterialMap(HTREEITEM );
	void ParseBlockPattern(HTREEITEM,TPATTERN * ,int );	
	BLEND_MAP * Parse_Blend_List(HTREEITEM , int ,int ,int);

	void ParsePigment(HTREEITEM ,PIGMENT*);


	/////////////////////////////
	void ParsePattern(CNoisePattern* dlg,TPATTERN *pat);
	void ParseNormal(HTREEITEM hitem,TNORMAL* norm);
	TURB *Check_Turb (WARP **Warps_Ptr);
	void ParseNoiseModifier(CNoiseModifier *dlg,TPATTERN *norm);
	void Parse_Texture_Tranformation(CTransformation *dlg,TEXTURE *New);
	TEXTURE * ParseMaterialMap(HTREEITEM hitem);
	TEXTURE * ParseLayeredTexture(HTREEITEM hitem);
	void ParseWarp(CWarpDlg *dlg,WARP **Warp_Ptr);
	void Check_BH_Parameters (BLACK_HOLE *bh);
void ParseDenisty(HTREEITEM hitem,PIGMENT* pig);

	int FreeMaterials(void);
	TEXTURE* GetTexture(CString TexName);
	INTERIOR* GetInterior(CString TexName);
	RAINBOW *ParseRainbow(HTREEITEM hitem);
	SKYSPHERE* ParseSkySphere(HTREEITEM hitem);
};

#endif // !defined(AFX_TEXTURETREEPARSER_H__5C2475FD_5FC7_49EC_9852_1EBF21836816__INCLUDED_)
