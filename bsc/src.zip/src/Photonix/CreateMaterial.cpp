// CreateMaterial.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "CreateMaterial.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCreateMaterial dialog


CCreateMaterial::CCreateMaterial(CWnd* pParent /*=NULL*/)
	: CDialog(CCreateMaterial::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCreateMaterial)
	m_mat_type = 0;
	m_name = _T("");
	//}}AFX_DATA_INIT
}


void CCreateMaterial::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCreateMaterial)
	DDX_Radio(pDX, IDC_TEXTURE, m_mat_type);
	DDX_Text(pDX, IDC_TEX_NAME, m_name);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCreateMaterial, CDialog)
	//{{AFX_MSG_MAP(CCreateMaterial)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCreateMaterial message handlers

void CCreateMaterial::OnBnClickedOk()
{
	this->UpdateData ();
	if(m_name=="")
	{
		MessageBox ("Please Enter a name for the Material");
		return ;
	}
	OnOK();
}
