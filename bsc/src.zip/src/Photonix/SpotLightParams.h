#if !defined(AFX_SPOTLIGHTPARAMS_H__A357C2EE_23CD_4F85_83F2_70ED36C2C6BF__INCLUDED_)
#define AFX_SPOTLIGHTPARAMS_H__A357C2EE_23CD_4F85_83F2_70ED36C2C6BF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SpotLightParams.h : header file
//
#include "AccessDialog.h"
/////////////////////////////////////////////////////////////////////////////
// CSpotLightParams dialog

class CSpotLightParams : public CAccessDialog//CDialog
{
// Construction
public:
	CSpotLightParams(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSpotLightParams)
	enum { IDD = IDD_SPOTLIGHTPARAMS };
	float	m_falloff;
	float	m_raduis;
	float	m_tightness;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpotLightParams)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSpotLightParams)
	afx_msg void OnKillfocusFalloff();
	afx_msg void OnKillfocusRadius();
	afx_msg void OnKillfocusTightness();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPOTLIGHTPARAMS_H__A357C2EE_23CD_4F85_83F2_70ED36C2C6BF__INCLUDED_)
