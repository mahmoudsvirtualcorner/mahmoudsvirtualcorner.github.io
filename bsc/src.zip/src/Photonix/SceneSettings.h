#if !defined(AFX_SCENESETTINGS_H__E2504228_3B2A_4140_84F9_C00E6E2E3737__INCLUDED_)
#define AFX_SCENESETTINGS_H__E2504228_3B2A_4140_84F9_C00E6E2E3737__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SceneSettings.h : header file
//
#include "RollupCtrl.h"
#include "FogOptions.h"
#include "MediaOptions.h"
#include "GlobalSettings.h"
#include "RadiosityOptions.h"
#include "PhotonMappingOptions.h"

/////////////////////////////////////////////////////////////////////////////
// CSceneSettings dialog

class CSceneSettings : public CDialog
{
// Construction
public:
	CSceneSettings(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSceneSettings)
	enum { IDD = IDD_SCENE_SETTINGS };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSceneSettings)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
	public:
	CRollupCtrl m_rollup;

	CFogOptions m_fogdlg;
CMediaOptions m_mediadlg;
CGlobalSettings m_globaldlg;
CRadiosityOptions m_raddlg;
CPhotonMappingOptions m_pmdialog;
	// Generated message map functions
	//{{AFX_MSG(CSceneSettings)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCENESETTINGS_H__E2504228_3B2A_4140_84F9_C00E6E2E3737__INCLUDED_)
