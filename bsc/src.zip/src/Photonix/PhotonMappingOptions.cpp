// PhotonMappingOptions.cpp : implementation file
//

#include "stdafx.h"
#include "photonix.h"
#include "PhotonMappingOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPhotonMappingOptions dialog


CPhotonMappingOptions::CPhotonMappingOptions(CWnd* pParent /*=NULL*/)
	: CDialog(CPhotonMappingOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPhotonMappingOptions)
	m_spacing = 0.02f;
	m_usepm = TRUE;
	m_adcbailout = -1.0f;
	m_filename = _T("");
	m_jitter = 0.4f;
	m_maxtracelevel = -1.0f;
	m_photoncount = 0;
	m_save = FALSE;
	m_usefile = FALSE;
	m_usespacing = TRUE;
	m_mediaphoton = FALSE;
	//}}AFX_DATA_INIT
}


void CPhotonMappingOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPhotonMappingOptions)
	DDX_Text(pDX, IDC_SPACING, m_spacing);
	DDV_MinMaxFloat(pDX, m_spacing, 1.e-008f, 100.f);
	DDX_Check(pDX, IDC_USEPM, m_usepm);
	DDX_Text(pDX, IDC_ADCBAILOUT, m_adcbailout);
	DDX_Text(pDX, IDC_FILENAME, m_filename);
	DDX_Text(pDX, IDC_JITTER, m_jitter);
	DDV_MinMaxFloat(pDX, m_jitter, 1.e-005f, 100.f);
	DDX_Text(pDX, IDC_MAXTRACELEVEL, m_maxtracelevel);
	DDV_MinMaxFloat(pDX, m_maxtracelevel, -1.f, 100.f);
	DDX_Text(pDX, IDC_PHOTONCOUNT, m_photoncount);
	DDX_Check(pDX, IDC_SAVELOAD, m_save);
	DDX_Check(pDX, IDC_USEFILES, m_usefile);
	DDX_Check(pDX, IDC_USESPACINGCOUNT, m_usespacing);
	DDX_Check(pDX, IDC_MEDIAPHOTON, m_mediaphoton);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPhotonMappingOptions, CDialog)
	//{{AFX_MSG_MAP(CPhotonMappingOptions)
	ON_BN_CLICKED(IDC_USEFILES, OnUsefiles)
	ON_BN_CLICKED(IDC_USESPACINGCOUNT, OnUsespacingcount)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPhotonMappingOptions message handlers

void CPhotonMappingOptions::OnUsefiles() 
{
		UpdateData ();
		UpdateFileEnable();
}

void CPhotonMappingOptions::OnUsespacingcount() 
{
	UpdateData ();
	UpdateSpacingAndCount();
}

void CPhotonMappingOptions::UpdateSpacingAndCount()
{
if(m_usespacing)
	{
		CWnd * wnd=(this->GetDlgItem (IDC_SPACING));
		wnd->EnableWindow (true);
		wnd=(this->GetDlgItem (IDC_PHOTONCOUNT));
		wnd->EnableWindow (false);

	}
	else
	{
		CWnd * wnd=(this->GetDlgItem (IDC_SPACING));
		wnd->EnableWindow (false);
		wnd=(this->GetDlgItem (IDC_PHOTONCOUNT));
		wnd->EnableWindow (true);

	}
}

void CPhotonMappingOptions::UpdateFileEnable()
{
if(m_usefile)
	{
		CWnd * wnd=(this->GetDlgItem (IDC_SAVELOAD));
		wnd->EnableWindow (true);
		wnd=(this->GetDlgItem (IDC_FILENAME));
		wnd->EnableWindow (true);
		wnd=(this->GetDlgItem (IDC_BROWSE));
		wnd->EnableWindow (true);

		
	}
	else
	{
		CWnd * wnd=(this->GetDlgItem (IDC_SAVELOAD));
		wnd->EnableWindow (false);
		wnd=(this->GetDlgItem (IDC_FILENAME));
		wnd->EnableWindow (false);
		wnd=(this->GetDlgItem (IDC_BROWSE));
		wnd->EnableWindow (false);

	}
}

BOOL CPhotonMappingOptions::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
		UpdateFileEnable();
		UpdateSpacingAndCount();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
