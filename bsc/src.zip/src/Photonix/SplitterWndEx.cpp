// SplitterWndEx.h : implementation file
//
// Written by Stephane Routelous (stephane.routelous@altavista.net)
// Copyright (c) 1999.
// All rights reserved
//
//
// Use and distribute freely, except: don't remove my name from the
// source or documentation (don't take credit for my work), mark your
// changes (don't get me blamed for your possible bugs), don't alter
// or remove this notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// This class extend the CSplitterWnd class from MFC with focus and 
// split features.
//
// This class uses some code from someone , for OnDrawSplitter method.
// If you know who has writtent this code, send me a mail. I would like to add
// credit for his work.


#include "stdafx.h"
#include "SplitterWndEx.h"
#include "resource.h"

#include "PhotonixView.h"

/////////////////////////////////////////////////////////////////////////////
// CSplitterWndEx

BEGIN_MESSAGE_MAP(CSplitterWndEx, CSplitterWnd)
	//{{AFX_MSG_MAP(CSplitterWndEx)
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
void CSplitterWndEx::RefreshSplitBars(void)
{	
	CRect rectInside;
	GetInsideRect(rectInside);
	DrawAllSplitBars(NULL, rectInside.right, rectInside.bottom);
}

CSplitterWndEx::CSplitterWndEx()
{
	m_bIsAutomaticSplit = false;
	m_bSplittingDone = false;
}

void CSplitterWndEx::OnDrawSplitter(CDC* pDC, ESplitType nType, const CRect& rectArg)
{
	int x_ActivePane, y_ActivePane; 
	COLORREF hilightcolor = RGB(255,255,0);
	GetActivePane(&x_ActivePane, &y_ActivePane);
	
	if( ((GetRowCount()>1) || (GetColumnCount()>1)) && (nType == splitBorder))
	{
		int pRow = 0;
		int pCol = 0;
		if(rectArg.top)
		{
			pRow = 1;	
		}
		if(rectArg.left)
		{
			pCol = 1;
		}
		if((pCol == y_ActivePane) && (pRow == x_ActivePane)) 
		{
			if (pDC == NULL)
			{
				RedrawWindow(rectArg, NULL, RDW_INVALIDATE|RDW_NOCHILDREN);
				return; 		
			}
			ASSERT_VALID(pDC);	
			CRect rect = rectArg;
			pDC->Draw3dRect(rect, hilightcolor, hilightcolor);
			int dx = -GetSystemMetrics(SM_CXBORDER);
			int dy = -GetSystemMetrics(SM_CYBORDER);
			rect.InflateRect(dx,dy);
			pDC->Draw3dRect(rect, hilightcolor, hilightcolor);
			return;
		}
	}
	/*int nbRow = GetRowCount();
		int nbCol = GetColumnCount();
		for ( int r = 0 ; r < nbRow ; r++ )
		{
			for ( int c = 0 ; c < nbCol ; c++ )
			{
				CPhotonixView * theView = (CPhotonixView*)GetPane(r,c);
				theView->DrawDetails();
			}
		}*/
	CSplitterWnd::OnDrawSplitter(pDC,nType,rectArg);
}

//==================================================================================
// Function name	: CSplitterWndEx::StartTracking
// Written by	    : Stephane Routelous / 28-10-99
// Description	    : Overloaded to change the cursor aspect ( to avoid the IDC_SIZEALL cursor )
// Return type		: void 
//==================================================================================
// Argument         : int ht
void CSplitterWndEx::StartTracking(int ht)
{
	//save the current cursor ...
	HCURSOR theCurrentCursor = GetCursor();

	CSplitterWnd::StartTracking(ht);

	if ( m_bIsAutomaticSplit )
	{
		//...and restore it immediatelly if in AutomaticSplit mode
		SetCursor(theCurrentCursor);
	}
}

//==================================================================================
// Function name	: CSplitterWndEx::OnMouseMove
// Written by	    : Stephane Routelous / 28-10-99
// Description	    : Method overloaded to stop the tracking if we are in Automatic mode
// Return type		: void 
//==================================================================================
// Argument         : UINT nFlags
// Argument         : CPoint pt
void CSplitterWndEx::OnMouseMove(UINT nFlags, CPoint pt)
{
	if ( m_bIsAutomaticSplit )
	{
		//if AutomaticSplit mode : We are not able to choose the position of the splitters
		// -> Exiting to next step
		StopTracking(TRUE);
		return;
	}
	CSplitterWnd::OnMouseMove(nFlags,pt);
}


//==================================================================================
// Function name	: CSplitterWndEx::StopTracking
// Written by	    : Stephane Routelous / 28-10-99
// Description	    : End of the Mouse tracking function
// Return type		: void 
//==================================================================================
// Argument         : BOOL bAccept
void CSplitterWndEx::StopTracking(BOOL bAccept)
{
	CSplitterWnd::StopTracking(bAccept);

	//now the is splitting done
	m_bIsAutomaticSplit = false;
	m_bSplittingDone = true;
}

 

//==================================================================================
// Function name	: CSplitterWndEx::DoAutomaticSplit
// Written by	    : Stephane Routelous / 28-10-99
// Description	    : Do a split of your CView directly with 4 panes of the same size
// Return type		: BOOL 
//==================================================================================
BOOL CSplitterWndEx::DoAutomaticSplit()
{
	//save the current mouse position
	POINT theInitialMousePosition;
	GetCursorPos(&theInitialMousePosition);

	//set the splitting done to false ( of course )
	m_bSplittingDone = false;

	//and automaitic to true 
	m_bIsAutomaticSplit = true;
	
	//do the split
	BOOL RetVal = CSplitterWnd::DoKeyboardSplit();

	//restore immediatelly the old mouse poition
	SetCursorPos(theInitialMousePosition.x,theInitialMousePosition.y);
	

	return RetVal;
}


//==================================================================================
// Function name	: CSplitterWndEx::DoKeyboardSplit
// Written by	    : Stephane Routelous / 28-10-99
// Description	    : "Standard" Splitting function
//					:   overloaded to set the variables
// Return type		: BOOL 
//==================================================================================
BOOL CSplitterWndEx::DoKeyboardSplit()
{
	m_bSplittingDone = false;
	m_bIsAutomaticSplit = false;
	return CSplitterWnd::DoKeyboardSplit();
}
