#if !defined(AFX_RAINBOWOPTIONS_H__8F05555D_08B6_4BF9_ADAB_84097EFBC680__INCLUDED_)
#define AFX_RAINBOWOPTIONS_H__8F05555D_08B6_4BF9_ADAB_84097EFBC680__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RainbowOptions.h : header file
//
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CRainbowOptions dialog

class CRainbowOptions : public CAccessDialog//CDialog
{
// Construction
public:
	DECLARE_SERIAL(CRainbowOptions)
	CRainbowOptions(CWnd* pParent = NULL);   // standard constructor
virtual void Serialize(CArchive &ar);
// Dialog Data
	//{{AFX_DATA(CRainbowOptions)
	enum { IDD = IDD_RAINBOW_OPTIONS };
	float	m_falloff_angle;
	float	m_arc_angle;
	float	m_distance;
	float	m_falloff_width;
	float	m_jitter;
	float	m_right_x;
	float	m_right_y;
	float	m_right_z;
	float	m_up_x;
	float	m_up_y;
	float	m_up_z;
	float	m_width;
	float	m_angle;
	float	m_antisolar_x;
	float	m_antisolar_y;
	float	m_antisolar_z;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRainbowOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRainbowOptions)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RAINBOWOPTIONS_H__8F05555D_08B6_4BF9_ADAB_84097EFBC680__INCLUDED_)
