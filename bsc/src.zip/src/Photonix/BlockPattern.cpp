// BlockPattern.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "BlockPattern.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CBlockPattern dialog
IMPLEMENT_SERIAL(CBlockPattern,CAccessDialog,1)


CBlockPattern::CBlockPattern(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CBlockPattern::IDD, pParent)
{
	//{{AFX_DATA_INIT(CBlockPattern)
	m_type = 0;
	m_bricksize = 0.0f;
	m_length_x = 1.0f;
	m_length_y = 0.6f;
	m_length_z = 3.0f;
	m_mortar = 0.06f;
	//}}AFX_DATA_INIT
}


void CBlockPattern::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBlockPattern)
	DDX_CBIndex(pDX, IDC_BP_TYPE, m_type);
	DDX_Text(pDX, IDC_BRICK_SIZE, m_bricksize);
	DDX_Text(pDX, IDC_LENGTH_X, m_length_x);
	DDX_Text(pDX, IDC_LENGTH_Y, m_length_y);
	DDX_Text(pDX, IDC_LENGTH_Z, m_length_z);
	DDX_Text(pDX, IDC_MORTAR, m_mortar);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBlockPattern, CDialog)
	//{{AFX_MSG_MAP(CBlockPattern)
	ON_BN_CLICKED(IDC_SIZE_ONE, OnSizeOne)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBlockPattern message handlers

void CBlockPattern::OnSizeOne() 
{
	// TODO: Add your control notification handler code here
	
}

BOOL CBlockPattern::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CComboBox * m=((CComboBox*)this->GetDlgItem (IDC_BP_TYPE));
	m->AddString ("checker");
	m->AddString ("hexagon");
	m->AddString ("bricks");
	this->UpdateData (false);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
