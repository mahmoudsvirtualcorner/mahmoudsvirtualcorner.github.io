#if !defined(AFX_BITMAPMODIFIER_H__4412B310_BF37_4572_8573_BAAA4598FC64__INCLUDED_)
#define AFX_BITMAPMODIFIER_H__4412B310_BF37_4572_8573_BAAA4598FC64__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BitmapModifier.h : header file
//
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CBitmapModifier dialog

class CBitmapModifier : public CAccessDialog//CDialog
{
// Construction
public:
		DECLARE_SERIAL(CBitmapModifier)

	CBitmapModifier(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBitmapModifier)
	enum { IDD = IDD_BITMAP_MODIFIER };
	CString	m_filename;
	int		m_maptype;
	int		m_interpolation;
	BOOL	m_once;
	BOOL	m_useindex;
	//}}AFX_DATA
virtual void Serialize(CArchive &ar);


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBitmapModifier)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBitmapModifier)
	afx_msg void OnBrowse();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BITMAPMODIFIER_H__4412B310_BF37_4572_8573_BAAA4598FC64__INCLUDED_)
