#if !defined(AFX_RENDERPROGRESS_H__EBD5D7C8_2F32_4607_99DC_D6A11D3556E3__INCLUDED_)
#define AFX_RENDERPROGRESS_H__EBD5D7C8_2F32_4607_99DC_D6A11D3556E3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RenderProgress.h : header file
//
/////////////////////////////////////////////////////////////////////////////
// CRenderProgress dialog
#include "TaskTimer.h"

#define WM_USER_THREAD_FINISHED	WM_USER+0x102
class CPhotonixDoc;
class CRenderProgress : public CDialog
{
// Construction
public:
	CRenderProgress(CWnd* pParent = NULL);   // standard constructor
CPhotonixDoc * pDoc;
void SetStatus(CString status);
void SetProgress(int value);
CWinThread * win;
TaskTimer tasktimer;
LRESULT FinishDialog(WPARAM wParam, LPARAM lParam);
//CWnd *OldParent;
// Dialog Data
	//{{AFX_DATA(CRenderProgress)
	enum { IDD = IDD_RENDERPROGRESS };
	CButton	m_pause;
	CProgressCtrl	m_progress;
	CStatic	m_curtask;
	CString	m_antialiasing;
	CString	m_elapsedtime;
	CString	m_height;
	CString	m_numlights;
	CString	m_numobjects;
	CString	m_remainingtime;
	CString	m_useparticipatingmedia;
	CString	m_usephoton;
	CString	m_viewport;
	CString	m_width;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRenderProgress)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRenderProgress)
	afx_msg void OnPause();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnClose();
protected:
	virtual void OnCancel();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RENDERPROGRESS_H__EBD5D7C8_2F32_4607_99DC_D6A11D3556E3__INCLUDED_)
