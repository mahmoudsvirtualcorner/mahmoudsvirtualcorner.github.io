// AccessDialog.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "AccessDialog.h"


// CAccessDialog dialog

IMPLEMENT_DYNAMIC(CAccessDialog, CDialog)
CAccessDialog::CAccessDialog(UINT idtemplate,CWnd* pParent /*=NULL*/)
	: CDialog(idtemplate, pParent)
{
}

CAccessDialog::~CAccessDialog()
{
}

void CAccessDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CAccessDialog, CDialog)
END_MESSAGE_MAP()


// CAccessDialog message handlers

LPCTSTR CAccessDialog::GetTemplate(void)
{
	return m_lpszTemplateName;
}
