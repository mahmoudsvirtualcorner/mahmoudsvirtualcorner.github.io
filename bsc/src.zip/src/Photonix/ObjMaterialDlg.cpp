// ObjMaterialDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "ObjMaterialDlg.h"
#include "MaterialsDlg.h"
#include "texmakerdlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CObjMaterialDlg dialog


CObjMaterialDlg::CObjMaterialDlg(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CObjMaterialDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CObjMaterialDlg)
	m_matname = _T("");
	//}}AFX_DATA_INIT
}


void CObjMaterialDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CObjMaterialDlg)
	DDX_Text(pDX, IDC_MATERIALNAME, m_matname);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CObjMaterialDlg, CAccessDialog)
	//{{AFX_MSG_MAP(CObjMaterialDlg)
	ON_BN_CLICKED(IDC_SELECTMATERIAL, OnSelectMaterial)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CObjMaterialDlg message handlers

void CObjMaterialDlg::OnSelectMaterial() 
{
	// TODO: Add your control notification handler code here
	CMaterialsDlg dlg;
	dlg.m_Searchtype=I_MATERIAL;
	if(dlg.DoModal ()==IDOK)
	{
		m_matname=dlg.m_MaterialName;
		m_Object->RayTextureName=m_matname;
		this->UpdateData(false);
	}
}
