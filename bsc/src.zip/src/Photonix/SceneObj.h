#pragma once
#include "enggenclasses.h"

class SceneObj:public Scene,public IScene
{
public :
	virtual ~SceneObj();
	virtual void GenerateScene();
	CObArray m_SceneObjects,m_SceneCameras;

	CMapStringToOb m_MapSceneObjects;
SceneObjectData* AddSceneObject(ISceneObject * pObject);
void DeleteSceneObject(ISceneObject * pObject);
void DeleteSceneObject(CString ObjectName);
int GetCameraCount();
int GetLightCount();
int  GetObjectsCount();
};