#if !defined(AFX_FINISHDLG_H__B39218EE_D605_4F99_AA22_A1AD68E005C2__INCLUDED_)
#define AFX_FINISHDLG_H__B39218EE_D605_4F99_AA22_A1AD68E005C2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FinishDlg.h : header file
//
#include "AccessDialog.h"
#include "frame.h"
/////////////////////////////////////////////////////////////////////////////
// CFinishDlg dialog

class CFinishDlg : public CAccessDialog//CDialog
{
// Construction
public:
			DECLARE_SERIAL(CFinishDlg)
	void Fill(FINISH* f);

	CFinishDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFinishDlg)
	enum { IDD = IDD_FINISH };
	float	m_ambient;
	float	m_amount;
	float	m_brilliance;
	float	m_crand;
	float	m_diffuse;
	BOOL	m_ref_enabled;
	float	m_influence;
	BOOL	m_irid_enabled;
	BOOL	m_metallic_enabled;
	float	m_phong;
	float	m_phong_size;
	float	m_reflection;
	float	m_roughness;
	float	m_specular;
	float	m_thickness;
	float	m_turbulence_x;
	float	m_turbulence_y;
	float	m_turbulence_z;
	//}}AFX_DATA
virtual void Serialize(CArchive &ar);


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFinishDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFinishDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINISHDLG_H__B39218EE_D605_4F99_AA22_A1AD68E005C2__INCLUDED_)
