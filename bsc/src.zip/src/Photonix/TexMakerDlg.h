// TexMakerDlg.h : header file
//

#if !defined(AFX_TEXMAKERDLG_H__700B14BB_3BFB_4280_BC2D_C3012BD55CC0__INCLUDED_)
#define AFX_TEXMAKERDLG_H__700B14BB_3BFB_4280_BC2D_C3012BD55CC0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "RollupCtrl.h"
#include "Picturectrl.h"

/////////////////////////////////////////////////////////////////////////////
// CTexMakerDlg dialog
struct ItemDATA
{
	int menutype;
	CMapStringToOb  data;
	CString Name;
	ItemDATA(int type)
	{
		Name="";
menutype=type;
//data=new CMapStringToOb();
	}
};

enum
{
	I_MATERIAL=0,
		I_STANDARD_TEX,
		//PIGMENTS
		I_TEX_PIGMENT,
		I_BP_WITH_COLOR,
		I_BP_WITH_PIGMENT,
		I_COLOR_MAP,
		I_PIGMENT_MAP,
		I_PIGMENT_MAP_VAL,
		I_IMAGE_MAP,
		I_TEX_COLOR,
		//NORMAL
		I_TEX_NORMAL,
		I_NORMAL_PATTERN,
		I_SLOPE_MAP,
		I_BP_WITH_NORM,
		I_NORMAL_MAP,
		I_NORMAL_MAP_VAL,
		I_BUMP_MAP,
		//FINISH
		I_TEX_FINISH,
		//	TEX TYPES
		I_TEX_MAP,
		I_TEX_LAYERED,
		I_MATERIAL_MAP,
		I_TEX_BP,
		//	TEX MAPS
		I_TEX_MAP_VAL,

		//INTERIORS Items
		I_INTERIOR,
		I_MEDIA,
		I_INTERIOR_DENISTY,
		I_DENISTY_PAT,
		I_BP_WITH_DENISTY,
		I_DENISTY_MAP,
		I_DENISTY_MAP_VAL,

		//other tex
		I_SKY_SPHERE,
		I_RAINBOW_MATERIAL,
		I_RAINBOW,
};

class CTexMakerDlg : public CDialog
{
// Construction
public:
	CTexMakerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTexMakerDlg)
	enum { IDD = IDD_TEXMAKER_DIALOG };
	CTreeCtrl	m_tree;
	CString	m_currainbow;
	CString	m_curskysphere;
	int		m_scenetype;
	BOOL	m_antialias;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTexMakerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
public:
	static UINT Render(LPVOID p);
static 	CPictureCtrl m_Window;

	bool NameExistinTree(CString Name);
	void GenerateTexture();
	CRollupCtrl m_rollup;
	HICON m_hIcon;
	HTREEITEM root;
	HTREEITEM hCurItem;
	bool SceneEnviromental;
	CString m_CurrentMaterialName;
	// Generated message map functions
	//{{AFX_MSG(CTexMakerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnPreview();
	virtual void OnOK();
	afx_msg void OnRclickTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeleteitemTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnAddStandardTex();
	afx_msg void OnUpdateStandardTex(CCmdUI* pCmdUI);
	afx_msg void OnAddTexMap();
	afx_msg void OnAddMatMap();
	afx_msg void OnAddTexLayered();
	afx_msg void OnAddTexPat();
	afx_msg void OnSave();
	afx_msg void OnLoad();
	afx_msg void OnProperties();
	afx_msg void OnPigment();
	afx_msg void OnSolidColor();
	afx_msg void OnAddTexPatEntry();
	afx_msg void OnAddLeyStandTex();
	afx_msg void OnBpSt();
	afx_msg void OnBpBpt();
	afx_msg void OnBpLt();
	afx_msg void OnBpMm();
	afx_msg void OnBpTm();
	afx_msg void OnMatmapBpt();
	afx_msg void OnMatmapLt();
	afx_msg void OnMatmapMm();
	afx_msg void OnMatmapSt();
	afx_msg void OnMatmapTm();
	afx_msg void OnTexmapBpt();
	afx_msg void OnTexmapLt();
	afx_msg void OnTexmapMm();
	afx_msg void OnTexmapSt();
	afx_msg void OnTexmapTm();
	afx_msg void OnPigBpSc();
	afx_msg void OnPigBpPig();
	afx_msg void OnPigIm();
	afx_msg void OnPigCm();
	afx_msg void OnPigPm();
	afx_msg void OnFinish();
	afx_msg void OnBpSolidColor();
	afx_msg void OnBpPigment();
	afx_msg void OnMapEntry();
	afx_msg void OnSceneSettings();
	afx_msg void OnDestroy();
	afx_msg void OnSysChangename();
	afx_msg void OnRender();
	afx_msg void OnAddmaterial();
	afx_msg void OnAddtorainbowmatRainbow();
	afx_msg void OnBrowseRainbows();
	afx_msg void OnBrowseSkysphere();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
//	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnSysDelete();
	afx_msg void OnAddtonormalNormalpattern();
	afx_msg void OnAddtonormalBlockpatternwithnormals();
	afx_msg void OnAddtonormalNormalmappattern();
	afx_msg void OnBumpMap();
	afx_msg void OnBpnNormal();
	afx_msg void OnNOrmalMapEntry();
	afx_msg void OnNormal();
	afx_msg void OnTvnSelchangedTree1(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnInterior();
	afx_msg void OnMedia();
	afx_msg void OnDenisty();
	afx_msg void OnAddtodensityDensitypattern();
	afx_msg void OnAddtodensityBlockpatternwithdensities();
	afx_msg void OnAddtodensityDensitymappattern();
	afx_msg void OnStopPreview();
	void UpdateRollUpCtrl(void);
	afx_msg void OnSceneMaterial();
	afx_msg void OnSceneEnviromental();
public:
	// enables the render button
	void StopRendering(void);
	afx_msg void OnRemoveAll();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEXMAKERDLG_H__700B14BB_3BFB_4280_BC2D_C3012BD55CC0__INCLUDED_)
