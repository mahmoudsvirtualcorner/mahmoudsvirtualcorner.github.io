#if !defined(AFX_CAMERAOPTIONS_H__0F6CE5BA_A2EC_4B01_9289_8E364C24E775__INCLUDED_)
#define AFX_CAMERAOPTIONS_H__0F6CE5BA_A2EC_4B01_9289_8E364C24E775__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CameraOptions.h : header file
//
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CCameraOptions dialog

class CCameraOptions : public CAccessDialog//CDialog
{
// Construction
public:
	CCameraOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCameraOptions)
	enum { IDD = IDD_CAMERAOPTIONS };
	float	m_aperture;
	float	m_confidence;
	float	m_focalx;
	float	m_focaly;
	float	m_focalz;
	float	m_variance;
	UINT	m_blursamples;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCameraOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCameraOptions)
	afx_msg void OnKillfocusAperture();
	afx_msg void OnKillfocusBlursamples();
	afx_msg void OnKillfocusConfidence();
	afx_msg void OnKillfocusFocalx();
	afx_msg void OnKillfocusFocaly();
	afx_msg void OnKillfocusFocalz();
	afx_msg void OnKillfocusVariance();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CAMERAOPTIONS_H__0F6CE5BA_A2EC_4B01_9289_8E364C24E775__INCLUDED_)
