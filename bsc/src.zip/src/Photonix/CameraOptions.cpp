// CameraOptions.cpp : implementation file
//

#include "stdafx.h"
#include "photonix.h"
#include "CameraOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCameraOptions dialog


CCameraOptions::CCameraOptions(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CCameraOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCameraOptions)
	m_aperture = 0.0f;
	m_confidence = 0.9f;
	m_focalx = 0.0f;
	m_focaly = 0.0f;
	m_focalz = 0.0f;
	m_variance = 1.0 / 10000.0;
	m_blursamples = 0;
	//}}AFX_DATA_INIT
}


void CCameraOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCameraOptions)
	DDX_Text(pDX, IDC_APERTURE, m_aperture);
	DDX_Text(pDX, IDC_CONFIDENCE, m_confidence);
	DDV_MinMaxFloat(pDX, m_confidence, 1.e-005f, 1.f);
	DDX_Text(pDX, IDC_FOCALX, m_focalx);
	DDX_Text(pDX, IDC_FOCALY, m_focaly);
	DDX_Text(pDX, IDC_FOCALZ, m_focalz);
	DDX_Text(pDX, IDC_VARIANCE, m_variance);
	DDV_MinMaxFloat(pDX, m_variance, 0.f, 1.f);
	DDX_Text(pDX, IDC_BLURSAMPLES, m_blursamples);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCameraOptions, CAccessDialog)
	//{{AFX_MSG_MAP(CCameraOptions)
	ON_EN_KILLFOCUS(IDC_APERTURE, OnKillfocusAperture)
	ON_EN_KILLFOCUS(IDC_BLURSAMPLES, OnKillfocusBlursamples)
	ON_EN_KILLFOCUS(IDC_CONFIDENCE, OnKillfocusConfidence)
	ON_EN_KILLFOCUS(IDC_FOCALX, OnKillfocusFocalx)
	ON_EN_KILLFOCUS(IDC_FOCALY, OnKillfocusFocaly)
	ON_EN_KILLFOCUS(IDC_FOCALZ, OnKillfocusFocalz)
	ON_EN_KILLFOCUS(IDC_VARIANCE, OnKillfocusVariance)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCameraOptions message handlers

void CCameraOptions::OnKillfocusAperture() 
{
	UpdateData ();
	((CameraObj *)m_Object )->Aperture =m_aperture;
}

void CCameraOptions::OnKillfocusBlursamples() 
{
		UpdateData ();
	((CameraObj *)m_Object )->Blur_Samples  =m_blursamples;

}

void CCameraOptions::OnKillfocusConfidence() 
{
			UpdateData ();
	((CameraObj *)m_Object )->Confidence   =m_confidence;

}

void CCameraOptions::OnKillfocusFocalx() 
{
	UpdateData ();
	((CameraObj *)m_Object )->Focal_Point.x   =m_focalx;

	
}

void CCameraOptions::OnKillfocusFocaly() 
{
		UpdateData ();
	((CameraObj *)m_Object )->Focal_Point.y   =m_focaly;

}

void CCameraOptions::OnKillfocusFocalz() 
{
			UpdateData ();
	((CameraObj *)m_Object )->Focal_Point.z   =m_focalz;

}

void CCameraOptions::OnKillfocusVariance() 
{
				UpdateData ();
	((CameraObj *)m_Object )->Variance    =m_variance;

}
