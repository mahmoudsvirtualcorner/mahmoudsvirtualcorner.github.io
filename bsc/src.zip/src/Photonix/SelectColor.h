#if !defined(AFX_SELECTCOLOR_H__EBF5BAB2_0285_4674_A03C_2D9ED0118744__INCLUDED_)
#define AFX_SELECTCOLOR_H__EBF5BAB2_0285_4674_A03C_2D9ED0118744__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SelectColor.h : header file
//
#include "GradientCtrl.h"
#include "ColourPickerXP.h"
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CSelectColor dialog

class CSelectColor : public CAccessDialog//CDialog
{
// Construction
public:
	DECLARE_SERIAL(CSelectColor)
	CSelectColor(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSelectColor)
	enum { IDD = IDD_COLORRANGE };
	CSliderCtrl	m_trans;
	CSliderCtrl	m_filter;
	CGradientCtrl m_wndGradientCtrl;
	//}}AFX_DATA
BOOL m_usegradient;
virtual void Serialize(CArchive &ar);
COLORREF m_col;DWORD trans,filter;
	CColourPickerXP m_clb;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSelectColor)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSelectColor)
	virtual BOOL OnInitDialog();
	afx_msg void OnButton1();
	afx_msg void OnReleasedcaptureSlideFilter(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnReleasedcaptureSlideTrans(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	afx_msg void OnNotifyDoubleClickCreate(NMHDR * pNotifyStruct, LRESULT *result);
	afx_msg void OnNotifyChangeSelPeg(NMHDR * pNotifyStruct, LRESULT *result);
afx_msg LONG OnSelChange(UINT /*lParam*/, LONG /*wParam*/);

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SELECTCOLOR_H__EBF5BAB2_0285_4674_A03C_2D9ED0118744__INCLUDED_)
