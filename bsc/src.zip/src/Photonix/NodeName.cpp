// NodeName.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "NodeName.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNodeName dialog


CNodeName::CNodeName(CWnd* pParent /*=NULL*/)
	: CDialog(CNodeName::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNodeName)
	m_name = _T("");
	//}}AFX_DATA_INIT
}


void CNodeName::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNodeName)
	DDX_Text(pDX, IDC_NAME, m_name);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNodeName, CDialog)
	//{{AFX_MSG_MAP(CNodeName)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNodeName message handlers
