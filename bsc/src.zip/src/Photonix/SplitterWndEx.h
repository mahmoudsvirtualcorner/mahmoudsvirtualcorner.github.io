// SplitterWndEx.h : header file
//
// Written by Stephane Routelous (stephane.routelous@altavista.net)
// Copyright (c) 1999.
// All rights reserved
//
//
// Use and distribute freely, except: don't remove my name from the
// source or documentation (don't take credit for my work), mark your
// changes (don't get me blamed for your possible bugs), don't alter
// or remove this notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// This class extend the CSplitterWnd class from MFC with focus and 
// automatic split features.
//
// This class uses some code from someone , for OnDrawSplitter method.
// If you know who has writtent this code, send me a mail. I would like to add
// credit for his work.

#if !defined(AFX_SPLITTERWNDEX_H__C63D3EAD_3B6F_11D3_999B_0008C74FEAEC__INCLUDED_)
#define AFX_SPLITTERWNDEX_H__C63D3EAD_3B6F_11D3_999B_0008C74FEAEC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SplitterWndEx.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSplitterWndEx window

class CSplitterWndEx : public CSplitterWnd
{
public:
	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSplitterWndEx)
	//}}AFX_VIRTUAL

public:
	CSplitterWndEx();
	void RefreshSplitBars(void);

	BOOL DoKeyboardSplit();
	BOOL DoAutomaticSplit();

	bool m_bSplittingDone;
protected:
	void StartTracking(int ht);
	void StopTracking(BOOL bAccept);
	void OnDrawSplitter(CDC* pDC, ESplitType nType,	const CRect& rectArg);

	bool m_bIsAutomaticSplit;
	//{{AFX_MSG(CSplitterWndEx)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPLITTERWNDEX_H__C63D3EAD_3B6F_11D3_999B_0008C74FEAEC__INCLUDED_)
