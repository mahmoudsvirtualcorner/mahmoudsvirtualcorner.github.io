// FinishDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "FinishDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFinishDlg dialog
IMPLEMENT_SERIAL(CFinishDlg,CAccessDialog,1)


CFinishDlg::CFinishDlg(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CFinishDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFinishDlg)
	m_ambient = 0.1f;
	m_amount = 0.5f;
	m_brilliance = 5.7f;
	m_crand = 0.4f;
	m_diffuse = 0.6f;
	m_ref_enabled = FALSE;
	m_influence = 0.0f;
	m_irid_enabled = FALSE;
	m_metallic_enabled = FALSE;
	m_phong = 1.0f;
	m_phong_size = 25.0f;
	m_reflection = 0.5f;
	m_roughness = 0.0f;
	m_specular = 0.4f;
	m_thickness = 1.5f;
	m_turbulence_x = 0.1f;
	m_turbulence_y = 0.1f;
	m_turbulence_z = 0.1f;
	//}}AFX_DATA_INIT
}


void CFinishDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFinishDlg)
	DDX_Text(pDX, IDC_AMBIENT, m_ambient);
	DDV_MinMaxFloat(pDX, m_ambient, 0.f, 1.f);
	DDX_Text(pDX, IDC_AMOUNT, m_amount);
	DDV_MinMaxFloat(pDX, m_amount, 0.f, 1.f);
	DDX_Text(pDX, IDC_BRILLIANCE, m_brilliance);
	DDV_MinMaxFloat(pDX, m_brilliance, 0.f, 10.f);
	DDX_Text(pDX, IDC_CRAND, m_crand);
	DDX_Text(pDX, IDC_DIFFUSE, m_diffuse);
	DDV_MinMaxFloat(pDX, m_diffuse, 0.f, 1.f);
	DDX_Check(pDX, IDC_ENABLE_REFLECTION, m_ref_enabled);
	DDX_Text(pDX, IDC_INFLUENCE, m_influence);
	DDV_MinMaxFloat(pDX, m_influence, 0.f, 2.f);
	DDX_Check(pDX, IDC_IRIDESCENCE, m_irid_enabled);
	DDX_Check(pDX, IDC_METALLIC, m_metallic_enabled);
	DDX_Text(pDX, IDC_PHONG, m_phong);
	DDV_MinMaxFloat(pDX, m_phong, 0.f, 1.f);
	DDX_Text(pDX, IDC_PHONGSIZE, m_phong_size);
	DDV_MinMaxFloat(pDX, m_phong_size, 0.f, 100.f);
	DDX_Text(pDX, IDC_REFLECTION, m_reflection);
	DDV_MinMaxFloat(pDX, m_reflection, 0.f, 1.f);
	DDX_Text(pDX, IDC_ROUGHNESS, m_roughness);
	DDV_MinMaxFloat(pDX, m_roughness, 0.f, 1.f);
	DDX_Text(pDX, IDC_SPECULAR, m_specular);
	DDV_MinMaxFloat(pDX, m_specular, 0.f, 1.f);
	DDX_Text(pDX, IDC_THINKNESS, m_thickness);
	DDV_MinMaxFloat(pDX, m_thickness, 0.f, 2.f);
	DDX_Text(pDX, IDC_TURBULENCE_X, m_turbulence_x);
	DDV_MinMaxFloat(pDX, m_turbulence_x, 0.f, 2.f);
	DDX_Text(pDX, IDC_TURBULENCE_Y, m_turbulence_y);
	DDV_MinMaxFloat(pDX, m_turbulence_y, 0.f, 2.f);
	DDX_Text(pDX, IDC_TURBULENCE_Z, m_turbulence_z);
	DDV_MinMaxFloat(pDX, m_turbulence_z, 0.f, 2.f);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFinishDlg, CDialog)
	//{{AFX_MSG_MAP(CFinishDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFinishDlg message handlers
void CFinishDlg::Serialize(CArchive &ar)
{
	if(ar.IsStoring ())
	{
			ar<<	m_ambient<<m_amount<<m_brilliance<<m_crand<<m_diffuse<<m_ref_enabled<<m_influence<<m_irid_enabled<<		m_metallic_enabled<<m_phong<<m_phong_size<<m_reflection<<m_roughness<<m_specular<<m_thickness<<m_turbulence_x<<		m_turbulence_y<<m_turbulence_z;

	}
	else
	{
		ar>>	m_ambient>>m_amount>>m_brilliance>>m_crand>>m_diffuse>>m_ref_enabled>>m_influence>>m_irid_enabled>>		m_metallic_enabled>>m_phong>>m_phong_size>>m_reflection>>m_roughness>>m_specular>>m_thickness>>m_turbulence_x>>		m_turbulence_y>>m_turbulence_z;

	}

}


void CFinishDlg::Fill(FINISH *f)
{
	
Make_RGB(f->Ambient, m_ambient, m_ambient, m_ambient);
		Make_RGB(f->Reflection_Max, m_reflection, m_reflection,m_reflection);
		Make_RGB(f->Reflection_Min, m_reflection, m_reflection, m_reflection);
		
		f->Reflection_Type    = m_ref_enabled;
		f->Reflection_Falloff = 1;    // Added by MBP 8/27/98 
		f->Diffuse    = m_diffuse;
		f->Brilliance = m_brilliance;
		f->Phong      = m_phong;
		f->Phong_Size = m_phong_size;
		f->Specular   = m_specular;
		f->Roughness  = (m_roughness==0)? m_roughness :1.0 / m_roughness;
		
		f->Crand =m_crand;
		
		f->Metallic = m_influence;
		
		f->Irid                = m_amount;
		f->Irid_Film_Thickness = m_thickness;
		f->Irid_Turb           = m_turbulence_x;
		f->Temp_Caustics = -1.0;
		f->Temp_IOR     = -1.0;
		f->Temp_Dispersion  = 1.0;
		f->Temp_Refract =  1.0;
		f->Reflect_Exp  =  1.0;
		f->Reflect_Metallic = 0.0;
		// Added Dec 19 1999 by NK 
		f->Conserve_Energy = false;


Make_RGB(f->Reflection_Max, m_reflection,m_reflection,m_reflection);
Make_RGB(f->Reflection_Min, m_reflection,m_reflection,m_reflection);

}
/*//	BOOL	m_irid_enabled;
	//BOOL	m_metallic_enabled;
	float	m_reflection;
*/

BOOL CFinishDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
