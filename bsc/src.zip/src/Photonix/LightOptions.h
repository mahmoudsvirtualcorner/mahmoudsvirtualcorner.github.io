#if !defined(AFX_LIGHTOPTIONS_H__12D088C5_2D63_4015_8DA5_BF6BEC70E8D9__INCLUDED_)
#define AFX_LIGHTOPTIONS_H__12D088C5_2D63_4015_8DA5_BF6BEC70E8D9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LightOptions.h : header file
//
#include "AccessDialog.h"
#include "enggenclasses.h"
#include "ColourPickerXP.h"

/////////////////////////////////////////////////////////////////////////////
// CLightOptions dialog

class CLightOptions : public CAccessDialog//CDialog
{
// Construction
public:
	CLightOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLightOptions)
	enum { IDD = IDD_LIGHT_OPTIONS };
	BOOL	m_noshadow;
	BOOL	m_interaction;
	BOOL	m_attenuation;
	float	m_multiplier;
	//}}AFX_DATA

CColourPickerXP m_color;
LightSourceData *m_Obj;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLightOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLightOptions)
	afx_msg void OnShadowless();
	afx_msg void OnMediaAttenuation();
	afx_msg void OnMediaInteraction();
	afx_msg void OnKillfocusMultiplier();
	//}}AFX_MSG
	afx_msg LONG OnSelChange(UINT lParam, LONG wParam);

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LIGHTOPTIONS_H__12D088C5_2D63_4015_8DA5_BF6BEC70E8D9__INCLUDED_)
