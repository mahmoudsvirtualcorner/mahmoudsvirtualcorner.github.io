// SelectColor.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "SelectColor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSelectColor dialog
IMPLEMENT_SERIAL(CSelectColor,CAccessDialog,1)

CSelectColor::CSelectColor(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CSelectColor::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSelectColor)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_usegradient=true;
	trans=filter=0;
	m_col=RGB(0,0,0);
}


void CSelectColor::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSelectColor)
	DDX_Control(pDX, IDC_SLIDE_TRANS, m_trans);
	DDX_Control(pDX, IDC_SLIDE_FILTER, m_filter);
		DDX_Control(pDX, IDC_GRADIENT, m_wndGradientCtrl);
		DDX_Control(pDX, IDC_COLOR, m_clb);
	//}}AFX_DATA_MAP

}


BEGIN_MESSAGE_MAP(CSelectColor, CDialog)
	//{{AFX_MSG_MAP(CSelectColor)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDE_FILTER, OnReleasedcaptureSlideFilter)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SLIDE_TRANS, OnReleasedcaptureSlideTrans)
	//}}AFX_MSG_MAP
		ON_NOTIFY(GC_CREATEPEG, IDC_GRADIENT, OnNotifyDoubleClickCreate)
	ON_NOTIFY(GC_SELCHANGE, IDC_GRADIENT, OnNotifyChangeSelPeg)
ON_MESSAGE(CPN_SELCHANGE,    OnSelChange)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSelectColor message handlers

BOOL CSelectColor::OnInitDialog() 
{
	CDialog::OnInitDialog();
		m_filter.SetRange (0,10000);
	m_trans.SetRange (0,10000);

if (m_usegradient)
{
	//----- Setup the Gradient -----//
	CGradient &gradient = m_wndGradientCtrl.GetGradient();
//	gradient.SetEndPegColour(0x00FFFFFF);
//	gradient.SetStartPegColour(0x00000000);
	gradient.SetUseBackground(true);
	
	//----- Set the dialog's selection -----//
	LRESULT result;
	PegNMHDR nmhdr;
	nmhdr.nmhdr.code = 0;
	nmhdr.nmhdr.idFrom = 0;
	nmhdr.nmhdr.hwndFrom = 0;
	nmhdr.index = STARTPEG;
nmhdr.peg =gradient.GetPeg (STARTPEG);
	OnNotifyChangeSelPeg((NMHDR*) &nmhdr, &result);

}
else
{
		CGradient &gradient = m_wndGradientCtrl.GetGradient();
	gradient.SetEndPegColour  (m_col);
	gradient.SetStartPegColour(m_col);
	gradient.SetUseBackground(true);

m_filter.SetPos (filter);
m_trans.SetPos (trans);
m_wndGradientCtrl.EnableWindow (false);
}	
m_clb.SetRegSection();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSelectColor::OnNotifyDoubleClickCreate(NMHDR * pNotifyStruct, LRESULT *result)
{
	PegCreateNMHDR* pPegCreateNotifyStruct = (PegCreateNMHDR*)pNotifyStruct;
	
	UpdateData(TRUE);
	m_wndGradientCtrl.GetGradient().AddPeg(pPegCreateNotifyStruct->colour,
	pPegCreateNotifyStruct->position);
	m_wndGradientCtrl.Invalidate();

//	UpdateFirePalette();

	*result = 0;
}
void CSelectColor::Serialize(CArchive &ar)
{
	if(ar.IsStoring ())
	{
		ar<<m_usegradient;
	}
	else
	{
		ar>>m_usegradient;	
	}
	if(m_usegradient)
	{
		CGradient &gradient = m_wndGradientCtrl.GetGradient();
		
	/*	if(ar.IsStoring ())
		{
			ar<<m_wndGradientCtrl.m_StartPeg<<m_wndGradientCtrl.m_EndPeg<< m_wndGradientCtrl.m_Background;
		}
		else
		{
			ar>>m_wndGradientCtrl.m_StartPeg>>m_wndGradientCtrl.m_EndPeg>>m_wndGradientCtrl.m_Background;	
		}*/
		gradient.Serialize (ar);
	}
	else
	{
		if(ar.IsStoring ())
		{
			ar<<m_col<<trans<<filter;
		}
		else
		{
			ar>>m_col>>trans>>filter;
			
		}
	}
}

void CSelectColor::OnButton1() 
{
	srand(time(0));
if(m_usegradient)
{
	CGradient &gradient = m_wndGradientCtrl.GetGradient();
	int selindex = m_wndGradientCtrl.GetSelIndex();
	
	if(selindex != -1 && selindex > -4)
	{
		const CPeg &peg = gradient.GetPeg(selindex);
		gradient.SetPeg(selindex,RGB(rand()%255,rand()%255,rand()%255), peg.position);
		gradient.SetPeg(selindex,RGB(rand()%255,rand()%255,rand()%255), peg.position);
		gradient.SetPeg(selindex,RGB(rand()%255,rand()%255,rand()%255), peg.position);
	//	peg.
	}
	
//	gradient.SetBackgroundColour(m_BackgroundColour.GetColor());
}
else
{
		CGradient &gradient = m_wndGradientCtrl.GetGradient();
		gradient.SetPeg(STARTPEG,RGB(rand()%255,rand()%255,rand()%255), 0);
		gradient.SetPeg(ENDPEG,RGB(rand()%255,rand()%255,rand()%255), 0);
		gradient.SetPeg(BACKGROUND,RGB(rand()%255,rand()%255,rand()%255), 0);
m_col=RGB(rand()%255,rand()%255,rand()%255);
}

	m_wndGradientCtrl.Invalidate();
	
}

void CSelectColor::OnReleasedcaptureSlideFilter(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	if(m_usegradient)
	{
		CGradient &gradient = m_wndGradientCtrl.GetGradient();
		int selindex = m_wndGradientCtrl.GetSelIndex();
		if(selindex != -1 && selindex > -4)
		{
			const CPeg &peg = gradient.GetPeg(selindex);
			gradient.SetPegData(selindex,m_filter.GetPos (),m_trans.GetPos () );
			//	peg.
		}
	}
	else
	{
		filter=m_filter.GetPos ();
	}
	*pResult = 0;
}

void CSelectColor::OnReleasedcaptureSlideTrans(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	if(m_usegradient)
	{
		CGradient &gradient = m_wndGradientCtrl.GetGradient();
		int selindex = m_wndGradientCtrl.GetSelIndex();
		if(selindex != -1 && selindex > -4)
		{
			const CPeg &peg = gradient.GetPeg(selindex);
			gradient.SetPegData(selindex,m_filter.GetPos (),m_trans.GetPos () );
			//	peg.
		}
	}
	else
	{
		trans=m_trans.GetPos ();
	}
*pResult = 0;
}
void CSelectColor::OnNotifyChangeSelPeg(NMHDR * pNotifyStruct, LRESULT *result)
{
	PegNMHDR* pPegNotifyStruct = (PegNMHDR*)pNotifyStruct;
	m_filter.SetPos (pPegNotifyStruct->peg.filter);
	m_trans.SetPos (pPegNotifyStruct->peg.trans );
m_clb.SetColor (pPegNotifyStruct->peg.colour);
}
LONG CSelectColor::OnSelChange(UINT /*lParam*/, LONG /*wParam*/)
{
	//   TRACE0("Selection changed\n");
COLORREF c=m_clb.GetColor();
	if(m_usegradient)
	{
		CGradient &gradient = m_wndGradientCtrl.GetGradient();
		int selindex = m_wndGradientCtrl.GetSelIndex();

		if(selindex != -1 && selindex > -4)
		{
			const CPeg &peg = gradient.GetPeg(selindex);
			gradient.SetPeg(selindex,c, peg.position);
			gradient.SetPeg(selindex,c, peg.position);
			gradient.SetPeg(selindex,c, peg.position);
			//	peg.
		}

		//	gradient.SetBackgroundColour(m_BackgroundColour.GetColor());
	}
	else
	{
		CGradient &gradient = m_wndGradientCtrl.GetGradient();
		
		gradient.SetPeg(STARTPEG,c, 0);
		gradient.SetPeg(ENDPEG,c, 0);
		gradient.SetPeg(BACKGROUND,c, 0);
		m_col=c;
	}

	m_wndGradientCtrl.Invalidate();

    return TRUE;
}
