#if !defined(AFX_GLOBALSETTINGS_H__9D0FE35D_4F96_468A_943E_65094C6A6257__INCLUDED_)
#define AFX_GLOBALSETTINGS_H__9D0FE35D_4F96_468A_943E_65094C6A6257__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GlobalSettings.h : header file
//
#include "ColourPickerXP.h"

/////////////////////////////////////////////////////////////////////////////
// CGlobalSettings dialog

class CGlobalSettings : public CDialog
{
// Construction
public:
	CGlobalSettings(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGlobalSettings)
	enum { IDD = IDD_GLOBAL_SETTINGS };
	BOOL	m_16bit_hfield;
	float	m_adc_bailout;
	float	m_assumed_gamma;
	UINT	m_max_intersect;
	UINT	m_max_trace;
	UINT	m_n_of_waves;
	//}}AFX_DATA

	CColourPickerXP m_ambient,m_irid,m_backcolor;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGlobalSettings)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGlobalSettings)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GLOBALSETTINGS_H__9D0FE35D_4F96_468A_943E_65094C6A6257__INCLUDED_)
