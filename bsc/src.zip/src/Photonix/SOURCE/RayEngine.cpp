#include "rayengine.h"
// 3d raytrace engine includes
#include "frame.h"    // common to ALL modules in this program 
#include "povproto.h"
#include "bezier.h"
#include "bbox.h"
#include "cones.h"
#include "csg.h"
#include "discs.h"
#include "fractal.h"
#include "hfield.h"
#include "lathe.h"
#include "lighting.h"
#include "lightgrp.h"
#include "mesh.h"
#include "photons.h"
#include "polysolv.h"
#include "objects.h"
#include "octree.h"
#include "pigment.h"
#include "point.h"
#include "poly.h"
#include "polygon.h"
#include "povray.h"
#include "quadrics.h"
#include "prism.h"
#include "radiosit.h"
#include "render.h"
#include "sor.h"
#include "spheres.h"
#include "super.h"
#include "texture.h"
#include "torus.h"
#include "triangle.h"
#include "userio.h"
#include "userdisp.h"
#include "sphsweep.h"
#include "pov_util.h"
#include "warps.h"
#include "Pattern.h"
#include "helpers.h"
#include "colour.h"
#include "vector.h"

void IRayEngine::StartRendering()
{

	povray_render();//argc, argv

	// Finish 
	povray_terminate();

}
IRayEngine::IRayEngine(IScene* scene,ICamera* cam)
{
	 m_Scene=scene;
 m_Camera=cam;
SetRenderStatus=0;
SetProgressStatus=0;
}
IRayEngine::IRayEngine()
{
SetRenderStatus=0;
SetProgressStatus=0;
}

IRayEngine *RayEngine;