// RainbowOptions.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "RainbowOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRainbowOptions dialog
IMPLEMENT_SERIAL(CRainbowOptions,CAccessDialog,1)
CRainbowOptions::CRainbowOptions(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CRainbowOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRainbowOptions)
	m_falloff_angle = 42.5f;
	m_arc_angle = 42.5f;
	m_distance = 1.0e7f;
	m_falloff_width = 0.0f;
	m_right_x = 1.0f;
	m_right_y = 0.0f;
	m_right_z = 0.0f;
	m_up_x = 0.0f;
	m_up_y = 1.0f;
	m_up_z = 0.0f;
	m_width = 5.0f;
	m_angle = 42.5f;
	m_jitter = 0.01f;
	m_antisolar_x = -0.2f;
	m_antisolar_y = -0.2f;
	m_antisolar_z = 1.0f;
	//}}AFX_DATA_INIT
}


void CRainbowOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRainbowOptions)
	DDX_Text(pDX, IDC_FALLOFF_ANGLE, m_falloff_angle);
	DDV_MinMaxFloat(pDX, m_falloff_angle, 0.f, 360.f);
	DDX_Text(pDX, IDC_ARC_ANGLE, m_arc_angle);
	DDV_MinMaxFloat(pDX, m_arc_angle, 0.f, 360.f);
	DDX_Text(pDX, IDC_DISTANCE, m_distance);
	DDX_Text(pDX, IDC_FALLOFF_WIDTH, m_falloff_width);
	DDX_Text(pDX, IDC_JITTER, m_jitter);
	DDX_Text(pDX, IDC_RIGHT_X, m_right_x);
	DDX_Text(pDX, IDC_RIGHT_Y, m_right_y);
	DDX_Text(pDX, IDC_RIGHT_Z, m_right_z);
	DDX_Text(pDX, IDC_UP_X, m_up_x);
	DDX_Text(pDX, IDC_UP_Y, m_up_y);
	DDX_Text(pDX, IDC_UP_Z, m_up_z);
	DDX_Text(pDX, IDC_WIDTH, m_width);
	DDX_Text(pDX, IDC_ANGLE, m_angle);
	DDX_Text(pDX, IDC_ANTISOLAR_X, m_antisolar_x);
	DDX_Text(pDX, IDC_ANTISOLAR_Y, m_antisolar_y);
	DDX_Text(pDX, IDC_ANTISOLAR_Z, m_antisolar_z);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRainbowOptions, CDialog)
	//{{AFX_MSG_MAP(CRainbowOptions)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRainbowOptions message handlers
void CRainbowOptions::Serialize (CArchive &ar)
{
	if(ar.IsStoring ())
	{

	ar<<m_falloff_angle<<m_arc_angle<<m_antisolar_x<<m_antisolar_y<<m_antisolar_z<<m_distance<<m_falloff_width<<m_jitter<<m_right_x<<m_right_y<<m_right_z<<m_up_x<<m_up_y<<m_up_z<<m_width<<m_angle;


	}

	else
	{
		ar>>m_falloff_angle>>m_arc_angle>>m_antisolar_x>>m_antisolar_y>>m_antisolar_z>>m_distance>>m_falloff_width>>m_jitter>>m_right_x>>m_right_y>>m_right_z>>m_up_x>>m_up_y>>m_up_z>>m_width>>m_angle;
	}

}