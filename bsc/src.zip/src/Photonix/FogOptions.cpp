// FogOptions.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "FogOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFogOptions dialog


CFogOptions::CFogOptions(CWnd* pParent /*=NULL*/)
	: CDialog(CFogOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFogOptions)
	m_up_x = 0.0f;
	m_octaves = 6;
	m_up_y = 0.0f;
	m_up_z = 0.0f;
	m_turb_z = 0.0f;
	m_turb_y = 0.0f;
	m_turb_x = 0.0f;
	m_turb_depth = 0.0f;
	m_altitude = 0.0f;
	m_distance = 0.0f;
	m_fog_type = 0;
	m_lambda = 0.0f;
	m_offset = 0.0f;
	m_omega = 0.0f;
	m_filter = 0;
	m_trans = 0;
	//}}AFX_DATA_INIT
	cursel=-1;
}


void CFogOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFogOptions)
	DDX_Control(pDX, IDC_LIST, m_list);
	DDX_Text(pDX, IDC_UP_VECTOR_Z, m_up_x);
	DDX_Text(pDX, IDC_OCTAVES, m_octaves);
	DDV_MinMaxUInt(pDX, m_octaves, 1, 10);
	DDX_Text(pDX, IDC_UP_VECTOR_Y, m_up_y);
	DDX_Text(pDX, IDC_UP_VECTOR_X, m_up_z);
	DDX_Text(pDX, IDC_TURB_Z, m_turb_z);
	DDX_Text(pDX, IDC_TURB_Y, m_turb_y);
	DDX_Text(pDX, IDC_TURB_X, m_turb_x);
	DDX_Text(pDX, IDC_TURB_DEPTH, m_turb_depth);
	DDX_Text(pDX, IDC_ALTITUDE, m_altitude);
	DDX_Text(pDX, IDC_DISTANCE, m_distance);
	DDX_CBIndex(pDX, IDC_FOG_TYPE, m_fog_type);
	DDX_Text(pDX, IDC_LAMBDA, m_lambda);
	DDX_Text(pDX, IDC_OFFSET, m_offset);
	DDX_Text(pDX, IDC_OMEGA, m_omega);
	DDX_Slider(pDX, IDC_SLIDE_FILTER, m_filter);
	DDX_Slider(pDX, IDC_SLIDE_TRANS, m_trans);
	DDX_Control(pDX, IDC_COLOR, m_fogcolor);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFogOptions, CDialog)
	//{{AFX_MSG_MAP(CFogOptions)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_LBN_SELCHANGE(IDC_LIST, OnSelchangeList)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFogOptions message handlers

void CFogOptions::OnAdd() 
{
	// TODO: Add your control notification handler code here
	CWinFog * w=new CWinFog();
	
	m_list.GetCount ();
	int n=m_list.AddString ("Fog");
	m_objects.Add (w);
	m_list.SetCurSel(n);
	OnSelchangeList();

}

void CFogOptions::OnDelete() 
{
	// TODO: Add your control notification handler code here
	int getsel=m_list.GetCurSel();
	if(getsel!=-1)
	{
		delete m_objects.GetAt (getsel);
		m_objects.RemoveAt (getsel);
		m_list.DeleteString(getsel);
		cursel=-1;
	}
}

void CFogOptions::OnSelchangeList() 
{
	// TODO: Add your control notification handler code here

	{
		if(cursel!=-1)
		{
		CWinFog * w=(CWinFog *)m_objects.GetAt (cursel);
		UpdateFog(w);
		}
	}
	int getsel=m_list.GetCurSel();
	if(getsel!=-1)
	{
		cursel=getsel;
		CWinFog * w=(CWinFog *)m_objects.GetAt (getsel);
		FillWindow(w);
		
	}
}

void CFogOptions::FillWindow(CWinFog *w)
{
	m_up_x		=w->m_up_x;
	m_octaves	=w->m_octaves;
	m_up_y		=w->m_up_y;
	m_up_z		=w->m_up_z;
	m_turb_z	=w->m_turb_z;
	m_turb_y	=w->m_turb_y;
	m_turb_x	=w->m_turb_x;
	m_turb_depth=w->m_turb_depth;
	m_altitude	=w->m_altitude ;
	m_distance	=w->m_distance;
	m_lambda	=w->m_lambda;
	m_offset	=w->m_offset;
	m_omega		=w->m_omega;
	m_fog_type=w->m_fog_type;
m_trans=w->m_trans;
m_filter=w->m_filter;
m_fogcolor.SetColor (w->m_color );


	this->UpdateData (false);
}

void CFogOptions::UpdateFog(CWinFog *w)
{
	this->UpdateData (true);
	w->m_up_x=m_up_x;		
	w->m_octaves=m_octaves	;
	w->m_up_y=m_up_y		;
	w->m_up_z=m_up_z		;
	w->m_turb_z=m_turb_z	;
	w->m_turb_y=m_turb_y	;
	w->m_turb_x=m_turb_x	;
	w->m_turb_depth=m_turb_depth;
	w->m_altitude =m_altitude	;
	w->m_distance=m_distance	;
	w->m_lambda=m_lambda	;
	w->m_offset=m_offset	;
	w->m_omega=m_omega		;
	w->m_fog_type=m_fog_type;
w->m_trans=m_trans;
w->m_filter=m_filter;
w->m_color = m_fogcolor.GetColor ();
	
}

void CFogOptions::OnDestroy() 
{
	OnSelchangeList();
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	
}

BOOL CFogOptions::OnInitDialog() 
{
	CDialog::OnInitDialog();
	CSliderCtrl * ctrl=((CSliderCtrl *)this->GetDlgItem (IDC_SLIDE_FILTER));
	ctrl->SetRange (0,10000);
	ctrl=((CSliderCtrl *)this->GetDlgItem (IDC_SLIDE_TRANS));
	ctrl->SetRange (0,10000);


	m_fogcolor.SetColor (RGB(.6*255,.6*255,.6*255));
cursel=-1;
	int count =m_objects.GetSize ();
	for (int i=0;i<count;i++)
	{
		m_list.AddString ("Fog");
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
