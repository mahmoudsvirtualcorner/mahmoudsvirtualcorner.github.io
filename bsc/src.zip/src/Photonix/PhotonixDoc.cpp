// PhotonixDoc.cpp : implementation of the CPhotonixDoc class
//

#include "stdafx.h"
#include "Photonix.h"
//#include "Photonix.h"

#include "MainFrm.h"
#include "PhotonixDoc.h"
#include "PhotonixView.h"

#include "Timeline.h"

#include "PhotonixDoc.h"
#include "SphereMesh.h"
#include "TextureTreeParser.h"
#include "RenderProgress.h"

#include "ObjMaterialDlg.h"
#include "ObjPhotonDlg.h"
#include "LightPhotons.h"
#include "LightOptions.h"
#include "ObjectOptions.h"
#include "TorusOptions.h"
#include "CameraOptions.h"
#include "AreaLightOptions.h"
#include "SpotLightParams.h"
#include "ifsmodel.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPhotonixDoc
CRenderScene CPhotonixDoc::renderscene;
CSceneSettings CPhotonixDoc::m_Settings;
CPictureDialog CPhotonixDoc::RenderDlg;
CTexMakerDlg CPhotonixDoc::TextureEditor;
//CObjectsTree CPhotonixDoc::m_ObjectsTree;
extern CTextureTreeParser TreeParser;


void DescScene(IRayEngine* Eng);
void SetRenderSettings(IRayEngine*Eng);
void Display_Plot(int x, int y, int r, int g, int b, int a);

IMPLEMENT_DYNCREATE(CPhotonixDoc, CDocument)

BEGIN_MESSAGE_MAP(CPhotonixDoc, CDocument)
	//{{AFX_MSG_MAP(CPhotonixDoc)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_KEYFRAMES, OnReleasedcaptureKeyframes)
	ON_BN_CLICKED(IDC_ADDKEY, OnAddkey)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_ADD_SPHERE, OnAddSphere)
	ON_COMMAND(ID_RENDERING_RENDER, OnRenderingRender)
	ON_COMMAND(ID_RENDERING_MATERIALEDITOR, OnMaterialeditor)
	ON_COMMAND(ID_RENDERING_QUICKRENDER, OnQuickRender)
	ON_COMMAND(ID_VIEW_OBJECTTREE, OnViewObjectTree)
	ON_COMMAND(ID_SCENESETTINGS, OnSceneSettings)
	ON_COMMAND(ID_MANIPULATION_TRANSLATION, OnManipulationTranslation)
	ON_COMMAND(ID_MANIPULATION_ROTATION, OnManipulationRotation)
	ON_COMMAND(ID_MANIPULATION_SCALE, OnManipulationScale)
	ON_COMMAND(ID_ADD_TORUS, OnAddTorus)
	ON_COMMAND(ID_ADD_CONE, OnAddCone)
	ON_COMMAND(ID_ADD_CYLINDER, OnAddCylinder)
	ON_COMMAND(ID_ADD_BOX, OnAddBox)
	ON_COMMAND(ID_ADD_POINT_LIGHT, OnAddPointLight)
	ON_COMMAND(ID_EDIT_DELETE, OnEditDelete)
	ON_COMMAND(ID_CAMERAS_TARGETCAMERA, OnAddTargetcamera)
	ON_COMMAND(ID_IMPORT_3DSFILE, OnImport3dsfile)
	ON_COMMAND(ID_LIGHTSOURCES_SPOTLIGHT, OnAddSpotlight)
	ON_COMMAND(ID_IMPORT_IFSFILE, OnImportIfsfile)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPhotonixDoc construction/destruction

CPhotonixDoc::CPhotonixDoc()
{
	// TODO: add one-time construction code here
	MainApp=NULL;
	//DialogsCreated=false;
	m_CurScene=NULL;
	CameraSet=FALSE;
}

CPhotonixDoc::~CPhotonixDoc()
{
}

BOOL CPhotonixDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	//	TextureEditor.ShowWindow (SW_HIDE);

	if(this->MainApp==NULL)
	{
		this->MainApp =new CMyApplication ();
	}
	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)
	SetMainApp (this->MainApp);
	this->MainApp->Start ();
	m_CurScene=(SceneObj *)MainApp->mScenes ["Scene1"];
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CPhotonixDoc serialization

void CPhotonixDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPhotonixDoc diagnostics

#ifdef _DEBUG
void CPhotonixDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPhotonixDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPhotonixDoc commands

void CPhotonixDoc::DeleteContents()
{
	UpdateAllViews(NULL,2);
	//	CRenderScene CPhotonixDoc::renderscene;
	//	CSceneSettings *CPhotonixDoc::m_Settings;
	//	CPictureDialog *CPhotonixDoc::RenderDlg;
	//	CTexMakerDlg *CPhotonixDoc::TextureEditor;
	m_ObjectsTree.Reset();
	CMainFrame * mainfram =(CMainFrame*)AfxGetMainWnd();
	if(mainfram==mainfrm)
	{

		if(mainfrm->GetSafeHwnd ())
		{
			if(mainfrm->m_Commandpanel.GetSafeHwnd ())
			{
				if(mainfrm->m_Commandpanel.m_rollup.GetSafeHwnd ())
					mainfrm->m_Commandpanel.m_rollup.RemoveAllPages ();
			}
		}
	}
	
	//mainfrm->m_Commandpanel.m_rollup.RemoveAllPages ();
	if(TextureEditor.GetSafeHwnd ())
		TextureEditor.OnRemoveAll();
	TreeParser.FreeMaterials();
	// TODO: Add your specialized code here and/or call the base class
	if(this->MainApp!=NULL)
	{
		this->MainApp->CleanUp ();
		delete this->MainApp;
		this->MainApp=0;
		SetMainApp (0);
	}
	m_Selector=NULL;
	m_CurScene=NULL;
	CameraSet=false;

	int count =CPhotonixDoc::m_Settings.m_fogdlg.m_objects .GetSize ();
	for(int i=0;i<count;i++)
	{
		delete	CPhotonixDoc::m_Settings.m_fogdlg.m_objects [i];
	}
	CDocument::DeleteContents();
}

void CPhotonixDoc::OnAddSphere()
{
	SphereObj *sphere=new SphereObj();
	//	sphere->RayTextureName="cool";
	m_CurScene->AddRenderable (sphere->pRenderable);
	//this->RenderWnd .Invalidate (0);
	m_ObjectsTree.m_objtree.EnableWindow (false);
	HTREEITEM h=m_ObjectsTree.m_objtree.InsertItem (sphere->pRenderable->Name );
	SceneObjectData *pData=m_CurScene->AddSceneObject(sphere);//new SceneObjectData(OBJ_SPHERE,sphere);
	pData->hItem =h;
	m_ObjectsTree.m_objtree.SetItemData (h,(DWORD)pData);
	//putting the dialogs to be shown
	CObjMaterialDlg *MatDlg=new CObjMaterialDlg();
	MatDlg->m_Object =sphere;
CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	MatDlg->Create (IDD_OBJ_MATERIAL_NAME,&mainfrm->m_Commandpanel);
	sphere->OptionDialogs["CObjMaterialDlg"]=MatDlg;
	CObjPhotonDlg *Photondlg=new CObjPhotonDlg();
	Photondlg->m_Object =sphere;
	
	Photondlg->Create (IDD_OBJPHOTON,&mainfrm->m_Commandpanel);
	sphere->OptionDialogs["CObjPhotonDlg"]=Photondlg;

	CObjectOptions *ObjectOptiondlg=new CObjectOptions();
	ObjectOptiondlg->m_Object =sphere;
	ObjectOptiondlg->Create (IDD_OBJECT_OPTIONS,&mainfrm->m_Commandpanel);
	sphere->OptionDialogs["CObjectOptions"]=ObjectOptiondlg;


	
	m_ObjectsTree.m_objtree.EnableWindow (true);
	SetModifiedFlag ();
	/*	KeyFrame * key=sphere->m_TimeLine.createKeyFrame(0);
	//Matrix4 mat=sphere->Bounding.GetWorldTransform();
	Vector3 pos;
	pos.x=0 ;pos.y=0 ;pos.z=0 ;
	key->setTranslate(pos);

	KeyFrame * key1=sphere->m_TimeLine.createKeyFrame(50);
	//Matrix4 mat1=sphere->Bounding.GetWorldTransform();
	Vector3 pos1;
	pos1.x=-1 ;pos1.y=-1 ;pos1.z=-1 ;
	key1->setTranslate(pos1);

	KeyFrame * key2=sphere->m_TimeLine.createKeyFrame(100);
	//Matrix4 mat2=sphere->Bounding.GetWorldTransform();
	Vector3 pos2;
	pos2.x=-1.5 ;pos2.y=-1.5 ;pos2.z=-1.5 ;
	key1->setTranslate(pos2);

	*/
	this->UpdateAllViews (0,0,0);
}
int RenderFinished(IRayEngine*Eng)
{
	//CTexMakerDlg* dlg=(CTexMakerDlg*)Eng->m_Data;
	//dlg->StopRendering();
	/*if(Eng->m_Data)
	{
		CRenderProgress* dlg=(CRenderProgress*)	Eng->m_Data;
		//	dlg->SendMessage (WM_CLOSE,0,0);
		Eng->m_Data=0;
	//	if(dlg->m_hWnd )
	//		dlg->FinishDialog();//IDCANCEL
		//	delete dlg;
	}*/
	return 0;
}
/*class CMainFrame;
class CPhotonixView;*/
void SetRenderSatus(IRayEngine * Eng,char* status)
{
	CRenderProgress* dlg=(CRenderProgress*)	Eng->m_Data;
	dlg->SetStatus (status);
}
void SetProgressStatus(IRayEngine * Eng,char* status,int current,int total)
{
	CRenderProgress* dlg=(CRenderProgress*)	Eng->m_Data;
	dlg->SetStatus (status);
	dlg->SetProgress((int)((float)current/total*100));
}
CameraObj *CPhotonixDoc::GetCamera (CString CamName)
{
	CObject *object;
	if(m_CurScene->m_MapSceneObjects.Lookup (CamName,object))
	{
		return (CameraObj*)((SceneObjectData*)object)->pObject;
	}
	if(MainApp->mCameras.Lookup (CamName,object))
	{
		return (CameraObj*)object;
	}
	return 0;
}
UINT CPhotonixDoc::Render(LPVOID p)
{
	CRenderProgress* dlg=(CRenderProgress*)p;
	//	dc=dlg->GetDC ();
	//	CBitmap *b=new CBitmap();
	//	b->CreateCompatibleBitmap(dc,300,300);
	//	dc->SelectObject (b);
	SceneObj *scene=dlg->pDoc->m_CurScene;
	//ver .0
	//	CameraObj* cam=(CameraObj*)dlg->MainApp ->mCameras ["Camera1"];
	//ver .o1

	
	//	CameraObj* cam=(CameraObj*)((SceneObjectData*)dlg->pDoc->m_CurScene->m_MapSceneObjects [dlg->pDoc->RenderCameraName])->pObject;
CameraObj* cam=dlg->pDoc->GetCamera(dlg->pDoc->RenderCameraName);
	dlg->pDoc->CameraSet=false;

	//frame->GetActiveDocument ()->getfi
	RayEngine=new IRayEngine(scene,cam);
	RayEngine->DescScene =&DescScene;
	RayEngine->Display_Plot= &Display_Plot;
	RayEngine->ExitThread =&RenderFinished;
	RayEngine->ThreadFinished=&RenderFinished;
	RayEngine->SetRenderSettings =&SetRenderSettings;
	RayEngine->SetRenderStatus =&SetRenderSatus;
	RayEngine->SetProgressStatus=&SetProgressStatus;
	RayEngine->m_Data =dlg;
	RayEngine->StartRendering ();
	//	povray_init();
dlg->PostMessage (WM_USER_THREAD_FINISHED, 0, 0);
//	dlg->FinishDialog ();
	/*int argc=5;
	char a1[10]="a.pov",b1[10]="+w320",c1[10]="+h320";
	char a2[10]="raytest1",b2[60]="C:\\toot\\RayTest1\\debug\\raytest1.exe";
	char **argv=new char*[5];

	argv[0]=&b2[0];
	argv[1]=&(a2[0]);
	argv[2]=&a1[0];
	argv[3]=&b1[0];
	argv[4]=&c1[0];
	*/

	//	povray_render();//argc, argv

	//delete argv;
	// Finish 
	//	povray_terminate();

	//	delete b;
	//	Destroy_Textures( Default_Texture);
	//	delete texglobal;
	//	texglobal=NULL;
	//Default_Texture=NULL;
	delete RayEngine;
	return 0;
}

void Display_Plot(int x, int y, int r, int g, int b, int a)
{
	//	dc->SetPixel (x,y,RGB(r,g,b));

	CPhotonixDoc::RenderDlg.m_Window.Plot_Pixel(x,y ,r,g,b,a);
}
void DescScene(IRayEngine* Eng)
{
	//AfxMessageBox ("DESCSCENE START");
	/**********************************************************************/
	//	Frame.Camera=new CAMERA();
	Frame.Camera=Eng->m_Camera->GenerateCamera();
	Frame.Number_Of_Light_Sources = 0;  
	Frame.Light_Sources = NULL;
	Frame.Light_Group_Lights = NULL;
	Frame.Objects = NULL;
	Frame.Atmosphere_IOR = 1.0;
	Frame.Atmosphere_Dispersion = 1.0;
	Frame.Antialias_Threshold = opts.Antialias_Threshold;

	Make_Colour (Frame.Background_Colour,1,1,1);


	/* dmf -- the first is physically "more correct".  The second works better */
	/*   Make_Colour (Frame.Irid_Wavelengths, 0.70, 0.52, 0.48); */
	/*	Make_Colour (Frame.Irid_Wavelengths, 0.25, 0.18, 0.14);
	Make_Colour (Frame.Background_Colour, 0.0, 0.0, 0.0);
	Make_Colour (Frame.Ambient_Light, 1.0, 1.0, 1.0);
	*/	
	/* Init atmospheric stuff. [DB 12/94] */
	CPhotonixDoc::InitAtmosphericEffects();
	/*
	Frame.Atmosphere = NULL;

	Frame.Fog = NULL;
	*/  
	Frame.Rainbow = NULL;
	Frame.Skysphere = NULL;

	SKYSPHERE* s=(SKYSPHERE*)TreeParser.SkySpheres ["SS"];
	if(s)
		Frame.Skysphere = s->GetCopy ();;
	RAINBOW* r=(RAINBOW*)TreeParser.Rainbows ["R"];
	if(r)
		Frame.Rainbow= r->GetCopy ();
	/*********************************************************************/

	/////////////////////////////////////////
	//global settings

	//	opts.GammaFactor = 1/opts.DisplayGamma;
	//	opts.Options |= GAMMA_CORRECT; // turn on gamma correction 
	//	Max_Trace_Level = 5;
	//	Had_Max_Trace_Level = true;

	/* here were the global photon block*/

	/*	///////////////////////////////////
	DBL k1, k2, k3;
	DBL Direction_Length = 1.0, Up_Length, Right_Length, Handedness;
	VECTOR tempv;
	//	TRANSFORM Local_Trans;
	//	CAMERA *New;
	//	bool only_mods = false;
	/////////////////////////////////////////
	//#defing New
	double camlocation[3]={0,1,-4};
	//	double camdir[3]={0,0,1.6542};

	double camdlook[3]={0,2,0};
	//Compute_Translation_Transform
	//	double up[3]={0,0,1};


	//setting properties
	//	Frame.Camera=Create_Camera();
	Frame.Camera->Type=PERSPECTIVE_CAMERA;
	Frame.Camera->Angle=80;
	VNormalize(Frame.Camera->Direction, Frame.Camera->Direction);
	VLength (Right_Length, Frame.Camera->Right);
	Direction_Length = Right_Length / tan(Frame.Camera->Angle * M_PI_360)/2.0;
	VScaleEq(Frame.Camera->Direction, Direction_Length);
	///	Assign_Vector(Frame.Camera->Direction,camdir);
	Assign_Vector(Frame.Camera->Location,camlocation);
	//	Assign_Vector(Frame.Camera->Up,up);
	//	Assign_Vector(Frame.Camera->Sky ,up);


	///setting up look at
	VLength (Direction_Length, Frame.Camera->Direction);
	VLength (Up_Length,        Frame.Camera->Up);
	VLength (Right_Length,     Frame.Camera->Right);
	VCross  (tempv,            Frame.Camera->Up, Frame.Camera->Direction);
	VDot    (Handedness,       tempv,   Frame.Camera->Right);

	//	Parse_Vector (Frame.Camera->Direction);
	Assign_Vector(Frame.Camera->Direction,camdlook);

	Assign_Vector(Frame.Camera->Look_At, Frame.Camera->Direction);

	VSub          (Frame.Camera->Direction, Frame.Camera->Direction, Frame.Camera->Location);

	// Check for zero length direction vector.
	if (VSumSqr(Frame.Camera->Direction) < EPSILON)
	Error("Camera location and look_at point must be different.");

	VNormalize (Frame.Camera->Direction, Frame.Camera->Direction);

	// Save Right vector
	Assign_Vector (tempv, Frame.Camera->Right);

	VCross        (Frame.Camera->Right, Frame.Camera->Sky, Frame.Camera->Direction);

	// Avoid DOMAIN error (from Terry Kanakis)
	if((fabs(Frame.Camera->Right[X]) < EPSILON) &&
	(fabs(Frame.Camera->Right[Y]) < EPSILON) &&
	(fabs(Frame.Camera->Right[Z]) < EPSILON))
	{
	// Restore Right vector
	Assign_Vector (Frame.Camera->Right, tempv);
	}

	VNormalize (Frame.Camera->Right,     Frame.Camera->Right);
	VCross     (Frame.Camera->Up,        Frame.Camera->Direction, Frame.Camera->Right);
	VScale     (Frame.Camera->Direction, Frame.Camera->Direction, Direction_Length);

	if (Handedness > 0.0)
	VScaleEq (Frame.Camera->Right, Right_Length)
	else
	VScaleEq (Frame.Camera->Right, -Right_Length);

	VScaleEq(Frame.Camera->Up, Up_Length);
	////post
	// Make sure the focal distance hasn't been explicitly given
	if (Frame.Camera->Focal_Distance < 0.0)
	Frame.Camera->Focal_Distance = Direction_Length;
	if (Frame.Camera->Focal_Distance == 0.0)
	Frame.Camera->Focal_Distance = 1.0;

	// Print a warning message if vectors are not perpendicular. [DB 10/94]
	VDot(k1, Frame.Camera->Right, Frame.Camera->Up);
	VDot(k2, Frame.Camera->Right, Frame.Camera->Direction);
	VDot(k3, Frame.Camera->Up, Frame.Camera->Direction);

	if ((fabs(k1) > EPSILON) || (fabs(k2) > EPSILON) || (fabs(k3) > EPSILON))
	{
	Warning(0, "Camera vectors are not perpendicular.\n"
	"Making look_at the last statement may help.");
	}
	*/
	////////////////////////////////////////////
	//light vectors;
	/*		double lightcenter[3]={2,2,- 2};
	float lightcolor[5]={1,1,1,0,0};
	DBL Len;
	//desc lights
	LIGHT_SOURCE *Object;
	Object = new LIGHT_SOURCE;//Create_Light_Source ();
	Assign_Vector(Object->Center,lightcenter);
	Assign_Colour(Object->Colour,lightcolor);

	//Object->Fade_Distance=20;
	//Object-> Fade_Power=2;				

	VSub(Object->Direction, Object->Points_At, Object->Center);

	VLength(Len, Object->Direction);

	if (Len > EPSILON)
	{
	VInverseScaleEq(Object->Direction, Len);
	}

	// Make sure that circular light sources are larger than 1 by x [ENB 9/97] 
	if (Object->Circular)
	{
	if ((Object->Area_Size1 <= 1) || (Object->Area_Size2 <= 1))
	{
	Error("Circular area light must have more than 1 point per axis");
	}
	}
	//photon mapping instructions
	if(1)// REFRACTION_TOKEN
	{ 
	Set_Flag(Object, PH_RFR_ON_FLAG); 
	Clear_Flag(Object, PH_RFR_OFF_FLAG); 
	}
	else
	{ 
	Clear_Flag(Object, PH_RFR_ON_FLAG); 
	Set_Flag(Object, PH_RFR_OFF_FLAG); 
	}
	if(1)// REFLECTION_TOKEN
	{ 
	Set_Flag(Object, PH_RFL_ON_FLAG); 
	Clear_Flag(Object, PH_RFL_OFF_FLAG); 
	}
	else
	{
	Clear_Flag(Object, PH_RFL_ON_FLAG); 
	Set_Flag(Object, PH_RFL_OFF_FLAG); 
	}
	if(0)// AREA_LIGHT_TOKEN
	Object->Photon_Area_Light = true;

	Post_Process (Object, NULL);
	Link_To_Frame (Object);
	*/
	////////////////////////////////////////////
	//plane vectors
	double planevector[3]={0, 0, 1};
	//float color[5]={1,1,1,0,0};
	DBL len;
	//desc objects
	PLANE *Object1;
	Object1 = new PLANE;//Create_Plane();
	Assign_Vector(Object1->Normal_Vector,planevector);

	VLength(len, Object1->Normal_Vector);
	if (len < EPSILON)
	{
		Error("Degenerate plane normal.");
	}
	VInverseScaleEq(Object1->Normal_Vector, len);
	Object1->Distance =0;

	Compute_Plane_BBox(Object1);
	Object1->Type |= TEXTURED_OBJECT;
	// define a new texture;
	TEXTURE *tex1 =new TEXTURE();//Create_Texture();

	tex1->Pigment = new PIGMENT();//Create_Pigment();
	tex1->Tnormal =NULL;// new TNORMAL();
	tex1->Finish  = new FINISH ();//Create_Finish();
	//tex1->Pigment->Type = PLAIN_PATTERN;
	//Assign_Colour(tex1->Pigment->Colour,color);

	tex1->Pigment->Type = CHECKER_PATTERN;
	tex1->Pigment->Frequency = 0.0;
	Destroy_Blend_Map(tex1->Pigment->Blend_Map);
	///parsing blend list

	float Colour1[5]={1,1,1,0,0};
	float Colour2[5]={.2,1,.2,0,0};
	BLEND_MAP *New;
	BLEND_MAP_ENTRY *Temp_Ent;

	Temp_Ent = Create_BMap_Entries(2);
	//Temp_Ent[0].Vals.Pigment=new PIGMENT();
	//Assign_Colour(Temp_Ent[0].Vals.Pigment->Colour,Colour1);
	Assign_Colour(Temp_Ent[0].Vals.Colour,Colour1);
	Temp_Ent[0].value = (SNGL)0;

	//Temp_Ent[1].Vals.Pigment=new PIGMENT();
	//Assign_Colour(Temp_Ent[1].Vals.Pigment->Colour,Colour2);
	Assign_Colour(Temp_Ent[1].Vals.Colour,Colour2);

	Temp_Ent[1].value = (SNGL)1;

	New = Create_Blend_Map ();
	New->Number_Of_Entries = 2;
	New->Type=COLOUR_TYPE;
	// New->Transparency_Flag=true; //Temp fix.  Really set in Post_???
	New->Blend_Map_Entries = Temp_Ent;
	tex1->Pigment->Blend_Map=New;


	///////////CHECKER
	/*	tex1->Tnormal->Type = CHECKER_PATTERN;
	tex1->Tnormal->Frequency = 0.0;	
	Destroy_Blend_Map(tex1->Tnormal->Blend_Map);		
	*/	
	Link_Textures(&(Object1->Texture), tex1);

	Post_Process (Object1, NULL);//used next object
	Link_To_Frame (Object1);

	//////////////////////////////////////////////

	/*
	BOX *Object4 = new BOX;//Create_Box();
	DBL temp;

	//  Parse_Vector(Object->bounds[0]);     Parse_Comma();
	//  Parse_Vector(Object->bounds[1]);
	Make_Vector(Object4->bounds[0],-1,-1,1);
	Make_Vector(Object4->bounds[1],1,1,-1);
	if (Object4->bounds[0][X] > Object4->bounds[1][X]) {
	temp = Object4->bounds[0][X];
	Object4->bounds[0][X] = Object4->bounds[1][X];
	Object4->bounds[1][X] = temp;
	}
	if (Object4->bounds[0][Y] > Object4->bounds[1][Y]) {
	temp = Object4->bounds[0][Y];
	Object4->bounds[0][Y] = Object4->bounds[1][Y];
	Object4->bounds[1][Y] = temp;
	}
	if (Object4->bounds[0][Z] > Object4->bounds[1][Z]) {
	temp = Object4->bounds[0][Z];
	Object4->bounds[0][Z] = Object4->bounds[1][Z];
	Object4->bounds[1][Z] = temp;
	}

	Compute_Box_BBox(Object4);

	Object1->Type |= TEXTURED_OBJECT;*/


	//aiz mod 1,22,2004		
	/*		double center[3]={0,0,0};
	float color1[5]={.75,.75,.75,0,0};
	SPHERE*Object4;
	Object4=new SPHERE();//Create_Sphere();
	Assign_Vector(Object4->Center,center);
	Object4->Radius=.5;

	Compute_Sphere_BBox(Object4);  

	Object4->Type |= TEXTURED_OBJECT;

	//goto toolacs:
	Object4->Interior=TreeParser.GetInterior("Material1");
	if(Object4->Interior)
	{
	Set_Flag(Object4,HOLLOW_FLAG);
	Set_Flag (Object4, HOLLOW_SET_FLAG);
	}
	Link_Textures(&(Object4->Texture),TreeParser.GetTexture ("Material1"));
	Post_Process (Object4, NULL);//used next object
	Link_To_Frame (Object4);
	*/
	Eng->m_Scene->GenerateScene ();
	//				Post_Process (Object4, NULL);//used next object
	//				Link_To_Frame (Object4);
	//AfxMessageBox ("DESCSCENE END");
}
void SetRenderSettings(IRayEngine*Eng)
{
	CRenderScene &rs=CPhotonixDoc::renderscene;
	if(rs.m_antialiasing )
		opts.Options |= ANTIALIAS;
	opts.Tracing_Method=rs.m_sampling_method ;
	opts.Antialias_Threshold=rs.m_threshold ;
	opts.AntialiasDepth=rs.m_depth ;
	opts.Quality=9;
	CPhotonixDoc::RenderDlg.m_Window.SetPictureRect(CRect (0,0,rs.m_width ,rs.m_height ));
	Frame.Screen_Width  = rs.m_width ;
	Frame.Screen_Height = rs.m_height ;


	if(rs.m_jitter )
		opts.Options |= JITTER;
	opts.JitterScale=rs.m_jitter ;

	if(rs.m_mosaic )
	{
		opts.PreviewGridSize_Start=rs.m_start ;
		opts.PreviewGridSize_End=rs.m_stop ;
	}
}
void CPhotonixDoc::InitAtmosphericEffects()
{
	if(CPhotonixDoc::m_Settings.m_mediadlg.m_selMedia !="")
	{
		Frame.Atmosphere =Copy_Media ((IMEDIA*) TreeParser .Medias [CPhotonixDoc::m_Settings.m_mediadlg.m_selMedia]);
	}
	//	Frame.Atmosphere = NULL;
	CObArray & arr= CPhotonixDoc::m_Settings.m_fogdlg .m_objects ;
	FOG  *Fog;
	int count=arr.GetSize ();

	for(int i=0;i<count;i++)
	{

		Fog =new FOG();//= Parse_Fog();
		CWinFog * winfog=(CWinFog *)arr[i];
		//copy the window layer fog to the engine fog
		{
			Make_ColourA(Fog->Colour,
				GetRValue(winfog->m_color)/255.0,GetGValue(winfog->m_color)/255.0,
				GetBValue(winfog->m_color)/255.0,winfog->m_filter  /10000.0,
				winfog->m_trans/10000.0 );
			Fog->Distance=winfog->m_distance ;
			Fog->Type=winfog->m_fog_type ;
			Fog->Alt =winfog->m_altitude ;
			Fog->Offset=winfog->m_offset ;

			Make_Vector(Fog->Up,winfog->m_up_x ,winfog->m_up_y,winfog->m_up_z);


			if(winfog->m_turb_x !=0 || winfog->m_turb_y!=0 || winfog->m_turb_z!=0)
			{
				Fog->Turb=(TURB *)Create_Warp(CLASSIC_TURB_WARP);
				Make_Vector(Fog->Turb->Turbulence,winfog->m_turb_x ,winfog->m_turb_y,winfog->m_turb_z);
				Fog->Turb_Depth=winfog->m_turb_depth ;
				Fog->Turb->Octaves =winfog->m_octaves ;
				Fog->Turb->Omega =winfog->m_omega ;
				Fog->Turb->Lambda=winfog->m_lambda ;
			}
			VNormalize(Fog->Up, Fog->Up);
		}



		Fog->Next = Frame.Fog;
		Frame.Fog = Fog;
	}

	//setting the radiosity
	if(CPhotonixDoc::renderscene.m_use_radiosity )
	{
		opts.Radiosity_Enabled=true;
		opts.Radiosity_Brightness=CPhotonixDoc::m_Settings.m_raddlg .m_brightness ;
		opts.Radiosity_Count=CPhotonixDoc::m_Settings.m_raddlg .m_count ;
		opts.Radiosity_Dist_Max =CPhotonixDoc::m_Settings.m_raddlg.m_dist_max ;
		opts.Radiosity_Error_Bound =CPhotonixDoc::m_Settings.m_raddlg.m_err_bound ;
		opts.Radiosity_Gray=CPhotonixDoc::m_Settings.m_raddlg.m_gray_threshold ;
		opts.Radiosity_Low_Error_Factor=CPhotonixDoc::m_Settings.m_raddlg.m_lowerror_factor ;
		opts.Radiosity_Min_Reuse=CPhotonixDoc::m_Settings.m_raddlg.m_min_reuse ;
		opts.Radiosity_Nearest_Count=CPhotonixDoc::m_Settings.m_raddlg.m_nearest_count ;
		opts.Radiosity_Recursion_Limit=CPhotonixDoc::m_Settings.m_raddlg.m_rec_limit ;
		opts.Radiosity_ADC_Bailout=0.01/2;

	}

	//setting the global options
	DBL AssumedGamma;
	AssumedGamma = CPhotonixDoc::m_Settings.m_globaldlg .m_assumed_gamma ;

	if (fabs(AssumedGamma - opts.DisplayGamma) < 0.1)
	{
		opts.GammaFactor = 1.0;
		opts.Options &= ~GAMMA_CORRECT; // turn off gamma correction 
	}
	else
	{
		opts.GammaFactor = AssumedGamma/opts.DisplayGamma;
		opts.Options |= GAMMA_CORRECT; // turn on gamma correction 
	}

	ADC_Bailout=CPhotonixDoc::m_Settings.m_globaldlg .m_adc_bailout ;
	Max_Trace_Level=CPhotonixDoc::m_Settings.m_globaldlg .m_max_trace ;

	Number_Of_Waves=CPhotonixDoc::m_Settings.m_globaldlg .m_n_of_waves ;
	Max_Intersections=CPhotonixDoc::m_Settings.m_globaldlg.m_max_intersect ;
	//CTexMakerDlg::m_Settings.m_globaldlg.m_backcolor 
	if(CPhotonixDoc::m_Settings.m_globaldlg.m_16bit_hfield )
	{
		opts.Options |= HF_GRAY_16;
	}
	COLORREF R=CPhotonixDoc::m_Settings.m_globaldlg.m_irid.GetColor () ;
	Make_Colour(Frame.Irid_Wavelengths,
		GetRValue(R)/255.0,GetGValue(R)/255.0,
		GetBValue(R)/255.0);
	R=CPhotonixDoc::m_Settings.m_globaldlg.m_ambient .GetColor ();
	Make_Colour(Frame.Ambient_Light,
		GetRValue(R)/255.0,GetGValue(R)/255.0,
		GetBValue(R)/255.0);
	R=CPhotonixDoc::m_Settings.m_globaldlg.m_backcolor.GetColor ();
	Make_Colour(Frame.Background_Colour,
		GetRValue(R)/255.0,GetGValue(R)/255.0,
		GetBValue(R)/255.0);
	CPhotonMappingOptions & photondlg= CPhotonixDoc::m_Settings.m_pmdialog;
	//global photon mapping block instructions
	if(photondlg.m_usepm)
	{
		//	photonOptions.surfaceSeparation = 0.02;
		if(photondlg.m_usespacing )
			photonOptions.surfaceSeparation=photondlg.m_spacing;
		else
			photonOptions.surfaceCount =photondlg.m_photoncount ;
		// max_gather_count = 0  means no photon maps 
		if (photonOptions.maxGatherCount > 0)
			photonOptions.photonsEnabled = true;
		else
			photonOptions.photonsEnabled = false;

		if(photonOptions.photonsEnabled)
		{
			photonOptions.jitter=photondlg.m_jitter ;
			photonOptions.Max_Trace_Level=photondlg.m_maxtracelevel ;
			photonOptions.ADC_Bailout=photondlg.m_adcbailout ;
			if(photondlg.m_usefile )
			{
				int length=photondlg.m_filename.GetLength ();
				if(photondlg.m_save )//save photons
				{
					photonOptions.fileName = photondlg.m_filename.GetBuffer (length );
					photonOptions.loadFile = false;
					photondlg.m_filename.ReleaseBuffer (length);
				}
				else //load photons
				{
					photonOptions.fileName =photondlg.m_filename.GetBuffer ( length);
					photonOptions.loadFile = true;
					photondlg.m_filename.ReleaseBuffer (length);

				}
			}
			if(photondlg.m_mediaphoton )
			{
				photonOptions.maxMediaSteps=100;
				photonOptions.mediaSpacingFactor =1.0;
			}
			/*	// check for range errors 
			if (photonOptions.minGatherCount < 0)
			Error("min_gather_count cannot be negative.");
			if (photonOptions.maxGatherCount < 0)
			Error("max_gather_count cannot be negative.");
			if (photonOptions.minGatherCount > photonOptions.maxGatherCount)
			Error("min_gather_count must be less than max_gather_count.");
			*/

		}


		if((photonOptions.photonsEnabled == false) && (opts.Quality < 9))
		{
			photonOptions.photonsEnabled = false;
			//	Warning(0, "A photons{}-block has been found but photons remain disabled because\n"
			//		"the output quality is set to 8 or less.");
		}

	}

}
void CPhotonixDoc::OnRenderingRender()
{
//	renderscene.Cameras =&MainApp->mCameras;
renderscene.Cameras .RemoveAll ();
CMainFrame * frame =(CMainFrame*)AfxGetMainWnd();
if(frame==mainfrm)
{
	CPhotonixView * actview=(CPhotonixView *)frame->GetActiveView (); 
	if(!actview){ AfxMessageBox("There is no Active View");return;}
CPhotonixView *cview=(CPhotonixView *) frame->m_wndSplitter.GetPane(0,0);
renderscene.Cameras.Add (cview->RenderWnd-> m_CurCamera->Name);
cview=(CPhotonixView *) frame->m_wndSplitter.GetPane(0,1);
renderscene.Cameras.Add (cview->RenderWnd->m_CurCamera->Name);
cview=(CPhotonixView *) frame->m_wndSplitter.GetPane(1,0);
renderscene.Cameras.Add (cview->RenderWnd->m_CurCamera->Name);
cview=(CPhotonixView *) frame->m_wndSplitter.GetPane(1,1);
renderscene.Cameras.Add (cview->RenderWnd->m_CurCamera->Name);
	renderscene.SelectedCameraName =actview->RenderWnd ->m_CurCamera->Name ;


	if(renderscene.DoModal ()==IDC_RENDER)
	{
		RenderCameraName=renderscene.SelectedCameraName ;
		CameraSet=true;
		OnQuickRender();
	}	
}
else
{
	//AfxMessageBox("Please Specify An active Window");
	AfxMessageBox("This Must not Happen!!!>>");

}
}

void CPhotonixDoc::OnMaterialeditor()
{
	TextureEditor.ShowWindow (SW_SHOW);

}

void CPhotonixDoc::OnQuickRender()
{
	if(!CameraSet)
	{
		CMainFrame * frame =(CMainFrame*)AfxGetMainWnd();
		if(frame==mainfrm)
		{
		CPhotonixView * actview=(CPhotonixView *)frame->GetActiveView ();
		if(!actview){ AfxMessageBox("There is no Active View");return;}

		RenderCameraName=actview->RenderWnd->m_CurCamera->Name ;
		}
		else
		{
			AfxMessageBox("This Must not Happen!!!>>");
		}
	}
	//saving every thing
	TextureEditor.GenerateTexture();



	//w=	
	CRenderProgress dlg(AfxGetMainWnd ());//=new CRenderProgress();
	dlg.pDoc =this;
	//dlg->Create(IDD_RENDERPROGRESS,NULL);
	dlg.m_viewport =RenderCameraName;
	CString s;
	s.Format ("%d", CPhotonixDoc::renderscene.m_width);
	dlg.m_width = s;
	s.Format ("%d", CPhotonixDoc::renderscene.m_height);

	dlg.m_height =s ;

	if(CPhotonixDoc::renderscene.m_antialiasing)
	{
		dlg.m_antialiasing ="True";
	}
	else
	{
		dlg.m_antialiasing ="False";
	}

	if(CPhotonixDoc::m_Settings .m_mediadlg.m_MediaEnabled)
	{
		dlg.m_useparticipatingmedia ="True";
	}
	else
	{
		dlg.m_useparticipatingmedia ="False";
	}
	if(CPhotonixDoc::m_Settings .m_pmdialog .m_usepm )
	{
		dlg.m_usephoton  ="True";
	}
	else
	{
		dlg.m_usephoton ="False";
	}
	s.Format ("%d",m_CurScene ->GetLightCount ());
	dlg.m_numlights =s;
	s.Format ("%d",m_CurScene ->GetObjectsCount ());

	dlg.m_numobjects =s;

	dlg.DoModal ();
}

void CPhotonixDoc::OnViewObjectTree()
{
	m_ObjectsTree.ShowWindow (SW_SHOW);
}

void CPhotonixDoc::OnSceneSettings()
{
	//TreeParser.GenerateTexture ();
	CPhotonixDoc::TextureEditor.GenerateTexture();
	CPhotonixDoc::m_Settings.m_mediadlg .Medias=&TreeParser.Medias ;
	CPhotonixDoc::m_Settings.DoModal ();	//.Create (IDD_SCENE_SETTINGS,NULL);
}

void CPhotonixDoc::OnManipulationTranslation()
{
	m_Selector ->mCurToolType=1;
	m_Selector->ReInitialize ();
}

void CPhotonixDoc::OnManipulationRotation()
{
	m_Selector ->mCurToolType=2;
	m_Selector->ReInitialize ();
}

void CPhotonixDoc::OnManipulationScale()
{
	m_Selector ->mCurToolType=3;
	m_Selector->ReInitialize ();
}

void CPhotonixDoc::OnAddTorus()
{
	TorusObj *torus=new TorusObj();
	//	sphere->RayTextureName="cool";
	m_CurScene->AddRenderable (torus->pRenderable);
	m_ObjectsTree.m_objtree.EnableWindow (false);
	HTREEITEM h=m_ObjectsTree.m_objtree.InsertItem (torus->pRenderable->Name );
	SceneObjectData *pData=m_CurScene->AddSceneObject(torus);//new SceneObjectData(OBJ_TORUS,torus);
	pData->hItem =h;
	m_ObjectsTree.m_objtree.SetItemData (h,(DWORD)pData);
	//putting the dialogs to be shown
	CObjMaterialDlg *MatDlg=new CObjMaterialDlg();
	MatDlg->m_Object =torus;
CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	MatDlg->Create (IDD_OBJ_MATERIAL_NAME,&mainfrm->m_Commandpanel);
	torus->OptionDialogs["CObjMaterialDlg"]=MatDlg;
	CObjPhotonDlg *Photondlg=new CObjPhotonDlg();
	Photondlg->m_Object =torus;
	Photondlg->Create (IDD_OBJPHOTON,&mainfrm->m_Commandpanel);
	torus->OptionDialogs["CObjPhotonDlg"]=Photondlg;

	CObjectOptions *ObjectOptiondlg=new CObjectOptions();
	ObjectOptiondlg->m_Object =torus;
	ObjectOptiondlg->Create (IDD_OBJECT_OPTIONS,&mainfrm->m_Commandpanel);
	torus->OptionDialogs["CObjectOptions"]=ObjectOptiondlg;


	CTorusOptions *torusOptiondlg=new CTorusOptions();
	torusOptiondlg->m_Object =torus;
	torusOptiondlg->Create (IDD_TORUSOPTIONS,&mainfrm->m_Commandpanel);
	torus->OptionDialogs["CTorusOptions"]=torusOptiondlg;

	
	m_ObjectsTree.m_objtree.EnableWindow (true);
	SetModifiedFlag ();
	this->UpdateAllViews (0,0,0);
}

void CPhotonixDoc::OnAddCone()
{
	ConeObj *cone=new ConeObj();
	//	sphere->RayTextureName="cool";
	m_CurScene->AddRenderable (cone->pRenderable);
	m_ObjectsTree.m_objtree.EnableWindow (false);
	HTREEITEM h=m_ObjectsTree.m_objtree.InsertItem (cone->pRenderable->Name );
	SceneObjectData *pData=m_CurScene->AddSceneObject(cone);//new SceneObjectData(OBJ_CONE,cone);
	pData->hItem =h;
	m_ObjectsTree.m_objtree.SetItemData (h,(DWORD)pData);
	//putting the dialogs to be shown
	CObjMaterialDlg *MatDlg=new CObjMaterialDlg();
	MatDlg->m_Object =cone;
	CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	MatDlg->Create (IDD_OBJ_MATERIAL_NAME,&mainfrm->m_Commandpanel);
	cone->OptionDialogs["CObjMaterialDlg"]=MatDlg;
	CObjPhotonDlg *Photondlg=new CObjPhotonDlg();
	Photondlg->m_Object =cone;
	Photondlg->Create (IDD_OBJPHOTON,&mainfrm->m_Commandpanel);
	cone->OptionDialogs["CObjPhotonDlg"]=Photondlg;

	CObjectOptions *ObjectOptiondlg=new CObjectOptions();
	ObjectOptiondlg->m_Object =cone;
	ObjectOptiondlg->Create (IDD_OBJECT_OPTIONS,&mainfrm->m_Commandpanel);
	cone->OptionDialogs["CObjectOptions"]=ObjectOptiondlg;
	
	m_ObjectsTree.m_objtree.EnableWindow (true);
	SetModifiedFlag ();
	this->UpdateAllViews (0,0,0);
}

void CPhotonixDoc::OnAddCylinder()
{
	CylinderObj *cylinder=new CylinderObj();
	//	sphere->RayTextureName="cool";
	m_CurScene->AddRenderable (cylinder->pRenderable);
	m_ObjectsTree.m_objtree.EnableWindow (false);
	HTREEITEM h=m_ObjectsTree.m_objtree.InsertItem (cylinder->pRenderable->Name );
	SceneObjectData *pData=m_CurScene->AddSceneObject(cylinder);//new SceneObjectData(OBJ_CYLINDER,cylinder);
	pData->hItem =h;
	m_ObjectsTree.m_objtree.SetItemData (h,(DWORD)pData);
	//putting the dialogs to be shown
	CObjMaterialDlg *MatDlg=new CObjMaterialDlg();
	MatDlg->m_Object =cylinder;
	CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	MatDlg->Create (IDD_OBJ_MATERIAL_NAME,&mainfrm->m_Commandpanel);
	cylinder->OptionDialogs["CObjMaterialDlg"]=MatDlg;
	CObjPhotonDlg *Photondlg=new CObjPhotonDlg();
	Photondlg->m_Object =cylinder;
	Photondlg->Create (IDD_OBJPHOTON,&mainfrm->m_Commandpanel);
	cylinder->OptionDialogs["CObjPhotonDlg"]=Photondlg;

	CObjectOptions *ObjectOptiondlg=new CObjectOptions();
	ObjectOptiondlg->m_Object =cylinder;
	ObjectOptiondlg->Create (IDD_OBJECT_OPTIONS,&mainfrm->m_Commandpanel);
	cylinder->OptionDialogs["CObjectOptions"]=ObjectOptiondlg;

	
	m_ObjectsTree.m_objtree.EnableWindow (true);
	SetModifiedFlag ();
	this->UpdateAllViews (0,0,0);

}

void CPhotonixDoc::OnAddBox()
{
	BoxObj *box=new BoxObj();
	//	sphere->RayTextureName="cool";
	m_CurScene->AddRenderable (box->pRenderable);
	m_ObjectsTree.m_objtree.EnableWindow (false);
	HTREEITEM h=m_ObjectsTree.m_objtree.InsertItem (box->pRenderable->Name );
	SceneObjectData *pData=m_CurScene->AddSceneObject(box);//new SceneObjectData(OBJ_BOX,box);
	pData->hItem =h;
	m_ObjectsTree.m_objtree.SetItemData (h,(DWORD)pData);
	//putting the dialogs to be shown
	CObjMaterialDlg *MatDlg=new CObjMaterialDlg();
	MatDlg->m_Object =box;
CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	MatDlg->Create (IDD_OBJ_MATERIAL_NAME,&mainfrm->m_Commandpanel);
	box->OptionDialogs["CObjMaterialDlg"]=MatDlg;
	CObjPhotonDlg *Photondlg=new CObjPhotonDlg();
	Photondlg->m_Object =box;
	Photondlg->Create (IDD_OBJPHOTON,&mainfrm->m_Commandpanel);
	box->OptionDialogs["CObjPhotonDlg"]=Photondlg;

	CObjectOptions *ObjectOptiondlg=new CObjectOptions();
	ObjectOptiondlg->m_Object =box;
	ObjectOptiondlg->Create (IDD_OBJECT_OPTIONS,&mainfrm->m_Commandpanel);
	box->OptionDialogs["CObjectOptions"]=ObjectOptiondlg;

	
	m_ObjectsTree.m_objtree.EnableWindow (true);
	SetModifiedFlag ();
	this->UpdateAllViews (0,0,0);
}

void CPhotonixDoc::OnAddPointLight()
{
	PointLightObj *lightsource=new PointLightObj();
	//	sphere->RayTextureName="cool";
		
m_CurScene->AddRenderable (lightsource->pRenderable);
	m_ObjectsTree.m_objtree.EnableWindow (false);
	HTREEITEM h=m_ObjectsTree.m_objtree.InsertItem (lightsource->pRenderable->Name );
	SceneObjectData *pData=m_CurScene->AddSceneObject(lightsource);//new SceneObjectData(OBJ_POINT_LIGHT,lightsource);
	pData->hItem =h;
	m_ObjectsTree.m_objtree.SetItemData (h,(DWORD)pData);
	//putting the dialogs to be shown
	/*CObjMaterialDlg *MatDlg=new CObjMaterialDlg();
	MatDlg->m_Object =lightsource;
	MatDlg->Create (IDD_OBJ_MATERIAL_NAME,&mainfrm->m_Commandpanel);
	pData->OptionDialogs["CObjMaterialDlg"]=MatDlg;
	*/
	CLightPhotons *Photondlg=new CLightPhotons();
	Photondlg->m_Object =lightsource;
CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	Photondlg->Create (IDD_LIGHT_PHOTONS,&mainfrm->m_Commandpanel);
	lightsource->OptionDialogs["CLightPhotons"]=Photondlg;

	CLightOptions *LightOptiondlg=new CLightOptions();
	LightOptiondlg->m_Object =lightsource;
	LightOptiondlg->m_Obj=lightsource;
	LightOptiondlg->Create (IDD_LIGHT_OPTIONS,&mainfrm->m_Commandpanel);
	lightsource->OptionDialogs["CLightOptions"]=LightOptiondlg;

CAreaLightOptions* arealightoptions=new CAreaLightOptions();
arealightoptions->m_Object=lightsource;
arealightoptions->m_Obj =lightsource;
arealightoptions->Create (IDD_AREALIGHTOPTIONS,&mainfrm->m_Commandpanel);
	lightsource->OptionDialogs["CAreaLightOptions"]=arealightoptions;

	m_ObjectsTree.m_objtree.EnableWindow (true);
	SetModifiedFlag ();
	this->UpdateAllViews (0,0,0);
}
void CPhotonixDoc::OnReleasedcaptureKeyframes(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	CSliderCtrl * pCtrl=(CSliderCtrl *)mainfrm->m_AnimationDialogBar .GetDlgItem (IDC_KEYFRAMES);
	int pos=pCtrl->GetPos ();
	IRenderable* pRend=(IRenderable*)m_Selector->mPicked[0];
	pRend->Bounding.PopMatrix();
	Matrix4 *m=new Matrix4();
	*m=m->GetTranslation (pRend->m_TimeLine.getInterpolatedKeyFrame(pos).getTranslate());
	pRend->Bounding.PushMatrix(m);

	*pResult = 0;
}

void CPhotonixDoc::OnAddkey() 
{
	CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	CSliderCtrl * pCtrl=(CSliderCtrl *)mainfrm->m_AnimationDialogBar .GetDlgItem (IDC_KEYFRAMES);
	int spos=pCtrl->GetPos ();
	IRenderable* pRend=(IRenderable*)m_Selector->mPicked[0];
	KeyFrame * key=pRend->m_TimeLine.createKeyFrame(spos);
	Matrix4 mat=pRend->Bounding.GetWorldTransform();
	Vector3 pos;
	pos.x=mat(3,0) ;pos.y=mat(3,1) ;pos.z=mat(3,2) ;
	key->setTranslate(pos);
}

void CPhotonixDoc::OnEditDelete()
{
	CMainFrame * mainfram =(CMainFrame*)AfxGetMainWnd();
	if(mainfram==mainfrm)
	{
//	if(mainfrm->GetSafeHwnd ())
//	{
		if(mainfrm->m_Commandpanel.GetSafeHwnd ())
		{
			if(mainfrm->m_Commandpanel.m_rollup.GetSafeHwnd ())
				mainfrm->m_Commandpanel.m_rollup.RemoveAllPages ();
		}
//	}
	}
		else
		{
			AfxMessageBox("This Must not Happen!!!>>");
		}
	int count=m_Selector ->mPicked .GetSize ();
	for(int i=0;i<count;i++)
	{
		IRenderable * pRend=(IRenderable *)m_Selector ->mPicked[i];
	//	ISceneObject * m_Object=(ISceneObject *)pRend->pReserved ;
		SceneObjectData* data=(SceneObjectData*)m_CurScene -> m_MapSceneObjects[pRend->Name];
		m_ObjectsTree.m_objtree .DeleteItem (data->hItem );
	//	m_Selector->ResetSelector();
		m_CurScene->DeleteSceneObject(data->pObject);
		//	pRend->pReserved
		m_CurScene->DeleteRenderable (pRend);
	}
	m_Selector ->mPicked.RemoveAll ();
	m_Selector->ResetSelector();
	this->UpdateAllViews (0,0,0);
}

void CPhotonixDoc::OnAddTargetcamera()
{
	CameraObj *precam=new CameraObj();
	//	sphere->RayTextureName="cool";
	m_CurScene->AddRenderable (precam->pRenderable);
	m_ObjectsTree.m_objtree.EnableWindow (false);
	HTREEITEM h=m_ObjectsTree.m_objtree.InsertItem (precam->pRenderable->Name );
	SceneObjectData *pData=m_CurScene->AddSceneObject(precam);//new SceneObjectData(OBJ_POINT_LIGHT,lightsource);
	pData->hItem =h;
	m_ObjectsTree.m_objtree.SetItemData (h,(DWORD)pData);
	//putting the dialogs to be shown
	CCameraOptions *CameraOptionsdlg=new CCameraOptions();
	CameraOptionsdlg->m_Object =precam;
CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	CameraOptionsdlg->Create (IDD_CAMERAOPTIONS,&mainfrm->m_Commandpanel);
	precam->OptionDialogs["CCameraOptions"]=CameraOptionsdlg;

	m_ObjectsTree.m_objtree.EnableWindow (true);
	SetModifiedFlag ();
	this->UpdateAllViews (0,0,0);
}
CameraObj * CPhotonixDoc::CreateTargetcamera()
{
	CameraObj *precam=new CameraObj();
	//	sphere->RayTextureName="cool";
	m_CurScene->AddRenderable (precam->pRenderable);
	m_ObjectsTree.m_objtree.EnableWindow (false);
	HTREEITEM h=m_ObjectsTree.m_objtree.InsertItem (precam->pRenderable->Name );
	SceneObjectData *pData=m_CurScene->AddSceneObject(precam);//new SceneObjectData(OBJ_POINT_LIGHT,lightsource);
	pData->hItem =h;
	m_ObjectsTree.m_objtree.SetItemData (h,(DWORD)pData);
	//putting the dialogs to be shown
	CCameraOptions *CameraOptionsdlg=new CCameraOptions();
	CameraOptionsdlg->m_Object =precam;
CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	CameraOptionsdlg->Create (IDD_CAMERAOPTIONS,&mainfrm->m_Commandpanel);
	precam->OptionDialogs["CCameraOptions"]=CameraOptionsdlg;
m_ObjectsTree.m_objtree.EnableWindow (true);
return precam;
}
#include "3dsloader.h"

void CPhotonixDoc::OnImport3dsfile()
{
	CFileDialog dlg(true,"AutoDesk 3D Studio Files|*.3ds");
	if(dlg.DoModal ()==IDOK)
	{
		C3DSLoader threedsfile;
		threedsfile.LoadFile(dlg.m_ofn .lpstrFile);
		threedsfile.SeekFrame(0);
		//Iterate on cameras
		void * Position=NULL;
		CString ObjectName;
		while(threedsfile.GetNextCamera(&Position,ObjectName))
		{
			if(MainApp ->stringgenerator .CheckString (ObjectName))
			{
				//create some dialog to rename the new object or replace
			}
			CameraObj *cam=CreateTargetcamera();	//put a param the object name
			threedsfile.GetCamera (Position,cam->camera );
		}
	}
}

void CPhotonixDoc::OnAddSpotlight()
{
	SpotLightObj *lightsource=new SpotLightObj();
	//	sphere->RayTextureName="cool";
		
m_CurScene->AddRenderable (lightsource->pRenderable);
	m_ObjectsTree.m_objtree.EnableWindow (false);
	HTREEITEM h=m_ObjectsTree.m_objtree.InsertItem (lightsource->pRenderable->Name );
	SceneObjectData *pData=m_CurScene->AddSceneObject(lightsource);//new SceneObjectData(OBJ_POINT_LIGHT,lightsource);
	pData->hItem =h;
	m_ObjectsTree.m_objtree.SetItemData (h,(DWORD)pData);
	//putting the dialogs to be shown
	/*CObjMaterialDlg *MatDlg=new CObjMaterialDlg();
	MatDlg->m_Object =lightsource;
	MatDlg->Create (IDD_OBJ_MATERIAL_NAME,&mainfrm->m_Commandpanel);
	pData->OptionDialogs["CObjMaterialDlg"]=MatDlg;
	*/
	CLightPhotons *Photondlg=new CLightPhotons();
	Photondlg->m_Object =lightsource;
CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	Photondlg->Create (IDD_LIGHT_PHOTONS,&mainfrm->m_Commandpanel);
	lightsource->OptionDialogs["CLightPhotons"]=Photondlg;

	CLightOptions *LightOptiondlg=new CLightOptions();
	LightOptiondlg->m_Object =lightsource;
	LightOptiondlg->m_Obj=lightsource;
	LightOptiondlg->Create (IDD_LIGHT_OPTIONS,&mainfrm->m_Commandpanel);
	lightsource->OptionDialogs["CLightOptions"]=LightOptiondlg;

CAreaLightOptions* arealightoptions=new CAreaLightOptions();
arealightoptions->m_Object=lightsource;
arealightoptions->m_Obj =lightsource;
arealightoptions->Create (IDD_AREALIGHTOPTIONS,&mainfrm->m_Commandpanel);
	lightsource->OptionDialogs["CAreaLightOptions"]=arealightoptions;

CSpotLightParams* spotlightoptions=new CSpotLightParams();
spotlightoptions->m_Object=lightsource;
spotlightoptions->Create (IDD_SPOTLIGHTPARAMS,&mainfrm->m_Commandpanel);
	lightsource->OptionDialogs["CSpotLightParams"]=spotlightoptions;

	
	m_ObjectsTree.m_objtree.EnableWindow (true);
	SetModifiedFlag ();
	this->UpdateAllViews (0,0,0);
}

void CPhotonixDoc::OnMessage(VOID *pSender,CString Message)
{
	CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();

	mainfrm->m_Commandpanel .OnMessage (pSender,Message);

}

void CPhotonixDoc::OnImportIfsfile()
{
		// szFilters is a text string that includes two file name filters:
   // "*.my" for "MyType Files" and "*.*' for "All Files."
   char szFilters[]=
      "IFS Files (*.IFS)|IFS Files||";

   // Create an Open dialog; the default file name extension is ".my".
   CFileDialog fileDlg (TRUE, "IFS", "*.ifs",
      OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters);
   
   // Display the file dialog. When user clicks OK, fileDlg.DoModal() 
   // returns IDOK.
   if( fileDlg.DoModal ()==IDOK )
   {
      CString pathName = fileDlg.GetPathName();
   
      // Implement opening and reading file in here.
      //Change the window's title to the opened file's title.
		CString fileName = fileDlg.GetPathName ();
		
		char name[256]={0};
		strcpy(name,fileName);
		string s(LPCTSTR(fileName));
		IFSModel mod;
		Mesh *mesh;
		mod.LoadModel (name,&mesh);
//		mesh->Name=GetMainApp ()->stringgenerator .RequestString("MeshSphere");
	

		MeshObj *m=new MeshObj();
		m->pRenderable =mesh;
	//	sphere->RayTextureName="cool";
	m_CurScene->AddRenderable (m->pRenderable);
	//this->RenderWnd .Invalidate (0);
	m_ObjectsTree.m_objtree.EnableWindow (false);
	HTREEITEM h=m_ObjectsTree.m_objtree.InsertItem (m->pRenderable->Name );
	SceneObjectData *pData=m_CurScene->AddSceneObject(m);//new SceneObjectData(OBJ_SPHERE,sphere);
	pData->hItem =h;
	m_ObjectsTree.m_objtree.SetItemData (h,(DWORD)pData);
	//putting the dialogs to be shown
	CObjMaterialDlg *MatDlg=new CObjMaterialDlg();
	MatDlg->m_Object =m;
CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	MatDlg->Create (IDD_OBJ_MATERIAL_NAME,&mainfrm->m_Commandpanel);
	m->OptionDialogs["CObjMaterialDlg"]=MatDlg;
	CObjPhotonDlg *Photondlg=new CObjPhotonDlg();
	Photondlg->m_Object =m;
	Photondlg->Create (IDD_OBJPHOTON,&mainfrm->m_Commandpanel);
	m->OptionDialogs["CObjPhotonDlg"]=Photondlg;

	CObjectOptions *ObjectOptiondlg=new CObjectOptions();
	ObjectOptiondlg->m_Object =m;
	ObjectOptiondlg->Create (IDD_OBJECT_OPTIONS,&mainfrm->m_Commandpanel);
	m->OptionDialogs["CObjectOptions"]=ObjectOptiondlg;
	m_ObjectsTree.m_objtree.EnableWindow (true);
	SetModifiedFlag ();
	this->UpdateAllViews (0,0,0);
		//m_CurScene->AddSceneObject();//mesh
		
	//	((SceneObj*)(GetMainApp ()->mScenes["Scene1"]))->AddRenderable (mesh);
   }
}
