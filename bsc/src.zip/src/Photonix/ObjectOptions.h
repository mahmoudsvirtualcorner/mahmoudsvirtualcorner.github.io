#if !defined(AFX_OBJECTOPTIONS_H__E67FCFDD_EED6_4BF4_B477_37FB58EC7D68__INCLUDED_)
#define AFX_OBJECTOPTIONS_H__E67FCFDD_EED6_4BF4_B477_37FB58EC7D68__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ObjectOptions.h : header file
//
#include "AccessDialog.h"
#include "enggenclasses.h"

/////////////////////////////////////////////////////////////////////////////
// CObjectOptions dialog

class CObjectOptions : public CAccessDialog//CDialog
{
// Construction
public:
	CObjectOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CObjectOptions)
	enum { IDD = IDD_OBJECT_OPTIONS };
	BOOL	m_noshadow;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CObjectOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CObjectOptions)
	afx_msg void OnNoshadow();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OBJECTOPTIONS_H__E67FCFDD_EED6_4BF4_B477_37FB58EC7D68__INCLUDED_)
