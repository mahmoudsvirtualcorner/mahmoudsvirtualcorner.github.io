// MaterialsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "MaterialsDlg.h"
#include "PhotonixDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMaterialsDlg dialog


CMaterialsDlg::CMaterialsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMaterialsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMaterialsDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_MaterialName="";
}


void CMaterialsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMaterialsDlg)
	DDX_Control(pDX, IDC_MATLIST, m_matlist);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMaterialsDlg, CDialog)
	//{{AFX_MSG_MAP(CMaterialsDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMaterialsDlg message handlers

void CMaterialsDlg::OnOK() 
{
	// TODO: Add extra validation here
	POSITION pos=m_matlist.GetFirstSelectedItemPosition ();
	int index=m_matlist.GetNextSelectedItem (pos);
	if(index!=-1)
	{
		m_MaterialName=m_matlist.GetItemText (index,0);
	}
	CDialog::OnOK();
}

BOOL CMaterialsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// create, initialize, and hook up image list
	m_pImageList.Create(32	,32	, ILC_COLOR32|ILC_MASK,   4, 4);
	CBitmap cbmp;
	BITMAP bmp;
	cbmp.LoadBitmap(IDB_MATERIAL_ICON);
	cbmp.GetBitmap(&bmp);
	m_pImageList.Add(&cbmp,RGB(0,0,0));
	m_matlist.SetImageList(&m_pImageList, LVSIL_NORMAL);
	// TODO: Add extra initialization here
	m_matlist.InsertColumn (0,"Material Name");
	CTreeCtrl * pCtrl =&(CPhotonixDoc::TextureEditor.m_tree);
	HTREEITEM h=pCtrl->GetRootItem ();
	if(h)
	{

		ItemDATA* d=(ItemDATA*)pCtrl->GetItemData (h);
		if(d->menutype ==m_Searchtype)
		{
			if(d->Name!="")
				m_matlist.InsertItem (m_matlist.GetItemCount (),d->Name,0 );
		}	

		// Look at all of the root-level items
		HTREEITEM hCurrent =pCtrl->GetNextItem(h, TVGN_NEXT);
		while (hCurrent != NULL)
		{
			ItemDATA* data=(ItemDATA*)pCtrl->GetItemData (hCurrent);
			if(data->menutype ==m_Searchtype)
			{
				if(data->Name!="")
					m_matlist.InsertItem (m_matlist.GetItemCount (),data->Name,0 );
			}	
			// Try to get the next item
			hCurrent = pCtrl->GetNextItem(hCurrent, TVGN_NEXT);

		}
	}
	if(m_matlist.GetItemCount ()>0)
	{
		m_matlist.SetItemState (0,LVIS_SELECTED , LVIS_SELECTED);
	}
	else
	{
		AfxMessageBox("The Specified Item Not Exist in Material Library");
		CDialog::OnOK ();
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
