// PhotonixDoc.h : interface of the CPhotonixDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PHOTONIXDOC_H__33596D6B_8615_44CD_BC21_F430805AE366__INCLUDED_)
#define AFX_PHOTONIXDOC_H__33596D6B_8615_44CD_BC21_F430805AE366__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "myapplication.h"

#include "RenderScene.h"
#include "PictureDialog.h"
#include "SceneSettings.h"
#include "TexMakerDlg.h"
#include "ObjectsTree.h"
#include "sceneobj.h"

class CMainFrame;
class CPhotonixDoc : public CDocument,public IGenericMessageReciever
{
protected: // create from serialization only
	CPhotonixDoc();
	DECLARE_DYNCREATE(CPhotonixDoc)

// Attributes
public:
CMyApplication  *MainApp;
SceneSelector *m_Selector;
CString  RenderCameraName;
bool CameraSet;
static CTexMakerDlg TextureEditor;
//bool DialogsCreated;
SceneObj * m_CurScene; //the one and only one scene in the application

static CRenderScene renderscene;	
static CPictureDialog RenderDlg;
static 	CSceneSettings m_Settings;
CObjectsTree m_ObjectsTree;
CMainFrame * mainfrm;

// Operations
public:
static void InitAtmosphericEffects();
static UINT Render(LPVOID p);
CameraObj *GetCamera (CString CamName);

//testing
CameraObj * CreateTargetcamera();
//event handles
virtual void OnMessage(VOID *pSender,CString Message);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPhotonixDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPhotonixDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPhotonixDoc)
	afx_msg void OnReleasedcaptureKeyframes(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnAddkey();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	virtual void DeleteContents();
	afx_msg void OnAddSphere();
	afx_msg void OnRenderingRender();
	afx_msg void OnMaterialeditor();
	afx_msg void OnQuickRender();
	afx_msg void OnViewObjectTree();
	afx_msg void OnSceneSettings();
	afx_msg void OnManipulationTranslation();
	afx_msg void OnManipulationRotation();
	afx_msg void OnManipulationScale();
	afx_msg void OnAddTorus();
	afx_msg void OnAddCone();
	afx_msg void OnAddCylinder();
	afx_msg void OnAddBox();
	afx_msg void OnAddPointLight();
	afx_msg void OnEditDelete();
	afx_msg void OnAddTargetcamera();
	afx_msg void OnImport3dsfile();
	afx_msg void OnAddSpotlight();
	afx_msg void OnImportIfsfile();
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PHOTONIXDOC_H__33596D6B_8615_44CD_BC21_F430805AE366__INCLUDED_)
