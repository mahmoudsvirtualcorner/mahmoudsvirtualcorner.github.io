#if !defined(AFX_INTERIORDLG_H__E1973335_30DA_46C4_A395_CB34DA81B1BD__INCLUDED_)
#define AFX_INTERIORDLG_H__E1973335_30DA_46C4_A395_CB34DA81B1BD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// InteriorDlg.h : header file
//
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CInteriorDlg dialog

class CInteriorDlg : public CAccessDialog//CDialog
{
// Construction
public:
	DECLARE_SERIAL(CInteriorDlg)
	CInteriorDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CInteriorDlg)
	enum { IDD = IDD_INTERIOR };
	float	m_cpower;
	float	m_fpower;
	BOOL	m_is_fade;
	BOOL	m_is_caustics;
	float	m_ior;
	float	m_distance;
	int		m_disersionsamples;
	float	m_dispersion;
	//}}AFX_DATA
virtual void Serialize(CArchive &ar);


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInteriorDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInteriorDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTERIORDLG_H__E1973335_30DA_46C4_A395_CB34DA81B1BD__INCLUDED_)
