#pragma once
#include "guicontrolbar.h"
#include "GuiFolder.h"

#include "GuiOutLook.h"
#include "GuiTabWnd.h"
#include "GuiContainer.h"
#include "rollupctrl.h"
#include "supportedinterfaces.h"
#include "photonixdoc.h"
class CCommandPanel :	public CGuiControlBar,public IGenericMessageReciever
{
public:
//	CGuiFolder cf;
//	CGuiOutLook Logic ,Operations,ImageOp,Frequency,Restoration;
CGuiTabWnd	m_Tab;
CGuiContainer m_OptionsRollUp;
CGuiMiniTool  m_MiniOptionsTool;
CRollupCtrl m_rollup;
virtual void OnMessage(VOID *pSender,CString Message);
virtual afx_msg void OnExpandAll();
virtual afx_msg void OnCollapseAll();

public:
	CCommandPanel(void);
	virtual ~CCommandPanel(void);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);

	virtual BOOL DestroyWindow();
	DECLARE_MESSAGE_MAP()
};
