// AreaLightOptions.cpp : implementation file
//

#include "stdafx.h"
#include "photonix.h"
#include "AreaLightOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAreaLightOptions dialog


CAreaLightOptions::CAreaLightOptions(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CAreaLightOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAreaLightOptions)
	m_enablearea = FALSE;
	m_samplesu = 10;
	m_samplesv = 10;
	m_axis1x = 1.0f;
	m_axis1y = 0.0f;
	m_axis1z = 0.0f;
	m_axis2x = 0.0f;
	m_axis2y = 1.0f;
	m_axis2z = 0.0f;
	//}}AFX_DATA_INIT
	m_Obj=0;
}


void CAreaLightOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAreaLightOptions)
	DDX_Check(pDX, IDC_ENABLEAREA, m_enablearea);
	DDX_Text(pDX, IDC_SAMPLESU, m_samplesu);
	DDX_Text(pDX, IDC_SAMPLESV, m_samplesv);
	DDX_Text(pDX, IDC_AXIS1X, m_axis1x);
	DDX_Text(pDX, IDC_AXIS1Y, m_axis1y);
	DDX_Text(pDX, IDC_AXIS1Z, m_axis1z);
	DDX_Text(pDX, IDC_AXIS2X, m_axis2x);
	DDX_Text(pDX, IDC_AXIS2Y, m_axis2y);
	DDX_Text(pDX, IDC_AXIS2Z, m_axis2z);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAreaLightOptions, CAccessDialog)
	//{{AFX_MSG_MAP(CAreaLightOptions)
	ON_EN_KILLFOCUS(IDC_SAMPLESU, OnKillfocusSamplesu)
	ON_EN_KILLFOCUS(IDC_SAMPLESV, OnKillfocusSamplesv)
	ON_BN_CLICKED(IDC_ENABLEAREA, OnEnablearea)
	ON_EN_KILLFOCUS(IDC_AXIS1X, OnKillfocusAxis1x)
	ON_EN_KILLFOCUS(IDC_AXIS1Y, OnKillfocusAxis1y)
	ON_EN_KILLFOCUS(IDC_AXIS1Z, OnKillfocusAxis1z)
	ON_EN_KILLFOCUS(IDC_AXIS2X, OnKillfocusAxis2x)
	ON_EN_KILLFOCUS(IDC_AXIS2Y, OnKillfocusAxis2y)
	ON_EN_KILLFOCUS(IDC_AXIS2Z, OnKillfocusAxis2z)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAreaLightOptions message handlers

void CAreaLightOptions::OnKillfocusSamplesu() 
{
	UpdateData ();
	AreaLightData * data=m_Obj ;
	data->m_samplesu=m_samplesu;

}

void CAreaLightOptions::OnKillfocusSamplesv() 
{
	UpdateData ();
	AreaLightData * data=m_Obj ;
	data->m_samplesv=m_samplesv;

}

void CAreaLightOptions::OnEnablearea() 
{
	UpdateData ();
	AreaLightData * data=m_Obj ;
	data->m_enablearea=(m_enablearea==1)?1:0;

}

void CAreaLightOptions::OnKillfocusAxis1x() 
{
	UpdateData ();
	AreaLightData * data=m_Obj ;
	data->m_axis1x =m_axis1x;

}

void CAreaLightOptions::OnKillfocusAxis1y() 
{
	UpdateData ();
	AreaLightData * data=m_Obj ;
	data->m_axis1y =m_axis1y;

}

void CAreaLightOptions::OnKillfocusAxis1z() 
{
	UpdateData ();
	AreaLightData * data=m_Obj ;
	data->m_axis1z =m_axis1z;

	
}

void CAreaLightOptions::OnKillfocusAxis2x() 
{
	UpdateData ();
	AreaLightData * data=m_Obj ;
	data->m_axis2x =m_axis2x;


}

void CAreaLightOptions::OnKillfocusAxis2y() 
{
	UpdateData ();
	AreaLightData * data=m_Obj ;
	data->m_axis2y =m_axis2y;


}

void CAreaLightOptions::OnKillfocusAxis2z() 
{
		UpdateData ();
	AreaLightData * data=m_Obj ;
	data->m_axis2z =m_axis2z;


}
