// RadiosityOptions.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "RadiosityOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRadiosityOptions dialog


CRadiosityOptions::CRadiosityOptions(CWnd* pParent /*=NULL*/)
	: CDialog(CRadiosityOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRadiosityOptions)
	m_brightness = 3.3f;
	m_count = 100;
	m_dist_max = 0.0f;
	m_err_bound = 0.4f;
	m_gray_threshold = 0.5f;
	m_lowerror_factor = 0.8f;
	m_min_reuse = 0.015f;
	m_nearest_count = 6;
	m_rec_limit = 1;
	//}}AFX_DATA_INIT
}


void CRadiosityOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRadiosityOptions)
	DDX_Text(pDX, IDC_BRIGHTNESS, m_brightness);
	DDV_MinMaxFloat(pDX, m_brightness, 0.f, 100.f);
	DDX_Text(pDX, IDC_COUNT, m_count);
	DDV_MinMaxUInt(pDX, m_count, 0, 1600);
	DDX_Text(pDX, IDC_DIST_MAX, m_dist_max);
	DDV_MinMaxFloat(pDX, m_dist_max, 0.f, 1.e+016f);
	DDX_Text(pDX, IDC_ERR, m_err_bound);
	DDV_MinMaxFloat(pDX, m_err_bound, 0.f, 1.f);
	DDX_Text(pDX, IDC_GRAY_THESHOLD, m_gray_threshold);
	DDV_MinMaxFloat(pDX, m_gray_threshold, 0.f, 1.f);
	DDX_Text(pDX, IDC_LOW_ERROR_FACTOR, m_lowerror_factor);
	DDV_MinMaxFloat(pDX, m_lowerror_factor, 0.f, 1.f);
	DDX_Text(pDX, IDC_MINIMUM_REUSE, m_min_reuse);
	DDV_MinMaxFloat(pDX, m_min_reuse, 0.f, 1.f);
	DDX_Text(pDX, IDC_NEAREST_COUNT, m_nearest_count);
	DDV_MinMaxUInt(pDX, m_nearest_count, 0, 20);
	DDX_Text(pDX, IDC_RECURSION_LIMIT, m_rec_limit);
	DDV_MinMaxUInt(pDX, m_rec_limit, 1, 2);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRadiosityOptions, CDialog)
	//{{AFX_MSG_MAP(CRadiosityOptions)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRadiosityOptions message handlers
