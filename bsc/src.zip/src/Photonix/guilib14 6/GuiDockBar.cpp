// GuiDockBar.cpp : implementation file
//

#include "stdafx.h"

#include "GuiDockBar.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGuiDockBar

CGuiDockBar::CGuiDockBar()
{
}

CGuiDockBar::~CGuiDockBar()
{
}


BEGIN_MESSAGE_MAP(CGuiDockBar, CDockBar)
	//{{AFX_MSG_MAP(CGuiDockBar)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CSize ReCalLayout(CGuiControlBar* pWnd)
{
	
}
/////////////////////////////////////////////////////////////////////////////
// CGuiDockBar message handlers
