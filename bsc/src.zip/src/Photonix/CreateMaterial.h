#if !defined(AFX_CREATEMATERIAL_H__A8F77EC4_23B2_4310_912D_E9C31B67E907__INCLUDED_)
#define AFX_CREATEMATERIAL_H__A8F77EC4_23B2_4310_912D_E9C31B67E907__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CreateMaterial.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CCreateMaterial dialog

class CCreateMaterial : public CDialog
{
// Construction
public:
	CCreateMaterial(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCreateMaterial)
	enum { IDD = IDD_CREATE_MATERIAL };
	int		m_mat_type;
	CString	m_name;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCreateMaterial)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CCreateMaterial)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CREATEMATERIAL_H__A8F77EC4_23B2_4310_912D_E9C31B67E907__INCLUDED_)
