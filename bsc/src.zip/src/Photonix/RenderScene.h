#if !defined(AFX_RENDERSCENE_H__0C9339B2_7735_4BF0_B0EB_97C09CCAA937__INCLUDED_)
#define AFX_RENDERSCENE_H__0C9339B2_7735_4BF0_B0EB_97C09CCAA937__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RenderScene.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRenderScene dialog

class CRenderScene : public CDialog
{
// Construction
public:
	CRenderScene(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRenderScene)
	enum { IDD = IDD_RENDER_SCENE };
	CComboBox	m_cameranames;
	UINT	m_start;
	UINT	m_stop;
	float	m_threshold;
	float	m_jitter;
	BOOL	m_mosaic;
	BOOL	m_antialiasing;
	int		m_sampling_method;
	BOOL	m_use_radiosity;
	int		m_depth;
	UINT	m_height;
	UINT	m_width;
	CString	m_selcam;
	//}}AFX_DATA

CStringArray Cameras;
CString SelectedCameraName;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRenderScene)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRenderScene)
	afx_msg void OnRender();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnCbnSelendokResolutionx();
	virtual BOOL OnInitDialog();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RENDERSCENE_H__0C9339B2_7735_4BF0_B0EB_97C09CCAA937__INCLUDED_)
