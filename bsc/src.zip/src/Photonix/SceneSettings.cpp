// SceneSettings.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "SceneSettings.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSceneSettings dialog


CSceneSettings::CSceneSettings(CWnd* pParent /*=NULL*/)
	: CDialog(CSceneSettings::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSceneSettings)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSceneSettings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSceneSettings)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSceneSettings, CDialog)
	//{{AFX_MSG_MAP(CSceneSettings)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSceneSettings message handlers

BOOL CSceneSettings::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	BOOL bSuccess;
CWnd * wnd=this->GetDlgItem (IDC_SETTINGS);
	CRect rect;
	wnd->GetWindowRect (&rect);
	this->ScreenToClient (&rect);
	
	bSuccess = m_rollup.Create(WS_CHILD | WS_DLGFRAME | WS_VISIBLE, rect, this, 1200);//CRect(0,0,500,400)
	ASSERT(bSuccess);
	
		m_globaldlg.Create (IDD_GLOBAL_SETTINGS,&m_rollup);
		m_rollup.InsertPage ("Global Settings",&m_globaldlg,false);

		m_fogdlg.Create (IDD_FOG,&m_rollup);
		m_rollup.InsertPage ("Fog Options",&m_fogdlg,false);

		m_raddlg.Create (IDD_RADIOSITY,&m_rollup);
		m_rollup.InsertPage ("Radiosity Options",&m_raddlg,false);

		m_pmdialog.Create (IDD_PHOTON_GLOBAL_OPTIONS,&m_rollup);
		m_rollup.InsertPage ("Photon Mapping",&m_pmdialog,false);

		m_mediadlg.Create (IDD_GLOBAL_MEDIA,&m_rollup);
		m_rollup.InsertPage ("Atmospheric Media",&m_mediadlg,false);

		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSceneSettings::OnDestroy() 
{
	CDialog::OnDestroy();
m_rollup.RemoveAllPages ();
//	m_rollup.DestroyWindow ();
/*	m_globaldlg.DestroyWindow ();
	m_fogdlg.DestroyWindow ();
	m_raddlg.DestroyWindow ();
	m_mediadlg.DestroyWindow ();*/
	// TODO: Add your message handler code here
	
}

void CSceneSettings::OnOK() 
{
	// TODO: Add extra validation here
//	m_globaldlg.UpdateData ();

	CDialog::OnOK();
}
