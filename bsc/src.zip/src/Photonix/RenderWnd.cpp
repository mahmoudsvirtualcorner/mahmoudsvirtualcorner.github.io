// RenderWnd.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "RenderWnd.h"

#include "gsmmath.h"
#include "myapplication.h"
#include "RenderWindow.h"

#include "Win32Window.h"
#include "PhotonixView.h"
// CRenderWnd
#define IDR_CAMERA0 1010
#define IDR_CUSTOMCAMERA0 2010


IMPLEMENT_DYNAMIC(CRenderWnd, CWnd)
CRenderWnd::CRenderWnd()
{
}

CRenderWnd::~CRenderWnd()
{
}


BEGIN_MESSAGE_MAP(CRenderWnd, CWnd)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_ERASEBKGND()
	ON_WM_ACTIVATE()
	ON_WM_RBUTTONDOWN()
	ON_COMMAND(ID_WIREFRAME, OnWireframe)
	ON_COMMAND(ID_SMOOTHHIGHLIGHT, OnSmoothhighlight)
	ON_COMMAND(ID_POINTS, OnPoints)
END_MESSAGE_MAP()



// CRenderWnd message handlers


void CRenderWnd::OnLButtonDown(UINT nFlags, CPoint point)
{
	
	((SceneSelector*)this->MouseRecievers[0])->SelCamera=m_CurCamera;
		((SceneSelector*)this->MouseRecievers[0])->SelViewPort =m_CurViewPort ;

	this->SetCapture ();
	// TODO: Add your message handler code here and/or call default
	POINT point1;point1.x=point.x;point1.y=point.y ;
	//	this->ClientToScreen (&point1);

	//	RenderWnd->ScreenToClient(&point1);
	CRect rect;
	GetClientRect (rect);
	//	if(rect.PtInRect(point1))
	//	{
	//	FireLMouseDown(2*((Real) point1.x/rect.Width ()-0.5),2*((Real)0.5-(Real)point1.y/rect.Height ()));28-jan
	FireLMouseDown(point1.x,point1.y);//zedan
	//	}

	/*	if(pDoc->MainApp->NeedRedraw)
	{
	Invalidate ();
	pDoc->MainApp->NeedRedraw=false;
	pDoc->UpdateAllViews ((CView*)this->GetParent (),1,0);
	}*/
	CWnd::OnLButtonDown(nFlags, point);
}

void CRenderWnd::OnLButtonUp(UINT nFlags, CPoint point)
{
	((SceneSelector*)this->MouseRecievers[0])->SelCamera=m_CurCamera;
	((SceneSelector*)this->MouseRecievers[0])->SelViewPort =m_CurViewPort ;

	ReleaseCapture();
	// TODO: Add your message handler code here and/or call default
	POINT point1;point1.x=point.x;point1.y=point.y ;
	//	this->ClientToScreen (&point1);

	//	RenderWnd->ScreenToClient(&point1);
	CRect rect;
	GetClientRect (rect);
	//	if(rect.PtInRect(point1))
	//	{
	//	FireLMouseUp(2*((Real) point1.x/rect.Width ()-0.5),2*((Real)0.5-(Real)point1.y/rect.Height ()));//8-feb
	FireLMouseUp(point1.x,point1.y);//zedan
	//	}
	//Invalidate ();
	/*	if(pDoc->MainApp->NeedRedraw)
	{
	Invalidate ();
	pDoc->MainApp->NeedRedraw=false;
	pDoc->UpdateAllViews ((CView*)this->GetParent (),1,0);
	}*/
	CWnd::OnLButtonUp(nFlags, point);
}

void CRenderWnd::OnMouseMove(UINT nFlags, CPoint point)
{
	((SceneSelector*)this->MouseRecievers[0])->SelCamera=m_CurCamera;
	((SceneSelector*)this->MouseRecievers[0])->SelViewPort =m_CurViewPort ;

	// TODO: Add your message handler code here and/or call default
	POINT point1;point1.x=point.x;point1.y=point.y ;
	//	this->ClientToScreen (&point1);
	int Flags=0;
	if(nFlags & MK_LBUTTON)
	{
		Flags|=MOUSE_LBUTTON;
	}

	if(nFlags & MK_RBUTTON)
	{
		Flags|=MOUSE_RBUTTON;
	}

	if(nFlags & MK_MBUTTON)
	{
		Flags|=MOUSE_MBUTTON;
	}

	if(Flags)
	{
		int a=0;
	}
	//	RenderWnd->ScreenToClient(&point1);
	CRect rect;
	GetClientRect (&rect);
	//	if(rect.PtInRect(point1))
	//	{
	//	FireMouseMove(2*((Real) point1.x/rect.Width ()-0.5),2*((Real)0.5-(Real)point1.y/rect.Height ()),Flags );//8-feb
	FireMouseMove(point1.x,point1.y,Flags);//zedan
	//	}
	//Invalidate ();
	/*if(pDoc->MainApp->NeedRedraw)
	{
	Invalidate ();
	pDoc->MainApp->NeedRedraw=false;
	//	pDoc->UpdateAllViews ((CView*)this->GetParent (),1,0);
	}*/
	CWnd::OnMouseMove(nFlags, point);
}

BOOL CRenderWnd::OnEraseBkgnd(CDC* pDC)
{
	return true;
	//	return __super::OnEraseBkgnd(pDC);
}

void CRenderWnd::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
	CWnd::OnActivate(nState, pWndOther, bMinimized);


}

void CRenderWnd::OnClose()
{
	//	rs->shutdown();
}
#include "gl\gl.h"
#include "gl\glut.h"
void CRenderWnd::OnDrawSelf()
{

		
//	glDisable (GL_LIGHTING);
//	glDisable (GL_LIGHT0);
//	glDepthMask( GL_FALSE );
	
	//SwapBuffers(((Win32Window*)m_Container->win)->mHDC);
//	glFlush();
	if(m_CurCamera)
	{	CDC* dc=GetDC();
	dc->TextOut (0,0,m_CurCamera->Name );
	
	ReleaseDC (dc);
	}
	
//	CClientDC dc(this);
//	dc.TextOut (0,0,m_CurCamera->Name );
/*	char msg[20];
	sprintf(msg, "prespective");
	char *message=&msg[0];
	CRect rect;
	this->GetClientRect(&rect);
	glViewport(0,0,100,100);
	glRasterPos2f(20,20 );
	while (*message) {
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *message);
		message++;
	}
	CDC* dc=GetDC();
	SwapBuffers(dc->GetSafeHdc ());
ReleaseDC (dc);
	*/
}
void CRenderWnd::OnRefresh()
{
//	this->Invalidate (false);
	this->RedrawWindow();
}

void CRenderWnd::OnRButtonDown(UINT nFlags, CPoint point)
{
	CPoint p=point;
	this->ClientToScreen (&p);
	CMenu m;m.LoadMenu (IDR_POPUP);
	CMenu* m2;m2=m.GetSubMenu (0);

	POSITION pos=pDoc->MainApp->mCameras.GetStartPosition ();
	int counter=0;
	while(pos)
	{
		CObject *camera;CString key;
		pDoc->MainApp->mCameras.GetNextAssoc (pos,key,camera);
		CameraObj *cam=(CameraObj *)camera;

		m2->AppendMenu (MF_STRING,IDR_CAMERA0+counter,cam->camera ->Name );
		counter++;
	}

	int count=pDoc->m_CurScene ->m_SceneCameras.GetSize ();
	for(int i=0;i<count;i++)
	{
		m2->AppendMenu (MF_STRING,IDR_CUSTOMCAMERA0+i,((CameraObj*)pDoc->m_CurScene ->m_SceneCameras[i])->camera ->Name );
	}
	m2->TrackPopupMenu (TPM_RIGHTBUTTON,p.x,p.y,this);

	CWnd::OnRButtonDown(nFlags, point);
}

void CRenderWnd::OnWireframe()
{
	m_CurViewPort->mSceneDetail=SDL_WIREFRAME;
	OnRefresh();
}

void CRenderWnd::OnSmoothhighlight()
{
	m_CurViewPort->mSceneDetail=SDL_SOLID;
	OnRefresh();
}

void CRenderWnd::OnPoints()
{
	m_CurViewPort->mSceneDetail=SDL_POINTS;
	OnRefresh();
}

BOOL CRenderWnd::OnCommand(WPARAM wParam, LPARAM lParam)
{
	// TODO: Add your specialized code here and/or call the base class
	UINT nID = LOWORD(wParam);
	if(nID>=IDR_CAMERA0 && nID<IDR_CAMERA0+pDoc->MainApp->mCameras.GetCount())
	{
		int index=nID-IDR_CAMERA0;
		int counter=0;
		POSITION pos=pDoc->MainApp->mCameras.GetStartPosition ();

		while(pos)
		{
			CObject *camera;CString key;
			pDoc->MainApp->mCameras.GetNextAssoc (pos,key,camera);
			CameraObj *cam=(CameraObj *)camera;
			if(index==counter)
			{
				SetViewportCamera(cam->camera );
				break;
			}
			counter++;
		}
		OnRefresh();
	}
	else if(nID>=IDR_CUSTOMCAMERA0 && nID<IDR_CUSTOMCAMERA0+pDoc->m_CurScene ->m_SceneCameras.GetSize())
	{
		int index=nID-IDR_CUSTOMCAMERA0;
		//int counter=0;
		SetViewportCamera(((CameraObj *)pDoc->m_CurScene ->m_SceneCameras[index])->camera);
		/*POSITION pos=pDoc->m_CurScene ->m_SceneCameras.GetStartPosition ();

		while(pos)
		{
			CObject *camera;CString key;
			pGetNextAssoc (pos,key,camera);
			Camera *cam=(Camera *)camera;
			if(index==counter)
			{
				
				break;
			}
			counter++;
		}*/
		OnRefresh();
	}

	return CWnd::OnCommand(wParam, lParam);
}
void CRenderWnd::SetViewportCamera(Camera *cam)
{
	m_CurViewPort ->mCamera=cam;
	m_CurCamera=cam;
	if(cam->Name =="Top")
	{
		m_CurViewPort->SetGridBasis(Vector3(1,0,0), Vector3(0,1,0));
	}
	else if(cam->Name =="Left")
	{
m_CurViewPort->SetGridBasis(Vector3(0,1,0), Vector3(0,0,1));
	}
	else if(cam->Name =="Front")
	{
m_CurViewPort->SetGridBasis(Vector3(1,0,0), Vector3(0,0,1));
	}
	else if(cam->Name =="Right")
	{
m_CurViewPort->SetGridBasis(Vector3(0,1,0), Vector3(0,0,1));
	}
	else //prespective and other
	{
m_CurViewPort->SetGridBasis(Vector3(1,0,0),Vector3(0,1,0));
	}

}