// MapEntry.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "MapEntry.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMapEntry dialog

IMPLEMENT_SERIAL(CMapEntry,CAccessDialog,1)

CMapEntry::CMapEntry(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CMapEntry::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMapEntry)
	m_pos = 0.0;
	//}}AFX_DATA_INIT
}


void CMapEntry::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMapEntry)
	DDX_Text(pDX, IDC_POSITION, m_pos);
	DDV_MinMaxDouble(pDX, m_pos, 0., 1.);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMapEntry, CDialog)
	//{{AFX_MSG_MAP(CMapEntry)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMapEntry message handlers
void CMapEntry::Serialize(CArchive &ar)
{
	if(ar.IsStoring ())
	{
		ar<<m_pos;
	}
	else
	{
		ar>>m_pos;
	}
}
