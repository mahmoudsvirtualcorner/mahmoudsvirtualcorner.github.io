#ifndef GENERICSERIALIZE_H
#define GENERICSERIALIZE_H
#pragma warning(disable:4786)
#include <map>
#include <vector>
using namespace std;

namespace intimate
{//implementation details
    
    template<class Access>
		void Serialize(Access::Type owner,Access::Type current,int currentTyp,
		const Access& a,map<Access::Type,int>& mapObjId,int nId)
    {
        a.ar << currentTyp;
        map<Access::Type,int>::const_iterator it= mapObjId.find(current);
        bool isPresent=(it==mapObjId.end());
        if(isPresent)
		{
            a.ar    <<  nId;
            mapObjId[current]= nId++;
        }
		else
		{
			a.ar    <<  it->second;
        }
        a.ar    <<  (int)isPresent;
        if(isPresent)
		{
            a.SerializeThis(owner,current,currentTyp);
            vector< pair<Access::Type,int> >vecNeighbors;
            a.GetNeighbors(current,vecNeighbors);
            a.ar    <<  vecNeighbors.size();
            for(int i=0;i<vecNeighbors.size();i++)
			{
                Serialize<Access>(current,vecNeighbors[i].first,vecNeighbors[i].second,
					a,mapObjId,nId);
            }
        }
    }
    template<class Access>
		void Deserialize(Access::Type owner,const Access& a,map<int,Access::Type>& mapIdObj)
    {
        int nTyp;
        int isPresent;
        int nId;
        a.ar    >>  nTyp;
        a.ar    >>  nId;
        a.ar    >>  isPresent;
        if(isPresent){
            Access::Type current= a.DeserializeThis(owner,nTyp);
            mapIdObj[nId]= current;

            int nNofElems;
            a.ar    >>  nNofElems;
            for(int i=0;i<nNofElems;i++){
                Deserialize<Access>(current,a,mapIdObj);
            }
        }else{
            a.SetReference(owner,mapIdObj[nId],nTyp);
        }
    }
}

template<class Access>
void GenericSerialize(const Access& a)
{
    map<Access::Type,int>    mapObjId;
    int             nId= 0;
    vector< pair<Access::Type,int> > vecRoots;
    a.GetNeighbors(a.Null(),vecRoots);
    a.ar    <<      vecRoots.size();
    for(int i=0;i<vecRoots.size();i++){
        intimate::Serialize<Access>(a.Null(),vecRoots[i].first,vecRoots[i].second,
                                                                    a,mapObjId,nId);
    }
}

template<class Access>
void GenericDeserialize(const Access& a)
{
    map<int,Access::Type> mapIdObj;
    typedef vector< pair<Access::Type,int> >::size_type size_type;
    size_type nOfElems;
    a.ar    >>  nOfElems;
    for(size_type i=0;i<nOfElems;i++){
        intimate::Deserialize<Access>(a.Null(),a,mapIdObj);
    }
}

#endif
