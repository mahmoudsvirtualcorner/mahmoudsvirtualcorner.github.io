#if !defined(AFX_FOGOPTIONS_H__F198F744_7D7A_47D6_A912_969FB3FEBFCA__INCLUDED_)
#define AFX_FOGOPTIONS_H__F198F744_7D7A_47D6_A912_969FB3FEBFCA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FogOptions.h : header file
//
#include "ColourPickerXP.h"

/////////////////////////////////////////////////////////////////////////////
// CFogOptions dialog
class CWinFog :public CObject
{
public:
	float	m_up_x;
	UINT	m_octaves;
	float	m_up_y;
	float	m_up_z;
	float	m_turb_z;
	float	m_turb_y;
	float	m_turb_x;
	float	m_turb_depth;
	float	m_altitude;
	float	m_distance;
	float	m_lambda;
	float	m_offset;
	float	m_omega;
	int		m_fog_type;
int m_trans,m_filter;
COLORREF m_color;
CWinFog()
	{
			m_up_x = 0.0f;
	m_octaves = 6;
	m_up_y = 0.0f;
	m_up_z = 0.0f;
	m_turb_z = 0.0f;
	m_turb_y = 0.0f;
	m_turb_x = 0.0f;
	m_turb_depth = 0.0f;
	m_altitude = 5.0f;
	m_distance = 10.0f;
	m_fog_type = 0;
	m_lambda = 2.0f;
	m_offset = 0.0f;
	m_omega = 0.5f;
	int		m_fog_type=1;
	m_trans=m_filter=0;
m_color=RGB(.6*255,.6*255,.6*255);;

	}
};

class CFogOptions : public CDialog
{
// Construction
public:
	void UpdateFog(CWinFog*w);
	void FillWindow(CWinFog *w);
	CFogOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFogOptions)
	enum { IDD = IDD_FOG };
	CListBox	m_list;
	float	m_up_x;
	UINT	m_octaves;
	float	m_up_y;
	float	m_up_z;
	float	m_turb_z;
	float	m_turb_y;
	float	m_turb_x;
	float	m_turb_depth;
	float	m_altitude;
	float	m_distance;
	int		m_fog_type;
	float	m_lambda;
	float	m_offset;
	float	m_omega;
	int		m_filter;
	int		m_trans;
	//}}AFX_DATA
	CColourPickerXP m_fogcolor;
CObArray m_objects;
int cursel;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFogOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFogOptions)
	afx_msg void OnAdd();
	afx_msg void OnDelete();
	afx_msg void OnSelchangeList();
	afx_msg void OnDestroy();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOGOPTIONS_H__F198F744_7D7A_47D6_A912_969FB3FEBFCA__INCLUDED_)
