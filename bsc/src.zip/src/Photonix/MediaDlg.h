#if !defined(AFX_MEDIADLG_H__613FE19A_C9DD_41E2_B04F_720CFD7C8A52__INCLUDED_)
#define AFX_MEDIADLG_H__613FE19A_C9DD_41E2_B04F_720CFD7C8A52__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MediaDlg.h : header file
//
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CMediaDlg dialog

class CMediaDlg : public CAccessDialog//CDialog
{
// Construction
public:
	DECLARE_SERIAL(CMediaDlg)
	CMediaDlg(CWnd* pParent = NULL);   // standard constructor
virtual void Serialize(CArchive &ar);

// Dialog Data
	//{{AFX_DATA(CMediaDlg)
	enum { IDD = IDD_MEDIA };
	int		m_intervals;
	int		m_minsamples;
	int		m_maxsamples;
	float	m_confidence;
	float	m_variance;
	float	m_ratio;
	float	m_ecc;
	float	m_extinction;
	BOOL	m_is_extiction;
	BOOL	m_is_scattering;
	int		m_type;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMediaDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMediaDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MEDIADLG_H__613FE19A_C9DD_41E2_B04F_720CFD7C8A52__INCLUDED_)
