#pragma once
/*
*/
//#include "IRENDERABLE.H"
#include "gsmcamera.h"
#include "scene.h"

class ISceneObject:public CObject
{
public:
ISceneObject();
~ISceneObject();
//some methods used in the 3d editor
	void * pReserved;//for containging puposes
	virtual void UpdateObject(){};
	virtual OBJECT* Generate();
	CString RayTextureName;
	OBJECT *obj;
	BOOL GenerateCaustics;
	BOOL RecieveCaustics;
	BOOL Reflection;
	BOOL Refraction;
	BOOL HasShadow;
	IRenderable * pRenderable;
	CMapStringToOb  OptionDialogs;
int ObjectType;
};
enum
{
	OBJ_DUMMY,
	OBJ_CAMERA,
	OBJ_SPHERE,
	OBJ_TORUS,
	OBJ_BOX,
	OBJ_CYLINDER,
	OBJ_CONE,

	OBJ_LIGHT=2000,
	OBJ_POINT_LIGHT,
	OBJ_SPOT_LIGHT

};
struct SceneObjectData:public CObject
{
	//int ObjectType;
	int ArrayIndex;
	ISceneObject *pObject;
	HTREEITEM hItem;
	SceneObjectData(int objtype,ISceneObject *pObject)
	{
//		ObjectType=objtype;
		SceneObjectData::pObject=pObject;
	}
	SceneObjectData()
	{
	//	ObjectType=OBJ_DUMMY;
		hItem=0;
		pObject=NULL;
	}
};

class SphereObj:public ISceneObject//SphereMesh
{
public:
	SphereObj(void);
	virtual OBJECT* Generate();
	virtual void UpdateObject();
	virtual ~SphereObj(void);
};
class TorusObj:public ISceneObject//TorusMesh
{
public:
	TorusObj(void);
	virtual OBJECT* Generate();
	virtual void UpdateObject();
	virtual ~TorusObj(void);
};

class BoxObj:public ISceneObject//BoxMesh
{
public:
	BoxObj(void);
	virtual OBJECT* Generate();
	virtual void UpdateObject();
	virtual ~BoxObj(void);
};
struct AreaLightData
{
	bool	m_enablearea;
	UINT	m_samplesu;
	UINT	m_samplesv;
	float	m_axis1x;
	float	m_axis1y;
	float	m_axis1z;
	float	m_axis2x;
	float	m_axis2y;
	float	m_axis2z;
};
struct LightSourceData
{
	bool MediaInteraction,MediaAttenuation;
	COLORREF color;
	float Multiplier;
};

class PointLightObj:public ISceneObject,public AreaLightData,public LightSourceData//LightMesh
{
public:
	PointLightObj(void);
	virtual OBJECT* Generate();
	virtual void UpdateObject();
	virtual ~PointLightObj(void);
	
};
class SpotLightObj:public ISceneObject,public AreaLightData,public LightSourceData
{
public:
	SpotLightObj(void);
	virtual void UpdateObject();
	virtual OBJECT* Generate();
	virtual ~SpotLightObj(void);
	Real RadiusAngle,FalloffAngle;
	Real Tightness;//falloff rate
};

class ConeObj:public ISceneObject//ConeMesh
{
public:
	ConeObj(void);
	virtual OBJECT* Generate();
	virtual void UpdateObject();
	virtual ~ConeObj(void);
};

class CylinderObj:public ISceneObject//CylinderMesh
{
public:
	CylinderObj(void);
	virtual OBJECT* Generate();
	virtual void UpdateObject();
	virtual ~CylinderObj(void);
};

class MeshObj:public ISceneObject//CylinderMesh
{
public:
	MeshObj(void);
	virtual OBJECT* Generate();
	virtual void UpdateObject();
	virtual ~MeshObj(void);
	bool bSmooth;
};
class CameraObj:public ISceneObject,public ICamera
{
public :
	CameraObj(bool bCreateMesh=true,CString CameraName="");
	~CameraObj();

virtual void UpdateObject();
virtual CAMERA* GenerateCamera();

	float Blur_Samples,Aperture,Confidence,Variance;
	Vector3 Focal_Point;
	virtual Camera * GetCamera();
	Camera * camera;
};
/*
class SceneObj:public Scene,public IScene
{
public :
	virtual void GenerateScene();
	CObArray m_SceneObjects;
	CMapStringToOb m_MapSceneObjects;
void AddSceneObject(ISceneObject * pObject);
void DeleteSceneObject(ISceneObject * pObject);
void DeleteSceneObject(CString ObjectName);

};*/
