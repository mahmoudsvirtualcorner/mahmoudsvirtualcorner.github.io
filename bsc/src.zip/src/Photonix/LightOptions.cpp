// LightOptions.cpp : implementation file
//

#include "stdafx.h"
#include "photonix.h"
#include "LightOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLightOptions dialog


CLightOptions::CLightOptions(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CLightOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLightOptions)
	m_noshadow = FALSE;
	m_interaction = TRUE;
	m_attenuation = FALSE;
	m_multiplier = 1.0f;
	//}}AFX_DATA_INIT
	m_color.SetColor (RGB(255,255,255));
m_Obj=0;
}


void CLightOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLightOptions)
	DDX_Check(pDX, IDC_SHADOWLESS, m_noshadow);
	DDX_Check(pDX, IDC_MEDIA_INTERACTION, m_interaction);
	DDX_Check(pDX, IDC_MEDIA_ATTENUATION, m_attenuation);
	DDX_Text(pDX, IDC_MULTIPLIER, m_multiplier);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_LIGHT_COLOR, m_color);

}


BEGIN_MESSAGE_MAP(CLightOptions, CAccessDialog)
	//{{AFX_MSG_MAP(CLightOptions)
	ON_BN_CLICKED(IDC_SHADOWLESS, OnShadowless)
	ON_BN_CLICKED(IDC_MEDIA_ATTENUATION, OnMediaAttenuation)
	ON_BN_CLICKED(IDC_MEDIA_INTERACTION, OnMediaInteraction)
	ON_EN_KILLFOCUS(IDC_MULTIPLIER, OnKillfocusMultiplier)
	//}}AFX_MSG_MAP
	ON_MESSAGE(CPN_SELCHANGE,    OnSelChange)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLightOptions message handlers

void CLightOptions::OnShadowless() 
{
		UpdateData(true);
m_Object->HasShadow=!m_noshadow;

}

void CLightOptions::OnMediaAttenuation() 
{
		UpdateData(true);
		m_Obj->MediaAttenuation =(m_attenuation==1)?1:0;
	
}

void CLightOptions::OnMediaInteraction() 
{
		UpdateData(true);
		m_Obj->MediaInteraction  =(m_interaction==1)?1:0;
	
}
LONG CLightOptions::OnSelChange(UINT lParam, LONG wParam)
{
	m_Obj->color=m_color.GetColor();
return TRUE;
}

void CLightOptions::OnKillfocusMultiplier() 
{
	UpdateData(true);
	m_Obj->Multiplier=m_multiplier;
}
