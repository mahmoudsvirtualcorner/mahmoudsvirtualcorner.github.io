#if !defined(AFX_SLOPEMAPENTRY_H__4877E8D5_8C27_4917_BBB7_7AA79873890C__INCLUDED_)
#define AFX_SLOPEMAPENTRY_H__4877E8D5_8C27_4917_BBB7_7AA79873890C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SlopeMapEntry.h : header file
//
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CSlopeMapEntry dialog

class CSlopeMapEntry : public CAccessDialog//CDialog
{
// Construction
public:
	CSlopeMapEntry(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSlopeMapEntry)
	enum { IDD = IDD_SLOPEMAP_ENTRY };
	float	m_height;
	float	m_number;
	float	m_slope;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSlopeMapEntry)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSlopeMapEntry)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SLOPEMAPENTRY_H__4877E8D5_8C27_4917_BBB7_7AA79873890C__INCLUDED_)
