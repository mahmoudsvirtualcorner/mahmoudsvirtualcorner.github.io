// WarpDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "WarpDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWarpDlg dialog

IMPLEMENT_SERIAL(CWarpDlg,CAccessDialog,1)
CWarpDlg::CWarpDlg(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CWarpDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWarpDlg)
	m_brepeat_x = 0.0f;
	m_brepeat_y = 0.0f;
	m_brepeat_z = 0.0f;
	m_bturbulence_x = 0.0f;
	m_bturbulence_y = 0.0f;
	m_bturbulence_z = 0.0f;
	m_center_x = 0.0f;
	m_center_y = 0.0f;
	m_center_z = 0.0f;
	m_flip_x = 0.0f;
	m_flip_y = 0.0f;
	m_flip_z = 0.0f;
	m_offset_x = 0.0f;
	m_offset_y = 0.0f;
	m_offset_z = 0.0f;
	m_rrepeat_x = 0.0f;
	m_rrepeat_y = 0.0f;
	m_rrepeat_z = 0.0f;
	m_tturbulence_x = 0.0f;
	m_tturbulence_y = 0.0f;
	m_tturbulence_z = 0.0f;
	m_strength = 0.0f;
	m_octaves = 0;
	m_omega = 0.0f;
	m_radius = 0.0f;
	m_lambda = 0.0f;
	m_is_tw = FALSE;
	m_is_rw = FALSE;
	m_is_inverse = FALSE;
	m_is_bhw = FALSE;
	m_fallof = 0.0f;
	//}}AFX_DATA_INIT
}


void CWarpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWarpDlg)
	DDX_Text(pDX, IDC_BREPEAT_X, m_brepeat_x);
	DDX_Text(pDX, IDC_BREPEAT_Y, m_brepeat_y);
	DDX_Text(pDX, IDC_BREPEAT_Z, m_brepeat_z);
	DDX_Text(pDX, IDC_BTURBULENCE_X, m_bturbulence_x);
	DDX_Text(pDX, IDC_BTURBULENCE_Y, m_bturbulence_y);
	DDX_Text(pDX, IDC_BTURBULENCE_Z, m_bturbulence_z);
	DDX_Text(pDX, IDC_CENTER_X, m_center_x);
	DDX_Text(pDX, IDC_CENTER_Y, m_center_y);
	DDX_Text(pDX, IDC_CENTER_Z, m_center_z);
	DDX_Text(pDX, IDC_FLIP_X, m_flip_x);
	DDX_Text(pDX, IDC_FLIP_Y, m_flip_y);
	DDX_Text(pDX, IDC_FLIP_Z, m_flip_z);
	DDX_Text(pDX, IDC_OFFSET_X, m_offset_x);
	DDX_Text(pDX, IDC_OFFSET_Y, m_offset_y);
	DDX_Text(pDX, IDC_OFFSET_Z, m_offset_z);
	DDX_Text(pDX, IDC_RREPEAT_X, m_rrepeat_x);
	DDX_Text(pDX, IDC_RREPEAT_Y, m_rrepeat_y);
	DDX_Text(pDX, IDC_RREPEAT_Z, m_rrepeat_z);
	DDX_Text(pDX, IDC_TTURBULENCE_X, m_tturbulence_x);
	DDX_Text(pDX, IDC_TTURBULENCE_Y, m_tturbulence_y);
	DDX_Text(pDX, IDC_TTURBULENCE_Z, m_tturbulence_z);
	DDX_Text(pDX, IDC_STENGTH, m_strength);
	DDX_Text(pDX, IDC_OCTAVES, m_octaves);
	DDV_MinMaxInt(pDX, m_octaves, 0, 10);
	DDX_Text(pDX, IDC_OMEGA, m_omega);
	DDX_Text(pDX, IDC_RADIUS, m_radius);
	DDX_Text(pDX, IDC_LAMBDA, m_lambda);
	DDX_Check(pDX, IDC_IS_TW, m_is_tw);
	DDX_Check(pDX, IDC_IS_RW, m_is_rw);
	DDX_Check(pDX, IDC_IS_INVERSE, m_is_inverse);
	DDX_Check(pDX, IDC_IS_BHW, m_is_bhw);
	DDX_Text(pDX, IDC_FALLOF, m_fallof);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWarpDlg, CDialog)
	//{{AFX_MSG_MAP(CWarpDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWarpDlg message handlers
void CWarpDlg::Serialize(CArchive &ar)
{
if(ar.IsStoring ())
	{
	ar
	<<	m_brepeat_x
	<<	m_brepeat_y
	<<	m_brepeat_z
	<<	m_bturbulence_x
	<<	m_bturbulence_y
	<<	m_bturbulence_z
	<<	m_center_x
	<<	m_center_y
	<<	m_center_z
	<<	m_flip_x
	<<	m_flip_y
	<<	m_flip_z
	<<	m_offset_x
	<<	m_offset_y
	<<	m_offset_z
	<<	m_rrepeat_x
	<<	m_rrepeat_y
	<<	m_rrepeat_z
	<<	m_tturbulence_x
	<<	m_tturbulence_y
	<<	m_tturbulence_z
	<<	m_strength
	<<	m_octaves
	<<	m_omega
	<<	m_radius
	<<	m_lambda
	<<	m_is_tw
	<<	m_is_rw
	<<	m_is_inverse
	<<	m_is_bhw
	<<	m_fallof;
	}
	else
	{
	ar
	>>	m_brepeat_x
	>>	m_brepeat_y
	>>	m_brepeat_z
	>>	m_bturbulence_x
	>>	m_bturbulence_y
	>>	m_bturbulence_z
	>>	m_center_x
	>>	m_center_y
	>>	m_center_z
	>>	m_flip_x
	>>	m_flip_y
	>>	m_flip_z
	>>	m_offset_x
	>>	m_offset_y
	>>	m_offset_z
	>>	m_rrepeat_x
	>>	m_rrepeat_y
	>>	m_rrepeat_z
	>>	m_tturbulence_x
	>>	m_tturbulence_y
	>>	m_tturbulence_z
	>>	m_strength
	>>	m_octaves
	>>	m_omega
	>>	m_radius
	>>	m_lambda
	>>	m_is_tw
	>>	m_is_rw
	>>	m_is_inverse
	>>	m_is_bhw
	>>	m_fallof;
	}
}