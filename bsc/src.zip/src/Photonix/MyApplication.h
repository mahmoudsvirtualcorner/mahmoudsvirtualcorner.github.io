#pragma once
#include "windowedapplication.h"

class CMyApplication :	public CWindowedApplication,public IFrameReciever,public IMessageReciever
{
public:
	CMyApplication(void);
	~CMyApplication(void);

	//overrided function
	virtual void CreateWindows();
	virtual void CleanUp(void);

	//message routing
	virtual bool FrameStarted(int LastFrameTime);
	virtual bool FrameEnded(int LastFrameTime);
	virtual void CreateScenes();

	virtual void OnMessage(GUIWnd* wnd,unsigned int Message,Real wParam,Real lParam);
void SelectRenderEngine();

		GUIWindow *Modal;
//HWND Parentwnd,NeededWnd;
IMouseProvider * Router;
virtual void CreateInput(void);
};
