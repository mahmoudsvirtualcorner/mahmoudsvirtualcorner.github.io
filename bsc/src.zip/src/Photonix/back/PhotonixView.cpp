// PhotonixView.cpp : implementation of the CPhotonixView class
//

#include "stdafx.h"
#include "Photonix.h"

#include "PhotonixDoc.h"
#include "PhotonixView.h"
#include "mainfrm.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#include "renderwindow.h"
#include "viewport.h"
#include "sceneselector.h"

/////////////////////////////////////////////////////////////////////////////
// CPhotonixView
int CPhotonixView::ViewPortCounter=0;

IMPLEMENT_DYNCREATE(CPhotonixView, CView)

BEGIN_MESSAGE_MAP(CPhotonixView, CView)
	//{{AFX_MSG_MAP(CPhotonixView)
	// NOTE - the ClassWizard will add and remove mapping macros here.
	//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_WM_ERASEBKGND()
	ON_WM_ACTIVATE()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
	ON_WM_PAINT()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPhotonixView construction/destruction

CPhotonixView::CPhotonixView()
{
	// TODO: add construction code here
	win=NULL;
	s="";
}

CPhotonixView::~CPhotonixView()
{
}

BOOL CPhotonixView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPhotonixView drawing

void CPhotonixView::OnDraw(CDC* pDC)
{
	CPhotonixDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
//	pDC->TextOut (0,0,RenderWnd.m_CurCamera->Name );
}

/////////////////////////////////////////////////////////////////////////////
// CPhotonixView diagnostics

#ifdef _DEBUG
void CPhotonixView::AssertValid() const
{
	CView::AssertValid();
}

void CPhotonixView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPhotonixDoc* CPhotonixView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPhotonixDoc)));
	return (CPhotonixDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPhotonixView message handlers

void CPhotonixView::OnInitialUpdate()
{
	CView::OnInitialUpdate();
	//create the shared dialogs
	CPhotonixDoc * pDoc=this->GetDocument ();
	if(!pDoc->DialogsCreated)
	{

		CWnd* mwnd=AfxGetMainWnd ();
		CPhotonixDoc::RenderDlg.m_Window.SetPictureRect(CRect (0,0,200 ,200));
		CPhotonixDoc::RenderDlg.Create (IDD_DIALOG1,mwnd);
		CPhotonixDoc::TextureEditor.Create (IDD_TEXMAKER_DIALOG,mwnd);
		pDoc->m_ObjectsTree.Create (IDD_OBJTREE,mwnd);
		pDoc->m_ObjectsTree.pDoc=pDoc;
		//finished creating dialogs
		this->GetDocument ()->DialogsCreated=true;

	}
	CRect r;
	this->GetClientRect (&r);
	RenderWnd.Create (NULL,"",WS_VISIBLE|WS_CHILD,r,this,1000);
	RenderWnd .pDoc=this->GetDocument ();
	CMyApplication * app=this->GetDocument ()->MainApp;
	win= app->rs ->createRenderWindow (RenderWnd.GetSafeHwnd (),24);
	app->rs->mRenderIn .Add (win);
//win->Register (&RenderWnd);
	//->&RenderWnd);
	//int width, height,colourDepth,left,top;
	//window->getMetrics(width,height,colourDepth,left,top);
	//create viewport
	if(s=="")
	{
	//create a new viewport for this camera
		CViewPort *vp1=new CViewPort( win,0,0,1,1,TRUE);//"my view port1"
		vp1->Clear =true;
		vp1->BackColour=ColourValue(.5,.5,.5);//ColourValue ::Blue ;
		s.Format ("view port%d",ViewPortCounter);
		ViewPortCounter++;
		app->mViewPorts[s]=vp1;
	
		//create a new scene selector also	
		CString s1;
		s1="SceneSel1";
		if(pDoc->m_Selector==NULL)
		{
	//	SceneSelector *Scene1Sel=new SceneSelector();
	//	Scene1Sel->SelCamera=(Camera*)app->mCameras["Camera1"];
	//	Scene1Sel->SelScene=(Scene*)app->mScenes ["Scene1"];
	//	CString s1;
		//s1.Format ("SceneSel%d",ViewPortCounter);
	//	s1="SceneSel1";
	//	app->mSelectors[s1]=Scene1Sel;
		pDoc->m_Selector=(SceneSelector *)app->mSelectors[s1];
		pDoc->m_Selector->Register (&pDoc->m_ObjectsTree);
		//	->Register (
		//and the selector take input from this
		}
		
		
		vp1->mSelector=pDoc->m_Selector;
		RenderWnd.Register ((SceneSelector*)app->mSelectors[s1]);

	}
	

	
//set the view port to viwndow and assign camera and scene to it
	Camera* cam=(Camera*)app->mCameras["Camera1"];
	((CViewPort*)app->mViewPorts[s])->mCamera=cam;
((CViewPort*)app->mViewPorts[s])->scene=(Scene*)app->mScenes ["Scene1"];
win->mViewPorts.Add((CViewPort*)app->mViewPorts[s]);

RenderWnd.m_CurCamera=cam;



}

void CPhotonixView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);
	if(win)
	RenderWnd.MoveWindow(0,0,cx,cy);
}

void CPhotonixView::OnDestroy()
{
	CView::OnDestroy();
	CMyApplication * app=this->GetDocument ()->MainApp;
	int count=app->rs->mRenderIn .GetSize ();
	for (int i=0;i<count;i++)
	{
		if(win==(RenderWindow*)app->rs->mRenderIn [i])
		{
			app->rs->mRenderIn .RemoveAt (i);
			delete win;
		break;
		}
	}
}

BOOL CPhotonixView::OnEraseBkgnd(CDC* pDC)
{
	// TODO: Add your message handler code here and/or call default
return TRUE; 
	//return CView::OnEraseBkgnd(pDC);
}

void CPhotonixView::OnUpdate(CView* /*pSender*/, LPARAM lHint, CObject* /*pHint*/)
{
	if(lHint)
	{
		this->Invalidate ();
	}
}

void CPhotonixView::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
	CView::OnActivate(nState, pWndOther, bMinimized);
//	CMyApplication * app=this->GetDocument ()->MainApp;
//	((SceneSelector*)app->mSelectors[])->SelCamera=(Camera*)app->mCameras["Camera1"];
}

void CPhotonixView::OnSetFocus(CWnd* pOldWnd)
{
	CView::OnSetFocus(pOldWnd);

	// TODO: Add your message handler code here
		((CMainFrame*)GetParentFrame())->m_wndSplitter.RefreshSplitBars();

}

void CPhotonixView::OnKillFocus(CWnd* pNewWnd)
{
	CView::OnKillFocus(pNewWnd);
	((CMainFrame*)GetParentFrame())->m_wndSplitter.RefreshSplitBars();

	// TODO: Add your message handler code here
}

void CPhotonixView::OnPaint()
{
//	CPaintDC dc(this); // device context for painting
	// TODO: Add your message handler code here
	// Do not call CView::OnPaint() for painting messages
//	dc.TextOut (0,0,RenderWnd.m_CurCamera->Name );
/*	if(RenderWnd.m_hWnd)
	{
	CDC * dc=RenderWnd.GetDC (); // device context for painting
	dc->TextOut (0,0,RenderWnd.m_CurCamera->Name );
RenderWnd.ReleaseDC (dc);
	}*/
}
