#if !defined(AFX_MATERIALSDLG_H__02AA8141_E0B3_413A_9653_62B9E4C17470__INCLUDED_)
#define AFX_MATERIALSDLG_H__02AA8141_E0B3_413A_9653_62B9E4C17470__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MaterialsDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMaterialsDlg dialog

class CMaterialsDlg : public CDialog
{
// Construction
public:
	CMaterialsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMaterialsDlg)
	enum { IDD = IDD_MATERIALS };
	CListCtrl	m_matlist;
	//}}AFX_DATA
int m_Searchtype;
CString m_MaterialName;
CImageList m_pImageList ;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMaterialsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMaterialsDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MATERIALSDLG_H__02AA8141_E0B3_413A_9653_62B9E4C17470__INCLUDED_)
