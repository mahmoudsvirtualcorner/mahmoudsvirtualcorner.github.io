#if !defined(AFX_PHOTONMAPPINGOPTIONS_H__9E6FD328_9C36_4375_B9FB_20F85BCD0447__INCLUDED_)
#define AFX_PHOTONMAPPINGOPTIONS_H__9E6FD328_9C36_4375_B9FB_20F85BCD0447__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PhotonMappingOptions.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPhotonMappingOptions dialog

class CPhotonMappingOptions : public CDialog
{
// Construction
public:
	void UpdateFileEnable();
	void UpdateSpacingAndCount();
	CPhotonMappingOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPhotonMappingOptions)
	enum { IDD = IDD_PHOTON_GLOBAL_OPTIONS };
	float	m_spacing;
	BOOL	m_usepm;
	float	m_adcbailout;
	CString	m_filename;
	float	m_jitter;
	float	m_maxtracelevel;
	long	m_photoncount;
	BOOL	m_save;
	BOOL	m_usefile;
	BOOL	m_usespacing;
	BOOL	m_mediaphoton;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPhotonMappingOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPhotonMappingOptions)
	afx_msg void OnUsefiles();
	afx_msg void OnUsespacingcount();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PHOTONMAPPINGOPTIONS_H__9E6FD328_9C36_4375_B9FB_20F85BCD0447__INCLUDED_)
