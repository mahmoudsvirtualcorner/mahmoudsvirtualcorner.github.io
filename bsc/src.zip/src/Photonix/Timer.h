
#ifndef __Timer_H__
#define __Timer_H__

    class  Timer 
	{
	protected:	
		clock_t zeroClock ;
	
	public:
		/** Resets timer 
		*/
		virtual void reset()
		{
			zeroClock = clock();
		}
		
		/** Returns milliseconds since initialisation or last reset
		*/
		virtual unsigned long getMilliseconds() 
		{
			clock_t newClock = clock();
			return (unsigned long)((float)(newClock-zeroClock) / ((float)CLOCKS_PER_SEC/1000.0)) ;
		}
		
		
		
	} ;
#endif
