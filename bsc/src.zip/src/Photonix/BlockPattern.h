#if !defined(AFX_BLOCKPATTERN_H__9EE50359_A956_421A_BE10_757A5F3EE37A__INCLUDED_)
#define AFX_BLOCKPATTERN_H__9EE50359_A956_421A_BE10_757A5F3EE37A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BlockPattern.h : header file
//
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CBlockPattern dialog

class CBlockPattern : public CAccessDialog//CDialog
{
// Construction
public:
	DECLARE_SERIAL(CBlockPattern)
	CBlockPattern(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CBlockPattern)
	enum { IDD = IDD_BLOCK_PATTERN };
	int		m_type;
	float	m_bricksize;
	float	m_length_x;
	float	m_length_y;
	float	m_length_z;
	float	m_mortar;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBlockPattern)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CBlockPattern)
	afx_msg void OnSizeOne();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BLOCKPATTERN_H__9EE50359_A956_421A_BE10_757A5F3EE37A__INCLUDED_)
