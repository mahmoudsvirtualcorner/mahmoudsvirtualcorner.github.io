// TextureTreeParser.cpp: implementation of the CTextureTreeParser class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Photonix.h"


#include "texparse.h"

#include "TexMakerDlg.h"
#include "BitmapModifier.h"
#include "BlockPattern.h"
#include "FinishDlg.h"
#include "MapEntry.h"
#include "TextureTreeParser.h"
#include "SelectColor.h"
#include "slopemap.h"
#include "pigment.h"
#include "interior.h"
//engine includes
#include "colour.h"
#include "image.h"
#include "matrices.h"
#include "helpers.h"
#include "vector.h"

#include "TextureTreeParser.h"
#include "InteriorDlg.h"
#include "MediaDlg.h"
#include "RainbowOptions.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTextureTreeParser::CTextureTreeParser()
{
	Default_Texture = new TEXTURE();
	Default_Texture->Pigment = new PIGMENT();
	Default_Texture->Tnormal = NULL;
	Default_Texture->Finish  = new FINISH();

}

CTextureTreeParser::~CTextureTreeParser()
{
	FreeMaterials();
Destroy_Textures (Default_Texture);
}
void CTextureTreeParser::GenerateTexture()
{
	FreeMaterials();


	HTREEITEM hroot=m_tree->GetRootItem ();//GetChildItem (hCurItem);

	HTREEITEM h=hroot;//this->m_tree.GetChildItem (hroot);
	if(!h) return;
	HTREEITEM h2=h;
	do
	{

	//	CString s=this->m_tree->GetItemText (h2);
		ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
		if(d->menutype ==I_MATERIAL)
		{
			INTERIOR *i=NULL;
			CObject* Ret=(CObject*)ParseTexture(m_tree->GetChildItem (h2),&i);
			if(Ret)
			{

				Textures[d->Name ]=Ret;
			}
			if(i)
				{
					Interiors[d->Name]=(CObject*)i;
				}
			
		}
		else if(d->menutype ==I_RAINBOW_MATERIAL)
		{
			Rainbows[d->Name]=(CObject*)  ParseRainbow(h2);
		}
		else if(d->menutype ==I_SKY_SPHERE)
		{
			SkySpheres[d->Name]=(CObject*)ParseSkySphere(h2);
		}
		h2=this->m_tree->GetNextSiblingItem(h2);
	}
	while(h2);	
//	texglobal=(TEXTURE*)Textures["Material1"];

}

TEXTURE * CTextureTreeParser::ParseStanderdTexture( HTREEITEM hitem)
{
	TEXTURE *New = new TEXTURE();
	New->Pigment = new PIGMENT();
	New->Tnormal = NULL;
	New->Finish  = new FINISH();
	
	
	HTREEITEM h=m_tree->GetChildItem (hitem);
	
	if(!h) return NULL;
	HTREEITEM h2=h;
	do{
		
		ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
		if(d->menutype ==I_TEX_PIGMENT)
		{
			ParsePigment(h2,New->Pigment);
		}
		else if(d->menutype ==I_TEX_NORMAL)
		{
			New->Tnormal=new TNORMAL();
			ParseNormal(h2,New->Tnormal);

		}
		else if(d->menutype ==I_TEX_FINISH)
		{
		CFinishDlg* dlg=((CFinishDlg*)	d->data["CFinishDlg"]);
		dlg->Fill(New->Finish);
		}
		
		h2=m_tree->GetNextSiblingItem(h2);
	}
	while(h2);	


	{
		ItemDATA* d=(ItemDATA*)m_tree->GetItemData (hitem);
	CString s=	m_tree->GetItemText (hitem);
			CTransformation* dlg =(CTransformation*)d->data ["CTransformation"];
			
			Parse_Texture_Tranformation(dlg,New);

		
	}
	return New;
}
TEXTURE * CTextureTreeParser::ParseLayeredTexture(HTREEITEM hitem)
{
	TEXTURE *Texture=NULL;
HTREEITEM h= m_tree->GetChildItem (hitem);

	TEXTURE *Local_Texture;

	if(!h) return 0;
	HTREEITEM h2=h;
//	Texture->Num_Of_Mats=0;
	do
	{
		//if(Texture->Num_Of_Mats==0)
		//{
		//	Texture->Materials= Local_Texture =ParseTexture(h2);//m_tree.GetChildItem (h2)
			Local_Texture =ParseTexture(h2,NULL);
			Link_Textures(&Texture, Local_Texture);
	//	}
	//	else
	//	{
		//	Local_Texture->Next_Material =ParseTexture(h2);//m_tree.GetChildItem (h2)
		//	Local_Texture = Local_Texture->Next_Material;
		//	Texture->Num_Of_Mats++;
	//	}

		h2=m_tree->GetNextSiblingItem(h2);
	}
	while(h2);
	return Texture;
}
TEXTURE * CTextureTreeParser::ParseMaterialMap(HTREEITEM hitem)
{
	TEXTURE *Texture = new TEXTURE();
	/*New->Pigment = new PIGMENT();
	New->Tnormal = NULL;
	New->Finish  = new FINISH();*/
	Texture->Pigment = NULL;
	Texture->Tnormal = NULL;
	Texture->Finish  = NULL;
	Texture->Type = BITMAP_PATTERN;


	// pig->Type = BITMAP_PATTERN;
	//       pig->Frequency = 0.0;

	ItemDATA* d=(ItemDATA*)m_tree->GetItemData (hitem);
	CBitmapModifier * dlg=((CBitmapModifier *)d->data["CBitmapModifier"]);
	IMAGE *Image;
	Image= Create_Image ();
	Image->Image_Type = IMAGE_FILE;
	READ_SYS_IMAGE(Image, dlg->m_filename.GetBuffer (256) );
	Image->Use_Colour_Flag = false;
	Image->Once_Flag=dlg->m_once ;
	Image->Map_Type=dlg->m_maptype ;
	if(dlg->m_maptype==3)
	{  
		Image->Map_Type=5;
	}
	else if(dlg->m_maptype==4)
	{  
		Image->Map_Type=8;
	}
	if(dlg->m_interpolation==1)
		Image->Interpolation_Type =2 ;
	else if(dlg->m_interpolation==2)
		Image->Interpolation_Type =4 ;
	Texture->Vals.Image=Image;

	HTREEITEM h= m_tree->GetChildItem (hitem);

	TEXTURE *Local_Texture;

	if(!h) return 0;
	HTREEITEM h2=h;
	Texture->Num_Of_Mats=0;
	do
	{

	//	CString s=this->m_tree .GetItemText (h2);
		if(Texture->Num_Of_Mats==0)
		{
			Texture->Materials= Local_Texture =ParseTexture(h2,NULL);//m_tree.GetChildItem (h2)
			Texture->Num_Of_Mats++;
		}
		else
		{
			Local_Texture->Next_Material =ParseTexture(h2,NULL);//m_tree.GetChildItem (h2)
			Local_Texture = Local_Texture->Next_Material;
			Texture->Num_Of_Mats++;
		}

		h2=m_tree->GetNextSiblingItem(h2);
	}
	while(h2);	
	return Texture;


}
void CTextureTreeParser::ParseDenisty(HTREEITEM hitem,PIGMENT* pig)
{
	{
		ItemDATA* d=(ItemDATA*)m_tree->GetItemData (hitem);
		CTransformation* dlg =(CTransformation*)d->data ["CTransformation"];
		VECTOR Vector;
		TRANSFORM Trans;
		Make_Vector(Vector,dlg->m_trans_x,dlg->m_trans_y,dlg->m_trans_z);
		Compute_Translation_Transform (&Trans, Vector);
		Transform_Tpattern ((TPATTERN*)pig, &Trans);

		Make_Vector(Vector,dlg->m_rot_x ,dlg->m_rot_y,dlg->m_rot_z);
		Compute_Rotation_Transform (&Trans, Vector);
		Transform_Tpattern ((TPATTERN*)pig, &Trans);

		Make_Vector(Vector,dlg->m_scale_x,dlg->m_scale_y,dlg->m_scale_z);
		Compute_Scaling_Transform (&Trans, Vector);
		Transform_Tpattern ((TPATTERN*)pig, &Trans);

		CNoiseModifier * nm=(CNoiseModifier*)d->data ["CNoiseModifier"];
		ParseNoiseModifier(nm,(TPATTERN*)pig);

		CWarpDlg * wd=(CWarpDlg*)d->data ["CWarpDlg"];
		ParseWarp(wd,&(pig->Warps));
	}
	HTREEITEM h=m_tree->GetChildItem (hitem);
	
	if(!h) return;
	HTREEITEM h2=h;
	
	do{
		ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
		if(d->menutype ==I_DENISTY_PAT)
		{
			ParsePattern(((CNoisePattern*)d->data["CNoisePattern"]),pig);
		}
		else if(d->menutype ==I_BP_WITH_DENISTY)
		{
			ParseBlockPattern(h2,(TPATTERN*)pig,DENSITY_TYPE);
		}
		else if(d->menutype == I_DENISTY_MAP)
		{
			ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);

			ParsePattern(((CNoisePattern*)d->data["CNoisePattern"]),pig);

			Destroy_Blend_Map(pig->Blend_Map);

			HTREEITEM myitem=m_tree->GetChildItem (h2);
			pig->Blend_Map= Parse_Blend_List( myitem,0,DENSITY_TYPE,0);

		}
		else if(d->menutype ==I_COLOR_MAP)
		{
					CGradient & g=((CSelectColor*)d->data["CSelectColor"])->m_wndGradientCtrl .GetGradient ();
			///////////
			//setting the color map
			int m=g.GetPegCount();
			BLEND_MAP *New;
			BLEND_MAP_ENTRY *Temp_Ent;
		//	BLEND_MAP *Def_Map;
			Temp_Ent = Create_BMap_Entries(m+2);
			
		//	m_StartPeg, m_EndPeg, 
			Make_ColourA(Temp_Ent[0].Vals.Colour,
				GetRValue(g.m_StartPeg.colour)/255.0,GetGValue(g.m_StartPeg.colour)/255.0,
				GetBValue(g.m_StartPeg.colour)/255.0,g.m_StartPeg.filter /10000.0,
				g.m_StartPeg.trans/10000.0 );
			Temp_Ent[0].value=0.0;
			for(int i=0;i<m;i++)
			{
				CPeg  p=g.GetPeg (i);
				Make_ColourA(Temp_Ent[i+1].Vals.Colour,
				GetRValue(p.colour)/255.0,GetGValue(p.colour)/255.0,
				GetBValue(p.colour)/255.0,p.filter /10000.0,
				p.trans/10000.0 );
				Temp_Ent[i+1].value=p.position;
			}
			Make_ColourA(Temp_Ent[m+1].Vals.Colour,
				GetRValue(g.m_EndPeg.colour)/255.0,GetGValue(g.m_EndPeg.colour)/255.0,
				GetBValue(g.m_EndPeg.colour)/255.0,g.m_EndPeg.filter /10000.0,
				g.m_EndPeg.trans/10000.0 );
			Temp_Ent[m+1].value=1.0;


			New = Create_Blend_Map ();
			New->Number_Of_Entries = m+2;
			New->Type=COLOUR_TYPE;
		//	 New->Transparency_Flag=true; //Temp fix.  Really set in Post_???
			New->Blend_Map_Entries = Temp_Ent;
			Destroy_Blend_Map(pig->Blend_Map);
			pig->Blend_Map=New;
			//////////.............
			ParsePattern(((CNoisePattern*)d->data["CNoisePattern"]),pig);
			
		}
		
		h2=m_tree->GetNextSiblingItem(h2);
	}
	while(h2);
	
}
void CTextureTreeParser::ParsePigment(HTREEITEM hitem,PIGMENT* pig)
{
	{
		ItemDATA* d=(ItemDATA*)m_tree->GetItemData (hitem);
		
			CTransformation* dlg =(CTransformation*)d->data ["CTransformation"];
			VECTOR Vector;
			TRANSFORM Trans;
			Make_Vector(Vector,dlg->m_trans_x,dlg->m_trans_y,dlg->m_trans_z);
			Compute_Translation_Transform (&Trans, Vector);
			Transform_Tpattern (pig, &Trans);

			Make_Vector(Vector,dlg->m_rot_x ,dlg->m_rot_y,dlg->m_rot_z);
			Compute_Rotation_Transform (&Trans, Vector);
			Transform_Tpattern (pig, &Trans);

			Make_Vector(Vector,dlg->m_scale_x,dlg->m_scale_y,dlg->m_scale_z);
			Compute_Scaling_Transform (&Trans, Vector);
			Transform_Tpattern (pig, &Trans);

			CNoiseModifier * nm=(CNoiseModifier*)d->data ["CNoiseModifier"];
			ParseNoiseModifier(nm,(TPATTERN*)pig);

			CWarpDlg * wd=(CWarpDlg*)d->data ["CWarpDlg"];
			ParseWarp(wd,&(pig->Warps));
		
	}
	HTREEITEM h=m_tree->GetChildItem (hitem);
	if(!h) return;
	HTREEITEM h2=h;
	do{
				
		ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
		if(d->menutype ==I_BP_WITH_COLOR)
		{
			ParseBlockPattern(h2,(TPATTERN*)pig,COLOUR_TYPE);	
		}
		if(d->menutype ==I_BP_WITH_PIGMENT)
		{
			ParseBlockPattern(h2,(TPATTERN*)pig,PIGMENT_TYPE);	
		}
		if(d->menutype ==I_COLOR_MAP)
		{
//			CRollUpDlg *dlg=(CRollUpDlg*)	d->data;
			
			CGradient & g=((CSelectColor*)d->data["CSelectColor"])->m_wndGradientCtrl .GetGradient ();
			///////////
			//setting the color map
			int m=g.GetPegCount();
			BLEND_MAP *New;
			BLEND_MAP_ENTRY *Temp_Ent;
		//	BLEND_MAP *Def_Map;
			Temp_Ent = Create_BMap_Entries(m+2);
			
		//	m_StartPeg, m_EndPeg, 
			Make_ColourA(Temp_Ent[0].Vals.Colour,
				GetRValue(g.m_StartPeg.colour)/255.0,GetGValue(g.m_StartPeg.colour)/255.0,
				GetBValue(g.m_StartPeg.colour)/255.0,g.m_StartPeg.filter /10000.0,
				g.m_StartPeg.trans/10000.0 );
			Temp_Ent[0].value=0.0;
			for(int i=0;i<m;i++)
			{
				CPeg  p=g.GetPeg (i);
				Make_ColourA(Temp_Ent[i+1].Vals.Colour,
				GetRValue(p.colour)/255.0,GetGValue(p.colour)/255.0,
				GetBValue(p.colour)/255.0,p.filter /10000.0,
				p.trans/10000.0 );
				Temp_Ent[i+1].value=p.position;
			}
			Make_ColourA(Temp_Ent[m+1].Vals.Colour,
				GetRValue(g.m_EndPeg.colour)/255.0,GetGValue(g.m_EndPeg.colour)/255.0,
				GetBValue(g.m_EndPeg.colour)/255.0,g.m_EndPeg.filter /10000.0,
				g.m_EndPeg.trans/10000.0 );
			Temp_Ent[m+1].value=1.0;


			New = Create_Blend_Map ();
			New->Number_Of_Entries = m+2;
			New->Type=COLOUR_TYPE;
		//	 New->Transparency_Flag=true; //Temp fix.  Really set in Post_???
			New->Blend_Map_Entries = Temp_Ent;
			Destroy_Blend_Map(pig->Blend_Map);
			pig->Blend_Map=New;
			//////////.............
			ParsePattern(((CNoisePattern*)d->data["CNoisePattern"]),pig);
			
			
		}
		else if(d->menutype ==I_PIGMENT_MAP)
		{
			ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);

			ParsePattern(((CNoisePattern*)d->data["CNoisePattern"]),pig);

			Destroy_Blend_Map(pig->Blend_Map);

			HTREEITEM myitem=m_tree->GetChildItem (h2);
			pig->Blend_Map= Parse_Blend_List( myitem,0,PIGMENT_TYPE,0);

		}
		else if(d->menutype ==I_IMAGE_MAP)
		{
		pig->Type = BITMAP_PATTERN;
       pig->Frequency = 0.0;

			ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
			CBitmapModifier * dlg=((CBitmapModifier *)d->data["CBitmapModifier"]);
			IMAGE *Image;
			Image= Create_Image ();
			Image->Image_Type = IMAGE_FILE;
			READ_SYS_IMAGE(Image, dlg->m_filename.GetBuffer (256) );
			Image->Use_Colour_Flag = true;
			Image->Once_Flag=dlg->m_once ;
			Image->Map_Type=dlg->m_maptype ;
			if(dlg->m_maptype==3)
			{  
				Image->Map_Type=5;
			}
			else if(dlg->m_maptype==4)
			{  
				Image->Map_Type=8;
			}
			if(dlg->m_interpolation==1)
				Image->Interpolation_Type =2 ;
			else if(dlg->m_interpolation==2)
				Image->Interpolation_Type =4 ;
			pig->Vals.Image=Image;
		}
		else if(d->menutype ==I_TEX_COLOR)
		{
			CSelectColor* dlg=((CSelectColor*)d->data["CSelectColor"]);
			pig->Type = PLAIN_PATTERN;
			Make_ColourA(pig->Colour,
				GetRValue(dlg->m_col)/255.0,GetGValue(dlg->m_col)/255.0,
				GetBValue(dlg->m_col)/255.0,dlg->filter/10000.0,
				dlg->trans/10000.0 );
			
		}
		
		h2=m_tree->GetNextSiblingItem(h2);
		
	}
	while(h2);
}
void CTextureTreeParser::ParseBlockPattern(HTREEITEM hitem,TPATTERN * New,int type)
{
	//defines
	int nCount;
	
	HTREEITEM h=hitem;//m_tree->.GetChildItem (hitem);
	
	if(!h) return;
	ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h);
	CBlockPattern * pat=((CBlockPattern*)d->data["CBlockPattern"]) ;
	if(pat->m_type ==0 )
	{
		New->Type = CHECKER_PATTERN;
     New->Frequency = 0.0;

		nCount=2;
	}
	else if(pat->m_type ==1)
	{
		New->Type = HEXAGON_PATTERN;
       New->Frequency = 0.0;
		nCount=3;
	}
	else if(pat->m_type ==2)
	{
		if (New->Type!=BRICK_PATTERN)
		{
			//     Make_Vector(New->Vals.Brick.Size,8.0,3.0,4.5);
			//   New->Vals.Brick.Mortar=0.5-Small_Tolerance*2.0;
			Make_Vector (New->Vals.Brick.Size, pat->m_length_x , pat->m_length_y, pat->m_length_z);
			New->Vals.Brick.Mortar=pat->m_mortar ;
			New->Type = BRICK_PATTERN;
		}
		nCount=2;
		New->Frequency = 0.0;
	}
	Destroy_Blend_Map(New->Blend_Map);
	
	HTREEITEM h2=m_tree->GetChildItem (hitem);
//AfxMessageBox ( m_tree->GetItemText(h2));
	New->Blend_Map= Parse_Blend_List( h2,nCount,type,New->Type);

	
	
}
TEXTURE * CTextureTreeParser::ParseTexture(HTREEITEM h,INTERIOR ** Interior)
{
	//	HTREEITEM h=m_tree->.GetChildItem (hitem);

	if(!h) return NULL;
	
	TEXTURE * RetTexture=NULL;
	do{
		HTREEITEM h2=h;
		ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
		if(d->menutype ==I_STANDARD_TEX || d->menutype ==I_TEX_MAP_VAL)
		{
			RetTexture= ParseStanderdTexture(h2);
		}
		else if(d->menutype ==I_TEX_MAP)
		{
			TEXTURE *tex=new TEXTURE();

			tex->Pigment = new PIGMENT();
			tex->Tnormal = NULL;
			tex->Finish  = new FINISH ();

			ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);

			ParsePattern(((CNoisePattern*)d->data["CNoisePattern"]),tex);

			Destroy_Blend_Map(tex->Blend_Map);

			HTREEITEM myitem=m_tree->GetChildItem (h2);
			tex->Blend_Map= Parse_Blend_List( myitem,0,TEXTURE_TYPE,0);
			if(!myitem)
			{
				AfxMessageBox("Texture Map Must Have At Least One Item Canceling Generation Of Item");
				delete tex;
				tex=0;
				break;
			}
			
			{
				//	ItemDATA* d=(ItemDATA*)m_tree->GetItemData (hitem);

				CTransformation* dlg =(CTransformation*)d->data ["CTransformation"];
				VECTOR Vector;
				TRANSFORM Trans;
				Make_Vector(Vector,dlg->m_trans_x,dlg->m_trans_y,dlg->m_trans_z);
				Compute_Translation_Transform (&Trans, Vector);
				Transform_Textures (tex, &Trans);

				Make_Vector(Vector,dlg->m_rot_x ,dlg->m_rot_y,dlg->m_rot_z);
				Compute_Rotation_Transform (&Trans, Vector);
				Transform_Textures (tex, &Trans);

				Make_Vector(Vector,dlg->m_scale_x,dlg->m_scale_y,dlg->m_scale_z);
				Compute_Scaling_Transform (&Trans, Vector);
				Transform_Textures (tex, &Trans);

				CNoiseModifier * nm=(CNoiseModifier*)d->data ["CNoiseModifier"];
				ParseNoiseModifier(nm,(TPATTERN*)tex);

				CWarpDlg * wd=(CWarpDlg*)d->data ["CWarpDlg"];
				ParseWarp(wd,&(tex->Warps));
			}
			RetTexture=	tex;//ParseTextureMap(h2);
		}
		else if(d->menutype ==I_TEX_LAYERED)
		{
			RetTexture=	ParseLayeredTexture(h2);
		}
		else if(d->menutype ==I_MATERIAL_MAP)
		{
			RetTexture=	ParseMaterialMap(h2);
		}
		else if(d->menutype ==I_TEX_BP)
		{
			TEXTURE *tex=new TEXTURE();

			tex->Pigment = new PIGMENT();
			tex->Tnormal = NULL;
			tex->Finish  = new FINISH ();
			((TPATTERN*)tex->Pigment )->Blend_Map ;

			ParseBlockPattern(h2,(TPATTERN*)tex,TEXTURE_TYPE);
			{
				ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);

				CTransformation* dlg =(CTransformation*)d->data ["CTransformation"];
				VECTOR Vector;
				TRANSFORM Trans;
				Make_Vector(Vector,dlg->m_trans_x,dlg->m_trans_y,dlg->m_trans_z);
				Compute_Translation_Transform (&Trans, Vector);
				Transform_Textures (tex, &Trans);

				Make_Vector(Vector,dlg->m_rot_x ,dlg->m_rot_y,dlg->m_rot_z);
				Compute_Rotation_Transform (&Trans, Vector);
				Transform_Textures (tex, &Trans);

				Make_Vector(Vector,dlg->m_scale_x,dlg->m_scale_y,dlg->m_scale_z);
				Compute_Scaling_Transform (&Trans, Vector);
				Transform_Textures (tex, &Trans);

				CNoiseModifier * nm=(CNoiseModifier*)d->data ["CNoiseModifier"];
				ParseNoiseModifier(nm,(TPATTERN*)tex);

				CWarpDlg * wd=(CWarpDlg*)d->data ["CWarpDlg"];
				ParseWarp(wd,&(tex->Warps));
			}
			RetTexture= tex;
		}
		else  if(d->menutype ==I_INTERIOR)
		{
			ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h);
			CInteriorDlg* dlg=(CInteriorDlg*)d->data ["CInteriorDlg"];
			(*Interior)=Create_Interior ();
			(*Interior)->IOR =dlg->m_ior ;
			if(dlg->m_is_caustics)
			{
				(*Interior)->Caustics =dlg->m_cpower * 45.0;
			}
			if(dlg->m_is_fade)
			{
				(*Interior)->Fade_Power =dlg->m_fpower ;
				(*Interior)->Fade_Distance =dlg->m_distance ;
			}
		(*Interior)->Dispersion=dlg->m_dispersion;
		(*Interior)->Disp_NElems=dlg->m_disersionsamples;
			HTREEITEM h2=m_tree->GetChildItem (h);
			if(h2) 
			{
				
				IMEDIA *IMedia,*Next_Media=(*Interior)->IMedia;
				do
				{
					d=(ItemDATA*)m_tree->GetItemData (h2);
					Next_Media = (*Interior)->IMedia;
					IMedia = Create_Media();
					CMediaDlg* medlg=(CMediaDlg*)d->data ["CMediaDlg"];

					IMedia->Intervals=medlg->m_intervals;
					IMedia->Min_Samples=medlg->m_minsamples ;
					IMedia->Max_Samples =medlg->m_maxsamples;
					IMedia->Confidence =medlg->m_confidence ;
					IMedia->Variance =medlg->m_variance ;
					IMedia->Ratio =medlg->m_ratio ;
					if(medlg->m_is_scattering )
					{
						IMedia->Type =medlg->m_type +1;
						if(IMedia->Type ==5)
						{
							IMedia->Eccentricity=medlg->m_ecc ;
						}
						if(medlg->m_is_extiction )
						{
							Make_Colour (IMedia->Extinction,medlg->m_extinction,medlg->m_extinction,medlg->m_extinction) ;
						}
					}
					CSelectColor* ecdlg=((CSelectColor*)d->data["Emmision Color"]);
					Make_ColourA(IMedia->Emission ,
						GetRValue(ecdlg->m_col)/255.0,GetGValue(ecdlg->m_col)/255.0,
						GetBValue(ecdlg->m_col)/255.0,ecdlg->filter/10000.0,
						ecdlg->trans/10000.0 );	

					CSelectColor* acdlg=((CSelectColor*)d->data["Absorbtion Color"]);
					Make_ColourA(IMedia->Absorption,
						GetRValue(acdlg->m_col)/255.0,GetGValue(acdlg->m_col)/255.0,
						GetBValue(acdlg->m_col)/255.0,acdlg->filter/10000.0,
						acdlg->trans/10000.0 );	

					CSelectColor* scdlg=((CSelectColor*)d->data["Scattering Color"]);
					Make_ColourA(IMedia->Scattering  ,
						GetRValue(acdlg->m_col)/255.0,GetGValue(acdlg->m_col)/255.0,
						GetBValue(acdlg->m_col)/255.0,acdlg->filter/10000.0,
						acdlg->trans/10000.0 );	

					
					HTREEITEM h3=m_tree->GetChildItem (h2);
					if(h3) 
					{
						do
						{

							PIGMENT *New=new PIGMENT();
							CString s;s=m_tree->GetItemText (h2);
							ParseDenisty(h3,New);
							Post_Pigment(New);
							New->Next = (TPATTERN*)IMedia->Density;
							IMedia->Density  = New;
							h3=this->m_tree->GetNextSiblingItem(h3);
						}
						while(h3);	

						
					}	
					if(d->Name!="")
					{
						Medias[d->Name]=(CObject*)IMedia;
					}
					IMedia->Next_Media = Next_Media;
						(*Interior)->IMedia= IMedia;
					h2=this->m_tree->GetNextSiblingItem(h2);

				}
				//	Parse_Media(h2,);
				while(h2);	
			}
		}
		h=this->m_tree->GetNextSiblingItem(h);
	}
	while(h);
	return 	RetTexture;
	//	return 0;
}

BLEND_MAP * CTextureTreeParser::Parse_Blend_List(HTREEITEM hitem, int count,int type,int bp)
{
	BLEND_MAP *New;
	BLEND_MAP_ENTRY *Temp_Ent;
	BLEND_MAP *Def_Map;
	if(count==0)
	{
		HTREEITEM itemloop = hitem;
		if(!itemloop) return NULL;	
		do{
			
			itemloop=m_tree->GetNextSiblingItem(itemloop);
			count++;
		}
		while(itemloop);
	}
	if(count<1) return NULL;
	Temp_Ent = Create_BMap_Entries(count);


	HTREEITEM h2=hitem;
	for(int i=0;i<count;i++)
//int i=0;
//	do
	{
		if(h2)
		{
			if(type==COLOUR_TYPE)
			{
				ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
				CSelectColor *dlg= ((CSelectColor*)d->data["CSelectColor"]);
				Make_ColourA(Temp_Ent[i].Vals.Colour,
				GetRValue(dlg->m_col)/255.0,GetGValue(dlg->m_col)/255.0,
				GetBValue(dlg->m_col)/255.0,dlg->filter/10000.0,
				dlg->trans/10000.0 );
				Temp_Ent[i].value=i;

			}
			else if(type==PIGMENT_TYPE)
			{
				Temp_Ent[i].Vals.Pigment=new PIGMENT();
				ParsePigment(h2,Temp_Ent[i].Vals.Pigment);
				
				ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
				if(d->menutype ==I_PIGMENT_MAP_VAL)
				{
					CMapEntry * e=((CMapEntry*)d->data["CMapEntry"] );
					Temp_Ent[i].value=e->m_pos ;
				}
				else
				{
					Temp_Ent[i].value=i;
				}
			}
			else if(type==NORMAL_TYPE)
			{
				Temp_Ent[i].Vals.Tnormal=new TNORMAL();
				ParseNormal(h2,Temp_Ent[i].Vals.Tnormal);
				
				ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
				if(d->menutype ==I_NORMAL_MAP_VAL)
				{
					CMapEntry * e=((CMapEntry*)d->data["CMapEntry"] );
					Temp_Ent[i].value=e->m_pos ;
				}
				else
				{
					Temp_Ent[i].value=i;
				}
			}
			else if(type==TEXTURE_TYPE)
			{
				ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
				if(d->menutype ==I_TEX_MAP_VAL)
				{
					Temp_Ent[i].Vals.Texture=ParseTexture(m_tree->GetChildItem ((h2)),NULL);//
					

					CMapEntry * e=((CMapEntry*)d->data["CMapEntry"] );
					Temp_Ent[i].value=e->m_pos ;
				}
				else
				{
					Temp_Ent[i].Vals.Texture=ParseTexture(h2,NULL);//m_tree->GetChildItem ((h2))
				//	ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);

					Temp_Ent[i].value=i;
				}
				
			}
			else if(type==DENSITY_TYPE)
			{
				Temp_Ent[i].Vals.Pigment=new PIGMENT();
				ParseDenisty(h2,Temp_Ent[i].Vals.Pigment);
				
				ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
				if(d->menutype ==I_DENISTY_MAP_VAL)
				{
					CMapEntry * e=((CMapEntry*)d->data["CMapEntry"] );
					Temp_Ent[i].value=e->m_pos ;
				}
				else
				{
					Temp_Ent[i].value=i;
				}
			}

			
			h2=m_tree->GetNextSiblingItem(h2);	
		}
		else break;
	//	i++;
	}//while(true);
	for(;i<count;i++)
	{
		if(type==COLOUR_TYPE)
		{
			if(bp==CHECKER_PATTERN)
			{
				Def_Map=&	Check_Default_Map;
			}
			else if(bp==HEXAGON_PATTERN)
			{
				Def_Map=&	Hex_Default_Map;
			}
			else if(bp==BRICK_PATTERN)
			{
				Def_Map=&	Brick_Default_Map;
			}
			Assign_Colour(Temp_Ent[i].Vals.Colour,Def_Map->Blend_Map_Entries[i].Vals.Colour);
		}
		else if(type==PIGMENT_TYPE)
		{
			Temp_Ent[i].Vals.Pigment=Default_Texture->Pigment;
		}
		else if(type==TEXTURE_TYPE)
		{
			Temp_Ent[i].Vals.Texture=Default_Texture->GetCopy();
			Destroy_Textures ( ParseTexture(h2,NULL));
		}
		Temp_Ent[i].value=i;
	}
	New = Create_Blend_Map ();
	New->Number_Of_Entries = count;
   New->Type=type;
  // New->Transparency_Flag=true; /*Temp fix.  Really set in Post_???*/
   New->Blend_Map_Entries = Temp_Ent;

  // Allow_Identifier_In_Call = old_allow_id;

   return (New);
}
void CTextureTreeParser::ParsePattern(CNoisePattern* dlg,TPATTERN *pat)
{
	switch(dlg->m_sel_pat)
	{
	case 0://agate
		pat->Type = AGATE_PATTERN;
		Check_Turb(&(pat->Warps));
		pat->Vals.Agate_Turb_Scale = 1.0;
		break;
	case 1: //bozo
		pat->Type = BOZO_PATTERN;
		break;
	case 2: //crackle
		pat->Type = CRACKLE_PATTERN;
		pat->Vals.Crackle.IsSolid = 0;
		pat->Vals.Crackle.Form[X] = -1;
		pat->Vals.Crackle.Form[Y] = 1;
		pat->Vals.Crackle.Form[Z] = 0;
		pat->Vals.Crackle.Metric[X] = 
			pat->Vals.Crackle.Metric[Y] = 
			pat->Vals.Crackle.Metric[Z] = 2;
		pat->Vals.Crackle.Offset = 0;
		pat->Vals.Crackle.Dim = 3;
		pat->Vals.Crackle.cv =(VECTOR*) POV_MALLOC( 125*sizeof(VECTOR), "crackle cache");
		pat->Vals.Crackle.lastseed = 0x8000000; 
		break;
				case 3: //gradient
					pat->Type = GRADIENT_PATTERN;
					Make_Vector(pat->Vals.Gradient,dlg->m_gx ,dlg->m_gy ,dlg->m_gz );
				//	VNormalizeEq(New->Vals.Gradient);
					break;
				case 4: //granite
					pat->Type = GRANITE_PATTERN;
					break;
					
				case 5: //leopard
					pat->Type = LEOPARD_PATTERN;
					break;
				case 6://mandle brot
					{
						pat->Type = MANDEL_PATTERN;
						pat->Vals.Fractal.Iterations = dlg->m_mandel_iter ;
						pat->Vals.Fractal.interior_type = DEFAULT_FRACTAL_INTERIOR_TYPE;
						pat->Vals.Fractal.exterior_type = DEFAULT_FRACTAL_EXTERIOR_TYPE;
						pat->Vals.Fractal.efactor = DEFAULT_FRACTAL_EXTERIOR_FACTOR;
						pat->Vals.Fractal.ifactor = DEFAULT_FRACTAL_INTERIOR_FACTOR;
						pat->Vals.Fractal.Exponent = 4;
					}
					break;
				case 7: //marble
					pat->Type = MARBLE_PATTERN;
					pat->Wave_Type = TRIANGLE_WAVE;
					break;
				case 8: //onion
					pat->Type = ONION_PATTERN;
					break;
				case 9: //radial
					pat->Type = RADIAL_PATTERN;
					break;
				case 10: //spiral 1
					pat->Type = SPIRAL1_PATTERN;
					pat->Vals.Arms = dlg->m_arms ;
					pat->Wave_Type = TRIANGLE_WAVE;
					break;
				case 11: //spiral 2
					pat->Type = SPIRAL2_PATTERN;
					pat->Vals.Arms = dlg->m_arms ;
					pat->Wave_Type = TRIANGLE_WAVE;
					break;
				case 12: //spotted
					pat->Type = SPOTTED_PATTERN;
					break;
				case 13: //wood
					pat->Type = WOOD_PATTERN;
       pat->Wave_Type = TRIANGLE_WAVE;
					break;
				case 14: //bumbs
					pat->Type = BUMPS_PATTERN;
					break;
				case 15: //ripples
					pat->Type = RIPPLES_PATTERN;
					break;
				case 16: //dents
					pat->Type = DENTS_PATTERN;
					break;
				case 17: //waves
					pat->Type = WAVES_PATTERN;
					break;
				case 18: //wrinkles
					pat->Type = WRINKLES_PATTERN;
					break;
				case 19: //quilted
					pat->Type = QUILTED_PATTERN;
       pat->Vals.Quilted.Control0 = 1.0;
       pat->Vals.Quilted.Control1 = 1.0;
       pat->Frequency = 0.0;
					break;
				case 20: //boxed
					pat->Type = BOXED_PATTERN;
					break;
				case 21: //cylindrical
					pat->Type = CYLINDRICAL_PATTERN;
					break;
				case 22: //planar
					pat->Type = PLANAR_PATTERN;
					break;
				case 23: //spherical
					pat->Type = SPHERICAL_PATTERN;
					break;

				default:
					AfxMessageBox ("you souldn't get here?");
	}
	
}



void CTextureTreeParser::ParseNormal(HTREEITEM hitem,TNORMAL* norm)
{
	{

		//making object transformation
		ItemDATA* d=(ItemDATA*)m_tree->GetItemData (hitem);
		
			CTransformation* dlg =(CTransformation*)d->data ["CTransformation"];
			VECTOR Vector;
			TRANSFORM Trans;
			Make_Vector(Vector,dlg->m_trans_x,dlg->m_trans_y,dlg->m_trans_z);
			Compute_Translation_Transform (&Trans, Vector);
			Transform_Tpattern ((TPATTERN*)norm, &Trans);

			Make_Vector(Vector,dlg->m_rot_x ,dlg->m_rot_y,dlg->m_rot_z);
			Compute_Rotation_Transform (&Trans, Vector);
			Transform_Tpattern ((TPATTERN*)norm, &Trans);

			Make_Vector(Vector,dlg->m_scale_x,dlg->m_scale_y,dlg->m_scale_z);
			Compute_Scaling_Transform (&Trans, Vector);
			Transform_Tpattern ((TPATTERN*)norm, &Trans);
		
			CNoiseModifier * nm=(CNoiseModifier*)d->data ["CNoiseModifier"];
			ParseNoiseModifier(nm,(TPATTERN*)norm);
			
		CWarpDlg * wd=(CWarpDlg*)d->data ["CWarpDlg"];
			ParseWarp(wd,&(norm->Warps));
	}
	HTREEITEM h=m_tree->GetChildItem (hitem);
	if(!h) return;
	HTREEITEM h2=h;
	do{
				
		ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
		if(d->menutype ==I_BP_WITH_NORM)
		{
			ParseBlockPattern(h2,(TPATTERN*)norm,NORMAL_TYPE);	
		}
		if(d->menutype ==I_NORMAL_PATTERN)
		{
			//////////.............
			norm->Amount=((CNoisePattern*)d->data["CNoisePattern"])->m_bump_depth;
			ParsePattern(((CNoisePattern*)d->data["CNoisePattern"]) ,norm);
			/// here we can parse the slope map
			CSlopeMap* slopemap=(CSlopeMap*)d->data["CSlopeMap"];
			int count =slopemap->slopmaps .GetSize ();
			if(count>0)
			{
				BLEND_MAP *New;
				BLEND_MAP_ENTRY *Temp_Ent;
//				BLEND_MAP *Def_Map;
				Temp_Ent = Create_BMap_Entries(count);
				//aloop 
				for(int i=0;i<count;i++)
				{
					SlopeMap* sm=(SlopeMap*)slopemap->slopmaps [i];
					Temp_Ent[i].value =sm->Number ;
					Make_UV_Vector(Temp_Ent[i].Vals.Point_Slope,sm->Height ,sm->Slope );
				}
				//Temp_Ent[i].Vals..Point_Slope

				New = Create_Blend_Map ();
				New->Number_Of_Entries = slopemap->slopmaps.GetSize ();
				New->Type=SLOPE_TYPE;
				// New->Transparency_Flag=true; /*Temp fix.  Really set in Post_???*/
				New->Blend_Map_Entries = Temp_Ent;

				Destroy_Blend_Map(norm->Blend_Map);
				norm->Blend_Map=New;
			}
		}
		else if(d->menutype ==I_NORMAL_MAP)
		{
		//	ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);

			ParsePattern(((CNoisePattern*)d->data["CNoisePattern"]),norm);

			Destroy_Blend_Map(norm->Blend_Map);

			HTREEITEM myitem=m_tree->GetChildItem (h2);
			norm->Blend_Map= Parse_Blend_List( myitem,0,NORMAL_TYPE,0);

		}
		else if(d->menutype ==I_BUMP_MAP)
		{
		norm->Type = BITMAP_PATTERN;
       norm->Frequency = 0.0;

			ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h2);
			CBitmapModifier * dlg=((CBitmapModifier *)d->data["CBitmapModifier"]);
			IMAGE *Image;
			Image= Create_Image ();
			Image->Image_Type = IMAGE_FILE;
			READ_SYS_IMAGE(Image, dlg->m_filename.GetBuffer (256) );
			Image->Use_Colour_Flag = true;
			Image->Once_Flag=dlg->m_once ;
			Image->Map_Type=dlg->m_maptype ;
		if(dlg->m_interpolation==1)
			Image->Interpolation_Type =2 ;
		else if(dlg->m_interpolation==2)
			Image->Interpolation_Type =4 ;
		

			   norm->Vals.Image=Image;
		}
	
		h2=m_tree->GetNextSiblingItem(h2);
		
	}
	while(h2);
}
TURB * CTextureTreeParser::Check_Turb (WARP **Warps_Ptr)
{
  WARP *Temp=*Warps_Ptr;
  
  if (Temp == NULL)
  {
    *Warps_Ptr = Temp = Create_Warp(CLASSIC_TURB_WARP);
  }
  else
  {
    while (Temp->Next_Warp != NULL)
    {
      Temp=Temp->Next_Warp;
    }
  
    if (Temp->Warp_Type != CLASSIC_TURB_WARP)
    {
      Temp->Next_Warp=Create_Warp(CLASSIC_TURB_WARP);
      Temp=Temp->Next_Warp;
    }
  }
  return((TURB *)Temp);
}

void CTextureTreeParser::ParseNoiseModifier(CNoiseModifier *dlg,TPATTERN *norm)
{
	//making noise effect
			//turbulence
			TURB *Local_Turb;
			Local_Turb=Check_Turb(&(norm->Warps));
			if(dlg->m_is_uniform )
			{
				Make_Vector(Local_Turb->Turbulence,dlg->m_uniform ,dlg->m_uniform ,dlg->m_uniform );
			}
			else
			{
				Make_Vector(Local_Turb->Turbulence,dlg->m_uniform_x ,dlg->m_uniform_y ,dlg->m_uniform_z );
			}
			//octaves
			Local_Turb=Check_Turb(&(norm->Warps));
       Local_Turb->Octaves = dlg->m_octaves ;
       if(Local_Turb->Octaves < 1)
          Local_Turb->Octaves = 1;
       if(Local_Turb->Octaves > 10)  /* Avoid DOMAIN errors */
          Local_Turb->Octaves = 10;
	   //omega
	   Local_Turb=Check_Turb(&(norm->Warps));
       Local_Turb->Omega = dlg->m_omega ;
	   //lambda
	   Local_Turb=Check_Turb(&(norm->Warps));
       Local_Turb->Lambda = dlg->m_lambda ;
	   //frequency
	   norm->Frequency =dlg->m_frequency;
	   //phase
	   norm->Phase =dlg->m_phase ;
	   switch(dlg->m_wavetype )
	   {
	   case 0:
		   norm->Wave_Type =RAMP_WAVE;
		   break;
	   case 1:
		   norm->Wave_Type =TRIANGLE_WAVE;
		   break;
	   case 2:
		   norm->Wave_Type =SINE_WAVE;
		   break;
	   case 3:
		   norm->Wave_Type =SCALLOP_WAVE;
		   break;
	   case 4:
		   norm->Wave_Type =CUBIC_WAVE;
		   break;
	   case 5:
		   norm->Wave_Type =POLY_WAVE;
		   norm->Exponent  = dlg->m_exp ;
		   break;

	   }
}
void CTextureTreeParser::Parse_Texture_Tranformation(CTransformation *dlg,TEXTURE *New)
{
VECTOR Vector;
			TRANSFORM Trans;
			Make_Vector(Vector,dlg->m_trans_x,dlg->m_trans_y,dlg->m_trans_z);
			Compute_Translation_Transform (&Trans, Vector);
			Transform_Textures (New, &Trans);

			Make_Vector(Vector,dlg->m_rot_x ,dlg->m_rot_y,dlg->m_rot_z);
			Compute_Rotation_Transform (&Trans, Vector);
			Transform_Textures (New, &Trans);

			Make_Vector(Vector,dlg->m_scale_x,dlg->m_scale_y,dlg->m_scale_z);
			Compute_Scaling_Transform (&Trans, Vector);
			Transform_Textures (New, &Trans);

}
void CTextureTreeParser::ParseWarp(CWarpDlg *dlg,WARP **Warp_Ptr)
{
	  VECTOR Local_Vector;
  WARP *New = NULL;
  TURB *Turb;
  REPEAT *Repeat;
  BLACK_HOLE *Black_Hole;

	if(dlg->m_is_rw )
	{
		New=Create_Warp(REPEAT_WARP);
      Repeat=(REPEAT *)New;

	  Make_Vector(Local_Vector,dlg->m_rrepeat_x  ,dlg->m_rrepeat_y ,dlg->m_rrepeat_z );

	//  Parse_Vector(Local_Vector);
      Repeat->Axis=-1;
      if (Local_Vector[X]!=0.0) 
      {
        Repeat->Axis=X;
      }
      else if (Local_Vector[Y]!=0.0)
      {
          Repeat->Axis=Y;
      }
      else if (Local_Vector[Z]!=0.0)
      {
          Repeat->Axis=Z;
      }
	  else
	  {
			Repeat->Axis=X;
	  }
      Repeat->Width=Local_Vector[Repeat->Axis];
       

	  Make_Vector(Repeat->Offset,dlg->m_offset_x ,dlg->m_offset_y ,dlg->m_offset_z );
	  Make_Vector(Repeat->Flip,dlg->m_flip_x ,dlg->m_flip_y ,dlg->m_flip_z );
	
          if (Repeat->Flip[X]!=0.0) Repeat->Flip[X]=-1.0; else Repeat->Flip[X]=1.0;
          if (Repeat->Flip[Y]!=0.0) Repeat->Flip[Y]=-1.0; else Repeat->Flip[Y]=1.0;
          if (Repeat->Flip[Z]!=0.0) Repeat->Flip[Z]=-1.0; else Repeat->Flip[Z]=1.0;
      New->Next_Warp=*Warp_Ptr;
	*Warp_Ptr=New; 
	}
	if(dlg->m_is_tw )
	{
		New=Create_Warp(EXTRA_TURB_WARP);
      Turb=(TURB *)New;
	  Make_Vector(Turb->Turbulence,dlg->m_tturbulence_x ,dlg->m_tturbulence_y,dlg->m_tturbulence_z);
	  Turb->Octaves=dlg->m_octaves ;
	  Turb->Omega =dlg->m_omega ;
	  Turb->Lambda =dlg->m_lambda ;
	   New->Next_Warp=*Warp_Ptr;
	*Warp_Ptr=New; 
	}
	if(dlg->m_is_bhw )
	{
		New = Create_Warp(BLACK_HOLE_WARP) ;
		Black_Hole = (BLACK_HOLE *) New ;
		Make_Vector(Black_Hole->Center,dlg->m_center_x,dlg->m_center_y,dlg->m_center_z);
		Black_Hole->Radius = dlg->m_radius ;
		Black_Hole->Radius_Squared = Black_Hole->Radius * Black_Hole->Radius ;
		Black_Hole->Inverse_Radius = 1.0 / Black_Hole->Radius;
		Black_Hole->Strength = 1.0 ;
		Black_Hole->Power = 2.0 ;
		Black_Hole->Inverted = false ;
		Black_Hole->Type = 0 ;

		Black_Hole->Strength =dlg->m_strength ;
		 Black_Hole->Power =dlg->m_fallof ;
		 Black_Hole->Inverted = dlg->m_is_inverse ;

		 Make_Vector(Black_Hole->Repeat_Vector,dlg->m_brepeat_x,dlg->m_brepeat_y,dlg->m_brepeat_z);
		 Black_Hole->Repeat = true ;
		 Check_BH_Parameters (Black_Hole) ;

		  if(dlg->m_bturbulence_x!=0 || dlg->m_bturbulence_y!=0 || dlg->m_bturbulence_z!=0 )
		  {
		  Make_Vector(Black_Hole->Uncertainty_Vector,dlg->m_bturbulence_x,dlg->m_bturbulence_y,dlg->m_bturbulence_z);
		  Black_Hole->Uncertain = true ;
          Check_BH_Parameters (Black_Hole) ;

		  
		  } 
		  New->Next_Warp=*Warp_Ptr;
		*Warp_Ptr=New; 
	}

}

void CTextureTreeParser::Check_BH_Parameters (BLACK_HOLE *bh)
{
  if (bh->Repeat == false) return ;

  if (bh->Repeat_Vector [X] > 0.0)
  {
    if (bh->Center [X] < bh->Radius)
      bh->Center [X] = bh->Radius ;
    if (bh->Repeat_Vector [X] < bh->Center [X] + bh->Radius + bh->Uncertainty_Vector [X])
    {
      bh->Repeat_Vector [X] = bh->Center [X] + bh->Radius + bh->Uncertainty_Vector [X] ;
 //     Warning (0, "Black Hole repeat vector X too small ; increased to %g", bh->Repeat_Vector [X]) ;
    } 
    if (bh->Repeat_Vector [X] < Small_Tolerance)
    {
 //     Warning (0,"Black Hole repeat vector X is less than %f ; ignored", (float) Small_Tolerance) ;
      bh->Repeat_Vector [X] = 0.0 ;
    }
  }

  if (bh->Repeat_Vector [Y] > 0.0)
  {
    if (bh->Center [Y] < bh->Radius)
      bh->Center [Y] = bh->Radius ;
    if (bh->Repeat_Vector [Y] < bh->Center [Y] + bh->Radius + bh->Uncertainty_Vector [Y])
    {
      bh->Repeat_Vector [Y] = bh->Center [Y] + bh->Radius + bh->Uncertainty_Vector [Y] ;
 //     Warning (0, "Black Hole repeat vector Y too small ; increased to %g", bh->Repeat_Vector [Y]) ;
    } 
    if (bh->Repeat_Vector [Y] < Small_Tolerance)
    {
 //     Warning (0, "Black Hole repeat vector Y is less than %f ; ignored", (float) Small_Tolerance) ;
      bh->Repeat_Vector [Y] = 0.0 ;
    } 
  }

  if (bh->Repeat_Vector [Z] > 0.0)
  {
    if (bh->Center [Z] < bh->Radius)
      bh->Center [Z] = bh->Radius ;
    if (bh->Repeat_Vector [Z] < bh->Center [Z] + bh->Radius + bh->Uncertainty_Vector [Z])
    {
      bh->Repeat_Vector [Z] = bh->Center [Z] + bh->Radius + bh->Uncertainty_Vector [Z] ;
 //     Warning (0, "Black Hole repeat vector Z too small ; increased to %g", bh->Repeat_Vector [Z]) ;
    } 
    if (bh->Repeat_Vector [Z] < Small_Tolerance)
    {
 //     Warning (0, "Black Hole repeat vector Z is less than %f ; ignored", (float) Small_Tolerance) ;
      bh->Repeat_Vector [Z] = 0.0 ;
    }
  }
}
int CTextureTreeParser::FreeMaterials(void)
{
//removing textures	
	POSITION pos=Textures.GetStartPosition ();
	while (pos!=NULL)
	{
		CObject *tex;CString key;
		Textures.GetNextAssoc (pos,key,tex);
		TEXTURE* t=(TEXTURE*)tex;
		Destroy_Textures ( t);
	}
	Textures.RemoveAll ();

	//removing interiors
	pos=Interiors .GetStartPosition ();
	while (pos!=NULL)
	{
		CObject *inter;CString key;
		Interiors.GetNextAssoc (pos,key,inter);
		INTERIOR* t=(INTERIOR*)inter;
		Destroy_Interior( t);
	}
	Interiors.RemoveAll ();

	///removing skyspheres
	pos=SkySpheres.GetStartPosition ();
	while (pos!=NULL)
	{
		CObject *ss;CString key;
		SkySpheres.GetNextAssoc (pos,key,ss);
		SKYSPHERE* t=(SKYSPHERE*)ss;
		delete  t;
	}
	SkySpheres.RemoveAll ();

//removing rainbows
	pos=Rainbows.GetStartPosition ();
	while (pos!=NULL)
	{
		CObject *ss;CString key;
		Rainbows.GetNextAssoc (pos,key,ss);
		RAINBOW* t=(RAINBOW*)ss;
		delete  t;
	}
	Rainbows.RemoveAll ();
	return 0;
}

TEXTURE* CTextureTreeParser::GetTexture(CString TexName)
{
//	CRef * r=(CRef*)Ref[TexName];
//	r->Refrences ++;
	return Copy_Texture_Pointer((TEXTURE*)Textures[TexName]);
	//return NULL;
}

INTERIOR* CTextureTreeParser::GetInterior(CString TexName)
{
	INTERIOR* i=(INTERIOR*)this->Interiors [TexName];
	if(i)
	{
		return Copy_Interior_Pointer (i);
	}
	else
		return NULL;
}

RAINBOW *CTextureTreeParser::ParseRainbow(HTREEITEM hitem)
{
	//	ItemDATA* d=(ItemDATA*)m_tree->GetItemData (hitem);
	//	d->Name ;
	RAINBOW *Rainbow=NULL;
	RAINBOW  *Local_Rainbow;
	//	Rainbow = ;

	HTREEITEM h=m_tree->GetChildItem (hitem);
	if(!h) return Rainbow;
	do
	{
		ItemDATA* d=(ItemDATA*)m_tree->GetItemData (h);
		CRainbowOptions* ro=(CRainbowOptions*)d->data ["CRainbowOptions"];
		Local_Rainbow = new RAINBOW();
		Local_Rainbow->Angle =ro->m_angle ;
		Make_Vector(Local_Rainbow->Antisolar_Vector,ro->m_antisolar_x,ro->m_antisolar_y,ro->m_antisolar_z);
		Local_Rainbow->Arc_Angle =ro->m_arc_angle ;
		Local_Rainbow->Arc_Angle *= M_PI_360;

		Local_Rainbow->Distance =ro->m_distance ;
		Local_Rainbow->Falloff_Angle =ro->m_falloff_angle ;
		Local_Rainbow->Falloff_Angle *= M_PI_360;

		Local_Rainbow->Falloff_Width =ro->m_falloff_width ;
		Local_Rainbow->Jitter =ro->m_jitter;
		Make_Vector(Local_Rainbow->Right_Vector ,ro->m_right_x ,ro->m_right_y,ro->m_right_z);
		Make_Vector(Local_Rainbow->Up_Vector ,ro->m_up_x ,ro->m_up_y,ro->m_up_z);
		Local_Rainbow->Width =ro->m_width ;
		Local_Rainbow->Pigment = new PIGMENT();
		////////////////////////////////////////////////////////////////////
		//SETTING THE PIGMENT MAP
		CGradient & g=((CSelectColor*)d->data["CSelectColor"])->m_wndGradientCtrl .GetGradient ();
		///////////
		//setting the color map
		int m=g.GetPegCount();
		BLEND_MAP *New;
		BLEND_MAP_ENTRY *Temp_Ent;
		//	BLEND_MAP *Def_Map;
		Temp_Ent = Create_BMap_Entries(m+2);

		//	m_StartPeg, m_EndPeg, 
		Make_ColourA(Temp_Ent[0].Vals.Colour,
			GetRValue(g.m_StartPeg.colour)/255.0,GetGValue(g.m_StartPeg.colour)/255.0,
			GetBValue(g.m_StartPeg.colour)/255.0,g.m_StartPeg.filter /10000.0,
			g.m_StartPeg.trans/10000.0 );
		Temp_Ent[0].value=0.0;
		for(int i=0;i<m;i++)
		{
			CPeg  p=g.GetPeg (i);
			Make_ColourA(Temp_Ent[i+1].Vals.Colour,
				GetRValue(p.colour)/255.0,GetGValue(p.colour)/255.0,
				GetBValue(p.colour)/255.0,p.filter /10000.0,
				p.trans/10000.0 );
			Temp_Ent[i+1].value=p.position;
		}
		Make_ColourA(Temp_Ent[m+1].Vals.Colour,
			GetRValue(g.m_EndPeg.colour)/255.0,GetGValue(g.m_EndPeg.colour)/255.0,
			GetBValue(g.m_EndPeg.colour)/255.0,g.m_EndPeg.filter /10000.0,
			g.m_EndPeg.trans/10000.0 );
		Temp_Ent[m+1].value=1.0;


		New = Create_Blend_Map ();
		New->Number_Of_Entries = m+2;
		New->Type=COLOUR_TYPE;
		//	 New->Transparency_Flag=true; //Temp fix.  Really set in Post_???
		New->Blend_Map_Entries = Temp_Ent;
		Destroy_Blend_Map(Local_Rainbow->Pigment->Blend_Map);
		Local_Rainbow->Pigment->Blend_Map=New;
		//////////////////////////////////////////////////////////////////////////////
		Local_Rainbow->Pigment->Type = GRADIENT_PATTERN;
		Make_Vector (Local_Rainbow->Pigment->Vals.Gradient,1.0,0.0,0.0);

		///SOME MATH I DIDN'T UNDERSTAND YET
		//////////////////////////////////////////////////////////////////
		DBL dot;

		/* Get falloff region width.*/

		Local_Rainbow->Falloff_Width = Local_Rainbow->Arc_Angle - Local_Rainbow->Falloff_Angle;

		/* Check for illegal vectors. */

		VDot(dot, Local_Rainbow->Antisolar_Vector, Local_Rainbow->Antisolar_Vector);

		if (fabs(dot) < EPSILON)
		{
			Error("Local_Rainbow's direction vector is zero.");
		}

		VDot(dot, Local_Rainbow->Up_Vector, Local_Rainbow->Up_Vector);

		if (fabs(dot) < EPSILON)
		{
			Error("Local_Rainbow's up vector is zero.");
		}

		VNormalizeEq(Local_Rainbow->Antisolar_Vector);
		VNormalizeEq(Local_Rainbow->Up_Vector);

		VDot(dot, Local_Rainbow->Up_Vector, Local_Rainbow->Antisolar_Vector);

		if (fabs(1.0 - fabs(dot)) < EPSILON)
		{
			Error("Local_Rainbow's up and direction vector are co-linear.");
		}

		/* Make sure that up and antisolar vector are perpendicular. */

		VCross(Local_Rainbow->Right_Vector, Local_Rainbow->Up_Vector, Local_Rainbow->Antisolar_Vector);

		VCross(Local_Rainbow->Up_Vector, Local_Rainbow->Antisolar_Vector, Local_Rainbow->Right_Vector);

		VNormalizeEq(Local_Rainbow->Up_Vector);
		VNormalizeEq(Local_Rainbow->Right_Vector);

		/* Adjust Local_Rainbow angle and width. */

		Local_Rainbow->Angle -= 0.5 * Local_Rainbow->Width;

		Local_Rainbow->Angle *= M_PI_180;
		Local_Rainbow->Width *= M_PI_180;
		//////////////////////////////////////////////////////////////////// 
		Local_Rainbow->Next = Frame.Rainbow;
		Rainbow = Local_Rainbow;


		h=this->m_tree->GetNextSiblingItem(h);
	}
	while(h);
	return Rainbow;
}

SKYSPHERE* CTextureTreeParser::ParseSkySphere(HTREEITEM hitem)
{
	ItemDATA* d=(ItemDATA*)m_tree->GetItemData (hitem);
	//	d->Name ;
	SKYSPHERE *Skysphere;
	Skysphere = new SKYSPHERE;
	Skysphere->Count=0;

	HTREEITEM h=m_tree->GetChildItem (hitem);
	if(!h) return Skysphere;
	do
	{
		Skysphere->Count++;
		Skysphere->Pigments =(PIGMENT **)POV_REALLOC(Skysphere->Pigments, Skysphere->Count*sizeof(SKYSPHERE *), "sky-sphere pigment");
		Skysphere->Pigments[Skysphere->Count-1] = new PIGMENT();
		ParsePigment (h, Skysphere->Pigments[Skysphere->Count-1]);
		Post_Pigment(Skysphere->Pigments[Skysphere->Count-1]);

		h=this->m_tree->GetNextSiblingItem(h);
	}
	while(h);
	//transformation
	//ItemDATA* d=(ItemDATA*)m_tree->GetItemData (hitem);

	{



		CTransformation* dlg =(CTransformation*)d->data ["CTransformation"];
		VECTOR Vector;
		TRANSFORM Trans;
		Make_Vector(Vector,dlg->m_trans_x,dlg->m_trans_y,dlg->m_trans_z);
		Compute_Translation_Transform (&Trans, Vector);
		Skysphere->Transform (&Trans);

		Make_Vector(Vector,dlg->m_rot_x ,dlg->m_rot_y,dlg->m_rot_z);
		Compute_Rotation_Transform (&Trans, Vector);
		Skysphere->Transform ( &Trans);

		Make_Vector(Vector,dlg->m_scale_x,dlg->m_scale_y,dlg->m_scale_z);
		Compute_Scaling_Transform (&Trans, Vector);
		Skysphere->Transform ( &Trans);

	}
	return Skysphere;
}
