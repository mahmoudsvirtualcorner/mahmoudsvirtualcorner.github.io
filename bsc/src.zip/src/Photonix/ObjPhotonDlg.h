#if !defined(AFX_OBJPHOTONDLG_H__F322E0B2_78FF_473D_941A_39FACA3E9AF4__INCLUDED_)
#define AFX_OBJPHOTONDLG_H__F322E0B2_78FF_473D_941A_39FACA3E9AF4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ObjPhotonDlg.h : header file
//
#include "AccessDialog.h"
#include "enggenclasses.h"

/////////////////////////////////////////////////////////////////////////////
// CObjPhotonDlg dialog

class CObjPhotonDlg : public CAccessDialog//CDialog
{
// Construction
public:
	CObjPhotonDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CObjPhotonDlg)
	enum { IDD = IDD_OBJPHOTON };
	BOOL	m_RecieveCaustics;
	BOOL	m_GenerateCaustics;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CObjPhotonDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CObjPhotonDlg)
	afx_msg void OnGenerateCaustics();
	afx_msg void OnRecieveCaustics();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	BOOL m_reflection;
	BOOL m_refraction;
	afx_msg void OnReflection();
	afx_msg void OnRefraction();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_OBJPHOTONDLG_H__F322E0B2_78FF_473D_941A_39FACA3E9AF4__INCLUDED_)
