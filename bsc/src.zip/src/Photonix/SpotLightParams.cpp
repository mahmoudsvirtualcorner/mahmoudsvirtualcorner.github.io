// SpotLightParams.cpp : implementation file
//

#include "stdafx.h"
#include "photonix.h"
#include "SpotLightParams.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSpotLightParams dialog


CSpotLightParams::CSpotLightParams(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CSpotLightParams::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSpotLightParams)
	m_falloff = 0.0f;
	m_raduis = 0.0f;
	m_tightness = 0.0f;
	//}}AFX_DATA_INIT
}


void CSpotLightParams::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSpotLightParams)
	DDX_Text(pDX, IDC_FALLOFF, m_falloff);
	DDX_Text(pDX, IDC_RADIUS, m_raduis);
	DDX_Text(pDX, IDC_TIGHTNESS, m_tightness);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSpotLightParams, CDialog)
	//{{AFX_MSG_MAP(CSpotLightParams)
	ON_EN_KILLFOCUS(IDC_FALLOFF, OnKillfocusFalloff)
	ON_EN_KILLFOCUS(IDC_RADIUS, OnKillfocusRadius)
	ON_EN_KILLFOCUS(IDC_TIGHTNESS, OnKillfocusTightness)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpotLightParams message handlers

void CSpotLightParams::OnKillfocusFalloff() 
{
	UpdateData ();
	((SpotLightObj*)m_Object )->FalloffAngle =m_falloff ;
}

void CSpotLightParams::OnKillfocusRadius() 
{
	UpdateData ();
	((SpotLightObj*)m_Object )->RadiusAngle  =m_raduis ;

}

void CSpotLightParams::OnKillfocusTightness() 
{
		UpdateData ();
	((SpotLightObj*)m_Object )->Tightness   =m_tightness ;

}
