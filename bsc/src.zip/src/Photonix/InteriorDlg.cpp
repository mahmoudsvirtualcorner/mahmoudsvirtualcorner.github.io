// InteriorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "InteriorDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInteriorDlg dialog
IMPLEMENT_SERIAL(CInteriorDlg,CAccessDialog,1)

CInteriorDlg::CInteriorDlg(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CInteriorDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInteriorDlg)
	m_cpower = 1.0f;
	m_fpower = 2.0f;
	m_is_fade = FALSE;
	m_is_caustics = FALSE;
	m_ior = 1.0f;
	m_distance = 10.0f;
	m_disersionsamples = 2;
	m_dispersion = 7.0f;
	//}}AFX_DATA_INIT
}


void CInteriorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInteriorDlg)
	DDX_Text(pDX, IDC_CPOWER, m_cpower);
	DDV_MinMaxFloat(pDX, m_cpower, 0.f, 100.f);
	DDX_Text(pDX, IDC_FPOWER, m_fpower);
	DDV_MinMaxFloat(pDX, m_fpower, 0.f, 100.f);
	DDX_Check(pDX, IDC_FADE, m_is_fade);
	DDX_Check(pDX, IDC_IS_CAUSTICS, m_is_caustics);
	DDX_Text(pDX, IDC_IOR, m_ior);
	DDV_MinMaxFloat(pDX, m_ior, 0.f, 5.f);
	DDX_Text(pDX, IDC_DISTANCE, m_distance);
	DDV_MinMaxFloat(pDX, m_distance, 0.f, 2.e+006f);
	DDX_Text(pDX, IDC_DISPERSION_SAMPLES, m_disersionsamples);
	DDV_MinMaxInt(pDX, m_disersionsamples, 2, 10000);
	DDX_Text(pDX, IDC_DISPERSION, m_dispersion);
	DDV_MinMaxFloat(pDX, m_dispersion, 1.e-007f, 1.e+009f);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInteriorDlg, CDialog)
	//{{AFX_MSG_MAP(CInteriorDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInteriorDlg message handlers
void CInteriorDlg::Serialize(CArchive &ar)
{
	if(ar.IsStoring ())
	{
		ar<<m_cpower<<m_fpower<<m_is_fade<<m_is_caustics<<m_ior<<m_distance<<m_disersionsamples <<m_dispersion;
	}

	else
	{
	ar>>m_cpower>>m_fpower>>m_is_fade>>m_is_caustics>>m_ior>>m_distance>>m_disersionsamples >>m_dispersion;
	}

}