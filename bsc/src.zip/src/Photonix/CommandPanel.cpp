#include "StdAfx.h"
#include "photonix.h"
#include "Commandpanel.h"

CCommandPanel::CCommandPanel(void)
{
	m_rollup.m_hWnd=0;
}

CCommandPanel::~CCommandPanel(void)
{
}
#define ID_EXPANDALL		2019
#define ID_COLLAPSEALL		2020
BEGIN_MESSAGE_MAP(CCommandPanel, CGuiControlBar)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_COMMAND(ID_EXPANDALL,OnExpandAll)
	ON_COMMAND(ID_COLLAPSEALL,OnCollapseAll)
END_MESSAGE_MAP()

void CCommandPanel::OnExpandAll()
{
	m_rollup.ExpandAllPages ();
}
void CCommandPanel::OnCollapseAll()
{
	m_rollup.ExpandAllPages(false);
}
int CCommandPanel::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CGuiControlBar::OnCreate(lpCreateStruct) == -1)
		return -1;
	SetSupporMultiView(TRUE);
	if (!m_Tab.Create(WS_VISIBLE|WS_CHILD,CRect(0,0,300,300),this,0x9999))
		return -1;
	if (!m_OptionsRollUp.Create(WS_CHILD|WS_VISIBLE,CRect(0,0,0,0),&m_Tab,124))
		return -1;
	
	
	m_OptionsRollUp.AddComponen(&m_MiniOptionsTool);
	m_MiniOptionsTool.AlingButtons(CGuiMiniTool::ALIGN_LEFT);
	m_MiniOptionsTool.SetImageList(IDB_COMMANDBARICONS, 16,22, RGB (255, 255, 255));
	m_MiniOptionsTool.AddButton(1,ID_EXPANDALL,NULL,_T("Expand All"),"Expand All Option Dialogs");
	m_MiniOptionsTool.AddButton(2,ID_COLLAPSEALL,NULL,_T("Collapse All"),"Collapse All Option Dialogs");
	m_MiniOptionsTool.AutoSize(FALSE);
	m_MiniOptionsTool.SetColor(GuiDrawLayer::GetRGBColorXP());
	
	BOOL bSuccess;
	bSuccess = m_rollup.Create(WS_CHILD | WS_DLGFRAME | WS_VISIBLE,CRect(0,0,0,0), &m_OptionsRollUp, 1100);// CRect(220,0,220+300,300)
	ASSERT(bSuccess);
	m_OptionsRollUp.AddComponen (&m_rollup);
	m_Tab.SetImageList(IDB_COMMANDBARICONS, 16,1, RGB (255, 255, 255));
	m_Tab.Addtab(&m_OptionsRollUp,"Options",2);
this->m_sizeVert.cx=230;
	return 0;
}


BOOL CCommandPanel::DestroyWindow() 
{
//	m_rollup.RemoveAllPages ();
	return CGuiControlBar::DestroyWindow();
}
void CCommandPanel::OnMessage(VOID *pSender,CString Message)
{
	if(Message=="Selection")
	{
		// select object in the tree
		//	AfxMessageBox ("obj sel");
		CObArray *pPicked=&((SceneSelector*)pSender)->mPicked;
		/*		int count=pPicked->GetSize ();
		for (int i=0;i<count;i++)
		{
		//	pPicked[i]
		}
		*/
		m_rollup.RemoveAllPages ();
		if(pPicked->GetSize ()==1)
		{
			IRenderable* IRend=(IRenderable*)(pPicked->GetAt (0));

			CMDIFrameWnd *pFrame = 	(CMDIFrameWnd*)AfxGetApp()->m_pMainWnd;
			//CMDIChildWnd *pChild = 	(CMDIChildWnd *) pFrame->GetActiveFrame();

			CPhotonixDoc * pDoc=(CPhotonixDoc*)(pFrame->GetActiveDocument ());//this->GetDocument();

			SceneObjectData* pdata=(SceneObjectData*)pDoc->m_CurScene -> m_MapSceneObjects[IRend->Name];
			if(pdata)
			{
				/*	{//working to select object oin the scene
				CObArray *pPicked=&(pDoc->m_Selector->mPicked);
				int count=pPicked->GetSize ();
				for (int i=0;i<count;i++)
				{
				IRenderable* IRend=(IRenderable*)pPicked->GetAt (i);
				IRend->DoDeSelect ();
				}
				pPicked->RemoveAll ();
				pdata->pObject->pRenderable->DoSelect ();
				pPicked->Add (pdata->pObject->pRenderable );
				pDoc->m_Selector->ReConstructTool();
				}*/
				{//working to show it's options in the dialog
					//	m_rollup.RemoveAllPages ();
					CMapStringToOb& hashtable =pdata->pObject->OptionDialogs;
					POSITION pos=hashtable.GetStartPosition ();
					while (pos!=NULL)
					{
						CObject *dlg;CString key;
						hashtable.GetNextAssoc (pos,key,dlg);
						CDialog *dialog=(CDialog*)dlg;
						dialog->SetParent (&m_rollup);
						m_rollup.InsertPage (key,dialog,false);
					}
					m_rollup.ExpandAllPages ();
				}

				//	pDoc->UpdateAllViews(0,0,0);
			}

			/*	HTREEITEM h=m_objtree.GetRootItem ();
			if(h)
			{
			SceneObjectData* pdata=(SceneObjectData*)m_objtree.GetItemData (h);
			if(pdata->pObject->pRenderable==IRend)
			{
			m_objtree.SelectItem (h);
			return;
			}
			}
			// Look at all of the root-level items
			HTREEITEM hCurrent =m_objtree.GetNextItem(h, TVGN_NEXT);
			while (hCurrent != NULL)
			{
			SceneObjectData* pdata=(SceneObjectData*)m_objtree.GetItemData (hCurrent);
			if(pdata->pObject->pRenderable==IRend)
			{
			m_objtree.SelectItem (hCurrent);
			break;
			}

			// Try to get the next item
			hCurrent = m_objtree.GetNextItem(hCurrent, TVGN_NEXT);
			}
			*/
		}
	}
	else if(Message=="DeSelection")
	{
		m_rollup.RemoveAllPages ();
	}
}