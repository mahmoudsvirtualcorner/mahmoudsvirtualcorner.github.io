#include "stdafx.h"
#include "myApplication.h"
#include "ColourValue.h"
#include "ViewPort.h"
#include "RenderWindow.h"
#include "Light.h"
#include "Math\Matrix4.h"
#include "Material.h"
#include "irenderable.h"
#include "RenderOperation.h"
#include "ConfigOption.h"

#include "rendersystem.h"
#include "GSMtexture.h"
#include "renderwindow.h"

#include "application.h"
#include "scene.h"
#include "gsmCamera.h"
#include "MeshBox.h"
#include "SphereMesh.h"
//#include "SuperEllipsoid.h"

#include "GSMtexture.h"
//#include "d3d8texture.h"
//#include "gltexture.h"
#include "guiwnd.h"
#include "guiwindow.h"
#include "guibutton.h"
#include "GLRenderSystem.h"
#include "enggenclasses.h"
#include "sceneselector.h"
#include "sceneobj.h"

CMyApplication::CMyApplication(void)
:CWindowedApplication()
{
	Modal=0;
}

CMyApplication::~CMyApplication(void)
{
}
void CMyApplication::SelectRenderEngine()
{
	//opengl
	rs=new GLRenderSystem();//AfxGetApp()->m_hInstance);
}
void CMyApplication::CreateWindows()
{
	CWindowedApplication::CreateWindows();
	
	
	// window=rs->createRenderWindow("hello",500,500,24,false,0,0,true,Parentwnd);
//	window=rs->createRenderWindow (NeededWnd,24);
//	rs->mRenderIn.Add (window);

//	window->Register (this);
	rs->Register(this);
}
#include "cameramesh.h"

void CMyApplication::CreateScenes()
{
	CWindowedApplication::CreateScenes();
		// ordinary sample with texturing
	/// creating some scenes and cameras for it
	SceneObj *s1=new SceneObj();//"Scene1"
	mScenes["Scene1"]=(CObject*)s1;

	SceneSelector *Scene1Sel=new SceneSelector();
	Scene1Sel->SelScene=s1;
	CString ss1;ss1="SceneSel1";
	mSelectors[ss1]=Scene1Sel;
	//creating some viewports
//	int width, height,colourDepth,left,top;
//	window->getMetrics(width,height,colourDepth,left,top);
//	CViewPort *vp1=new CViewPort(window,left,top,width,height);//"my view port1"
//	vp1->Clear =true;
//	vp1->BackColour=ColourValue ::Blue ;
//	mViewPorts["view port1"]=vp1;

	CameraObj *cam=new CameraObj(false,"Prespective");
Camera *camPre=cam->GetCamera();
	camPre->m_Location=Vector3(2,2,2);
	camPre->m_Direction =Vector3(0,0,0)-Vector3(2,2,2);
	//(Real)(width/height)
	camPre->SetFrustum (45.0,1,1,1000.0);
//	cam1->mSceneDetail=SDL_WIREFRAME;
	mCameras["Prespective"]=cam;


	cam=new CameraObj(false,"Front");
Camera *camFront=cam->GetCamera();
	camFront->m_Location=Vector3(0,2,0);
	camFront->m_Direction =Vector3(0,0,0)-Vector3(0,2,0);
	camFront->SetFrustum (130.0,1,.5,1000.0);
	camFront->mProjType=PT_ORTHOGRAPHIC;
	mCameras["Front"]=cam;

	cam=new CameraObj(false,"Left");
	Camera *camleft=cam->GetCamera();

	camleft->m_Location=Vector3(2,0,0);
	camleft->m_Direction =Vector3(0,0,0)-Vector3(2,0,0);
	camleft->SetFrustum (130.0,1,.5,1000.0);
	camleft->mProjType=PT_ORTHOGRAPHIC;
	mCameras["Left"]=cam;

	cam=new CameraObj(false,"Right");
	Camera *camRight=cam->GetCamera();
	camRight->m_Location=Vector3(-2,0,0);
	camRight->m_Direction =Vector3(0,0,0)-Vector3(-2,0,0);
	camRight->SetFrustum (130.0,1,.5,1000.0);
	camRight->mProjType=PT_ORTHOGRAPHIC;
	mCameras["Right"]=cam;

	cam=new CameraObj(false,"Top");
	Camera *camTop=cam->GetCamera();

	camTop->m_Location=Vector3(0,0,20);
	camTop->m_Direction =Vector3(0,0,0)-Vector3(0,0,20);
	camTop ->m_Up =-Vector3::UNIT_X ;
	camTop->SetFrustum (130.0,1,.5,1000.0);
	camTop->mProjType=PT_ORTHOGRAPHIC;
	mCameras["Top"]=cam;



	//rs->_setCullingMode(CULL_CLOCKWISE);

//creating the object selection
//	Scene1Sel=new SceneSelector();
//	Scene1Sel->SelScene=s1;
//Scene1Sel->SelCamera =cam1;
//	mSelectors["Scene1Sel"]=Scene1Sel;
//Router->Register (Scene1Sel);
	
	/*
this->Input->m_Mouse ->Register (Scene1Sel);
*/

//	SphereMesh *sphere=new SphereMesh();
//	sphere->Scale *=(Real).8;
//	sphere->ComputeBoundingBox();
//	sphere->SetRenderType(SDL_WIREFRAME);
//	MeshBox *box=new MeshBox();
//	box->Translation =Vector3((Real)-0.5,(Real)0,(Real)-1);
//	box->ComputeBoundingBox();
//	SuperEllipsoid * superellipse=new SuperEllipsoid();
//	superellipse->Translation =Vector3((Real)-0.5,(Real)0,(Real)-3);
//	superellipse->ComputeBoundingBox();
//	SphereObj *sphere=new SphereObj();
//	sphere->ComputeBoundingBox();
//	s1->AddRenderable (sphere);

//	s1->AddRenderable (sphere);
//	s1->AddRenderable (box);
//	s1->AddRenderable (superellipse);

	Light *light=new Light("DefaultLight");
	light->mPosition =Vector3(10,10,10);
	light->mRange=100;
	light->mDiffuse=ColourValue (0.5f, 0.5f, 0.5f);
	s1->Lights["light1"]=light;
	rs->_addLight(light);

	/// create array
/*	for (int i=0;i<10;i++)
	{
		SphereMesh *spherea=new SphereMesh();
		spherea->Scale *=(Real).8;
		spherea->Translation =Vector3((float)i/10,0,0);
		
	//	spherea->SetRenderType (SDL_WIREFRAME);
		spherea->ComputeBoundingBox();
		s1->AddRenderable (spherea);

	}
*/
//	((CViewPort*)mViewPorts["view port1"])->Camera=(Camera*)mCameras["Camera1"];
//	((CViewPort*)mViewPorts["view port1"])->scene=s1;
//	window->mViewPorts.Add((CViewPort*)mViewPorts["view port1"]);


	/////////////////////////////////////////////////////////////
	//user interface
/*		Scene *s3=new Scene();//"Scene1"
	mScenes["Scene3"]=(CObject*)s3;

//	int width, height,colourDepth,left,top;
	//	window->getMetrics(width,height,colourDepth,left,top);
	CViewPort *vp3=new CViewPort(window,left,top,width,height);//"my view port1"
	vp3->Clear =false;
	vp3->BackColour=ColourValue ::Red;
	mViewPorts["view port3"]=vp3;
	// initializing the windowing system
	s3->GuiManager = new GUIManager();
	s3->GuiManager ->MouseTextureName ="cur.png";//"cursor.bmp";
	s3->GuiManager ->BuildMouse ();
	s3->GuiManager ->MouseVisible=false;
	//Input ->m_Mouse ->Register (s3->GuiManager);
	Router->Register (s3->GuiManager);
	//making the first window
	GUIWindow *myguiwindow1=new GUIWindow();
	myguiwindow1->SetWindowPos (-.5,.5,.5,.5);
	myguiwindow1->Background ="Bitmap2.bmp";
	myguiwindow1->Build ();
	GUIButton *bt1=new GUIButton("Exit"); //the first button in the window
	bt1->SetWindowPos (0,0,(Real)0.5,(Real)0.5);
	bt1->SetImages ("back02.png","back01.png","back03.png","back02.png");
	
	bt1->Register (this);
	myguiwindow1->AttachWnd(bt1);
	bt1->Build ();
	////////////////////////
	// checking multi level relative positions
GUIButton *btn=new GUIButton("Exit1"); //the first button in the window
	btn->SetWindowPos ((Real).05,(Real).05,(Real)0.2,(Real)0.2);
	btn->SetImages ("back02.png","back01.png","back03.png","back02.png");
	
	btn->Register (this);
	bt1->AttachWnd(btn);
	btn->Build ();

	GUIButton *btn1=new GUIButton("Exit2"); //the first button in the window
	btn1->SetWindowPos ((Real).05,(Real).05,(Real)0.1,(Real)0.1);
	btn1->SetImages ("back02.png","back01.png","back03.png","back02.png");
	
	btn1->Register (this);
	btn->AttachWnd(btn1);
	btn1->Build ();
	////////////////////////////////////
	
	GUIButton *bt2=new GUIButton();	//the second button in the window
	bt2->SetWindowPos ((Real).2,(Real).2,(Real)0.1,(Real)0.1);
	bt2->SetImages ("back02.png","back01.png","back03.png","back02.png");
	
	bt2->Register (this);
	myguiwindow1->AttachWnd(bt2);
	bt2->Build ();
	s3->GuiManager->AttachWnd (myguiwindow1);
//creating the second window
	GUIWindow *myguiwindow2=new GUIWindow();
	myguiwindow2->SetWindowPos (0,0,.5,.5);
	myguiwindow2->Background ="Bitmap2.bmp";
	myguiwindow2->Build ();
	GUIButton *bt3=new GUIButton("TestModal");	//the first button in the window
	bt3->SetWindowPos ((Real)0.1,(Real)0.1,(Real)0.1,(Real)0.1);
	bt3->SetImages ("back02.png","back01.png","back03.png","back02.png");
	bt3->Register (this);
	myguiwindow2->AttachWnd(bt3);
	bt3->Build ();
	s3->GuiManager->AttachWnd (myguiwindow2);

	((CViewPort*)mViewPorts["view port3"])->Camera=(Camera*)mCameras["Camera1"];
	((CViewPort*)mViewPorts["view port3"])->scene=s3;
	window->mViewPorts.Add((CViewPort*)mViewPorts["view port3"]);

	/////////
	// do modal dialog
	Modal=new GUIWindow();
	Modal->SetWindowPos (-.25,.25,.5,.5);
	Modal->Background ="Bitmap2.bmp";
	Modal->Build ();
	GUIButton *btclose=new GUIButton("CloseModal"); //the first button in the window
	btclose->SetWindowPos (0,0,(Real)0.1,(Real)0.1);
	btclose->SetImages ("back02.png","back01.png","back03.png","back02.png");
	btclose->Register (this);
	Modal->AttachWnd(btclose);
	btclose->Build ();
*/
}
void CMyApplication::CleanUp(void)
{
CWindowedApplication::CleanUp();
if(Modal) delete Modal;
if(window) delete window;
}

bool CMyApplication::FrameStarted(int LastFrameTime)
{


	return TRUE;
}
bool CMyApplication::FrameEnded(int LastFrameTime)
{
	return TRUE;
}
/*
void CMyApplication::OnClose()
{
	rs->shutdown();
}*/

void CMyApplication::CreateInput(void)
{
//	Input=new DirectInputManager(Parentwnd,true);

}

void CMyApplication::OnMessage(GUIWnd* wnd,unsigned int Message,Real wParam,Real lParam)
{
	if(Message==BT_CLICKED)
	{
		if(wnd->InternalName =="Exit")
		{
		//	rs->mRenderIn .RemoveAll ();
			rs->shutdown();
		}
		else if (wnd->InternalName=="TestModal")
		{
			wnd->GuiMan ->DoModal (Modal);
		}
		else if (wnd->InternalName=="CloseModal")
		{
		//	wnd->GuiMan ->ActiveWindow =Modal;
			wnd->GuiMan ->ReleaseModal ();
		}
		else
		{
			AfxMessageBox (wnd->InternalName + " has been clicked and parent "+wnd->Parent ->InternalName );
		}
	}
}