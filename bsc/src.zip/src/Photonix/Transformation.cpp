// Transformation.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "Transformation.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTransformation dialog
IMPLEMENT_SERIAL(CTransformation,CAccessDialog,1)

CTransformation::CTransformation(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CTransformation::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTransformation)
	m_rot_x = 0.0f;
	m_rot_y = 0.0f;
	m_rot_z = 0.0f;
	m_scale_x = 1.0f;
	m_scale_y = 1.0f;
	m_scale_z = 1.0f;
	m_trans_x = 0.0f;
	m_trans_y = 0.0f;
	m_trans_z = 0.0f;
	//}}AFX_DATA_INIT
}


void CTransformation::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTransformation)
	DDX_Text(pDX, IDC_ROT_X, m_rot_x);
	DDX_Text(pDX, IDC_ROT_Y, m_rot_y);
	DDX_Text(pDX, IDC_ROT_Z, m_rot_z);
	DDX_Text(pDX, IDC_SCALE_X, m_scale_x);
	DDX_Text(pDX, IDC_SCALE_Y, m_scale_y);
	DDX_Text(pDX, IDC_SCALE_Z, m_scale_z);
	DDX_Text(pDX, IDC_TRANS_X, m_trans_x);
	DDX_Text(pDX, IDC_TRANS_Y, m_trans_y);
	DDX_Text(pDX, IDC_TRANS_Z, m_trans_z);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTransformation, CDialog)
	//{{AFX_MSG_MAP(CTransformation)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTransformation message handlers
void CTransformation::Serialize(CArchive &ar)
{
	if(ar.IsStoring ())
	{
//		ar<<m_usegradient;
			ar<<	m_rot_x<<m_rot_y<<m_rot_z<<m_scale_x<<m_scale_y<<m_scale_z<<m_trans_x<<m_trans_y<<m_trans_z;

	}
	else
	{
//		ar>>m_usegradient;
			ar>>	m_rot_x>>m_rot_y>>m_rot_z>>m_scale_x>>m_scale_y>>m_scale_z>>m_trans_x>>m_trans_y>>m_trans_z;

	}

}
