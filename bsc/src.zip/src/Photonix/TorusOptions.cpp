// TorusOptions.cpp : implementation file
//

#include "stdafx.h"
#include "photonix.h"
#include "TorusOptions.h"
#include "TorusMesh.h"
#include "Application.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTorusOptions dialog


CTorusOptions::CTorusOptions(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CTorusOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTorusOptions)
	m_brad = 0.5f;
	m_srad = 0.3f;
	//}}AFX_DATA_INIT
}


void CTorusOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTorusOptions)
	DDX_Text(pDX, IDC_BIGRAD, m_brad);
	DDX_Text(pDX, IDC_SMALLRAD, m_srad);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTorusOptions, CDialog)
	//{{AFX_MSG_MAP(CTorusOptions)
	ON_EN_KILLFOCUS(IDC_BIGRAD, OnKillfocusBigrad)
	ON_EN_KILLFOCUS(IDC_SMALLRAD, OnKillfocusSmallrad)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTorusOptions message handlers

void CTorusOptions::OnKillfocusBigrad() 
{
	this->UpdateData();
	TorusMesh* tm=(TorusMesh*)this->m_Object->pRenderable;
	tm->BigRadius=this->m_brad;
	tm->ReConstruct();
	GetMainApp()->FireRefresh();
}

void CTorusOptions::OnKillfocusSmallrad() 
{
	this->UpdateData();
	TorusMesh* tm=(TorusMesh*)this->m_Object->pRenderable;
	tm->BigRadius=this->m_srad;
	tm->ReConstruct();
	GetMainApp()->FireRefresh();

}
