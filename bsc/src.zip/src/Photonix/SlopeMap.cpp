// SlopeMap.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "SlopeMap.h"
#include "slopemapentry.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSlopeMap dialog
IMPLEMENT_SERIAL(SlopeMap,CObject,1)
void SlopeMap::Serialize(CArchive &ar)
{
	if(ar.IsStoring ())
	{
		ar<<Number<<Height<<Slope;
	}
	else
	{
		ar>>Number>>Height>>Slope;
	}
}

IMPLEMENT_SERIAL(CSlopeMap,CDialog,1)
CSlopeMap::CSlopeMap(CWnd* pParent /*=NULL*/)
	: CDialog(CSlopeMap::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSlopeMap)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSlopeMap::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSlopeMap)
	DDX_Control(pDX, IDC_LIST1, m_list);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSlopeMap, CDialog)
	//{{AFX_MSG_MAP(CSlopeMap)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_BN_CLICKED(IDC_DEL, OnDel)
	ON_BN_CLICKED(IDC_DELALL, OnDelall)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSlopeMap message handlers

void CSlopeMap::OnAdd() 
{
	// TODO: Add your control notification handler code here
	CSlopeMapEntry dlg;
	if(dlg.DoModal ()==IDOK)
	{
		SlopeMap *s=new SlopeMap();
		s->Height =dlg.m_height ;
		s->Number =dlg.m_number ;
		s->Slope =dlg.m_slope ;
		slopmaps.Add (s);
		CString string1;string1 .Format ("%f",s->Number );
		CString string2;string2 .Format ("%f",s->Height);
		CString string3;string3 .Format ("%f",s->Slope  );
		int i=m_list.InsertItem (m_list.GetItemCount (),string1);
		m_list.SetItemText (i,1,string2);
		m_list.SetItemText (i,2,string3);

	}
}


void CSlopeMap::OnDel() 
{
	// TODO: Add your control notification handler code here
	POSITION pos=m_list.GetFirstSelectedItemPosition ();
int i=m_list.GetNextSelectedItem (pos);
if(i!=-1)
{
	delete slopmaps[i];
	slopmaps.RemoveAt (i);
m_list.DeleteItem (i);

}
}

void CSlopeMap::OnDelall() 
{
	// TODO: Add your control notification handler code here
Free();
	m_list.DeleteAllItems ();

}

BOOL CSlopeMap::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
m_list.InsertColumn (0,"Number",LVCFMT_LEFT,200);
m_list.InsertColumn (1,"Height",LVCFMT_LEFT,200);
m_list.InsertColumn (2,"Slope",LVCFMT_LEFT,200);

FillList();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSlopeMap::FillList()
{
	m_list.DeleteAllItems ();
	int count=slopmaps.GetSize ();
	for(int i=0;i<count;i++)
	{
		SlopeMap * s=(SlopeMap*)slopmaps[i];
		CString string1;string1 .Format ("%f",s->Number );
		CString string2;string2 .Format ("%f",s->Height);
		CString string3;string3 .Format ("%f",s->Slope  );
		m_list.InsertItem (i,string1);
		m_list.SetItemText (i,1,string2);
		m_list.SetItemText (i,2,string3);
	}

}
void CSlopeMap::Serialize(CArchive &ar)
{
	slopmaps.Serialize (ar);
	/*if(ar.IsStoring ())
	{
		ar<<m_sel_pat<<	m_bump_depth<<m_agate_turb<<	m_gx<<	m_gy<<	m_gz<<	m_mandel_iter<<	m_arms<<	m_c0<<m_c1;
	}
	else
	{
		ar>>m_sel_pat>>	m_bump_depth>>m_agate_turb>>	m_gx>>	m_gy>>	m_gz>>	m_mandel_iter>>	m_arms>>	m_c0>>m_c1;	
	}*/
}


void CSlopeMap::Free(void)
{
	int count=slopmaps.GetSize ();

	for(int i=0;i<count;i++)
	{
delete slopmaps[i];
	}
	slopmaps.RemoveAll ();

}

BOOL CSlopeMap::DestroyWindow()
{
	// TODO: Add your specialized code here and/or call the base class
Free();

	return CDialog::DestroyWindow();
}
