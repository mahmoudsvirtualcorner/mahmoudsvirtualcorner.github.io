// ObjectOptions.cpp : implementation file
//

#include "stdafx.h"
#include "photonix.h"
#include "ObjectOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CObjectOptions dialog


CObjectOptions::CObjectOptions(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CObjectOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(CObjectOptions)
	m_noshadow = FALSE;
	//}}AFX_DATA_INIT
}


void CObjectOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CObjectOptions)
	DDX_Check(pDX, IDC_NOSHADOW, m_noshadow);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CObjectOptions, CDialog)
	//{{AFX_MSG_MAP(CObjectOptions)
	ON_BN_CLICKED(IDC_NOSHADOW, OnNoshadow)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CObjectOptions message handlers

void CObjectOptions::OnNoshadow() 
{
			UpdateData(true);
m_Object->HasShadow=!m_noshadow;

}
