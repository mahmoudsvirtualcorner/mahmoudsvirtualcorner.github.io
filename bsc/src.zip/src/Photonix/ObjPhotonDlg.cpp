// ObjPhotonDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "ObjPhotonDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CObjPhotonDlg dialog


CObjPhotonDlg::CObjPhotonDlg(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CObjPhotonDlg::IDD, pParent)
	, m_reflection(false)
	, m_refraction(false)
{
	//{{AFX_DATA_INIT(CObjPhotonDlg)
	m_RecieveCaustics = FALSE;
	m_GenerateCaustics = FALSE;
	//}}AFX_DATA_INIT
}


void CObjPhotonDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CObjPhotonDlg)
	DDX_Check(pDX, IDC_RECIEVE_CAUSTICS, m_RecieveCaustics);
	DDX_Check(pDX, IDC_GENERATE_CAUSTICS, m_GenerateCaustics);
	DDX_Check(pDX, IDC_REFLECTION, m_reflection);
	DDX_Check(pDX, IDC_REFRACTION, m_refraction);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CObjPhotonDlg, CDialog)
	//{{AFX_MSG_MAP(CObjPhotonDlg)
	ON_BN_CLICKED(IDC_GENERATE_CAUSTICS, OnGenerateCaustics)
	ON_BN_CLICKED(IDC_RECIEVE_CAUSTICS, OnRecieveCaustics)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_REFLECTION, OnReflection)
	ON_BN_CLICKED(IDC_REFRACTION, OnRefraction)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CObjPhotonDlg message handlers

void CObjPhotonDlg::OnGenerateCaustics() 
{
	UpdateData(true);
	// TODO: Add your control notification handler code here
m_Object->GenerateCaustics =m_GenerateCaustics;
	//	m_Object->obj
if(!m_GenerateCaustics)
	{
m_reflection=m_refraction=false;
UpdateData(false);

	}
}

void CObjPhotonDlg::OnRecieveCaustics() 
{
	// TODO: Add your control notification handler code here
	UpdateData(true);
	m_Object->RecieveCaustics =m_RecieveCaustics;
	

}

void CObjPhotonDlg::OnReflection()
{
	UpdateData(true);
	m_Object->Reflection=m_reflection;
}

void CObjPhotonDlg::OnRefraction()
{
	UpdateData(true);
m_Object->Refraction=m_refraction;
}
