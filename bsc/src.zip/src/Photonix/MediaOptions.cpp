// MediaOptions.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "MediaOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMediaOptions dialog


CMediaOptions::CMediaOptions(CWnd* pParent /*=NULL*/)
	: CDialog(CMediaOptions::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMediaOptions)
	m_MediaEnabled = FALSE;
	m_selMedia = _T("");
//	m_sel_media_index = -1;
	//}}AFX_DATA_INIT
}


void CMediaOptions::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMediaOptions)
	DDX_Control(pDX, IDC_MEDIA_LIST, m_list);
	DDX_Check(pDX, IDC_ENABLED, m_MediaEnabled);
//	DDX_LBIndex(pDX, IDC_MEDIA_LIST, m_sel_media_index);
	DDX_LBString(pDX, IDC_MEDIA_LIST, m_selMedia);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMediaOptions, CDialog)
	//{{AFX_MSG_MAP(CMediaOptions)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMediaOptions message handlers

BOOL CMediaOptions::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
		POSITION pos=Medias->GetStartPosition ();
		while (pos!=NULL)
		{
			CObject *obj;CString key;
			Medias->GetNextAssoc (pos,key,obj);
			m_list.AddString (key);
			
		}	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
