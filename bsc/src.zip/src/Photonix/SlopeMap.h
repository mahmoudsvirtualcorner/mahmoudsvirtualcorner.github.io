#if !defined(AFX_SLOPEMAP_H__1133B233_0B89_4669_82F4_5E7F4A1ED625__INCLUDED_)
#define AFX_SLOPEMAP_H__1133B233_0B89_4669_82F4_5E7F4A1ED625__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SlopeMap.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSlopeMap dialog
class SlopeMap:public CObject
{
	DECLARE_SERIAL(SlopeMap);

	float Number,Height,Slope;
virtual void Serialize(CArchive &ar);

};
class CSlopeMap : public CDialog
{
// Construction
public:
	DECLARE_SERIAL(CSlopeMap);
	void FillList();
	CSlopeMap(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSlopeMap)
	enum { IDD = IDD_SLOPE_MAP };
	CListCtrl	m_list;
	//}}AFX_DATA
virtual void Serialize(CArchive &ar);

CObArray slopmaps;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSlopeMap)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSlopeMap)
	afx_msg void OnAdd();
	afx_msg void OnDel();
	afx_msg void OnDelall();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	void Free(void);
	virtual BOOL DestroyWindow();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SLOPEMAP_H__1133B233_0B89_4669_82F4_5E7F4A1ED625__INCLUDED_)
