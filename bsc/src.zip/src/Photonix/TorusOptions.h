#if !defined(AFX_TORUSOPTIONS_H__3C6FB951_A03B_44D7_B76D_C6BCA44CF13A__INCLUDED_)
#define AFX_TORUSOPTIONS_H__3C6FB951_A03B_44D7_B76D_C6BCA44CF13A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TorusOptions.h : header file
//
#include "AccessDialog.h"
#include "enggenclasses.h"

/////////////////////////////////////////////////////////////////////////////
// CTorusOptions dialog

class CTorusOptions : public CAccessDialog//CDialog
{
// Construction
public:
	CTorusOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTorusOptions)
	enum { IDD = IDD_TORUSOPTIONS };
	float	m_brad;
	float	m_srad;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTorusOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTorusOptions)
	afx_msg void OnKillfocusBigrad();
	afx_msg void OnKillfocusSmallrad();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TORUSOPTIONS_H__3C6FB951_A03B_44D7_B76D_C6BCA44CF13A__INCLUDED_)
