#if !defined(AFX_PICTUREDIALOG_H__EAB44B4E_F916_11D7_B4C3_8B894E720A24__INCLUDED_)
#define AFX_PICTUREDIALOG_H__EAB44B4E_F916_11D7_B4C3_8B894E720A24__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PictureDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPictureDialog dialog

#include "Picturectrl.h"

class CPictureDialog : public CDialog
{
public:
	CPictureCtrl m_Window;
	bool maxreached;
// Construction
public:
	CPictureDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPictureDialog)
	enum { IDD = IDD_PICTUREDIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPictureDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPictureDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
	afx_msg void OnWindowPosChanging(WINDOWPOS* lpwndpos);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PICTUREDIALOG_H__EAB44B4E_F916_11D7_B4C3_8B894E720A24__INCLUDED_)
