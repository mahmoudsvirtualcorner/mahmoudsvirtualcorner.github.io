// RenderScene.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "RenderScene.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRenderScene dialog


CRenderScene::CRenderScene(CWnd* pParent /*=NULL*/)
	: CDialog(CRenderScene::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRenderScene)
	m_start = 64;
	m_stop = 2;
	m_threshold = 1.0f;
	m_jitter = 1.0f;
	m_mosaic = FALSE;
	m_antialiasing = FALSE;
	m_sampling_method = 0;
	m_use_radiosity = FALSE;
	m_depth = 9;
	m_height =240;
	m_width =  320;
	m_selcam = _T("");
	//}}AFX_DATA_INIT
}


void CRenderScene::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRenderScene)
	DDX_Control(pDX, IDC_CAMERAS, m_cameranames);
	DDX_Text(pDX, IDC_START, m_start);
	DDX_Text(pDX, IDC_STOP, m_stop);
	DDX_Text(pDX, IDC_THRESHOLD, m_threshold);
	DDV_MinMaxFloat(pDX, m_threshold, 0.f, 1.f);
	DDX_Text(pDX, IDC_JITTER, m_jitter);
	DDV_MinMaxFloat(pDX, m_jitter, 0.f, 1.f);
	DDX_Check(pDX, IDC_MOSAIC, m_mosaic);
	DDX_Check(pDX, IDC_ANTIALIASING, m_antialiasing);
	DDX_CBIndex(pDX, IDC_SAMPLING_METHOD, m_sampling_method);
	DDX_Check(pDX, IDC_USE_RADIOSITY, m_use_radiosity);
	DDX_CBIndex(pDX, IDC_DEPTH, m_depth);
	DDX_Text(pDX, IDC_HEIGHT, m_height);
	DDX_Text(pDX, IDC_WIDTH, m_width);
	DDX_CBString(pDX, IDC_CAMERAS, m_selcam);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRenderScene, CDialog)
	//{{AFX_MSG_MAP(CRenderScene)
	ON_BN_CLICKED(IDC_RENDER, OnRender)
	//}}AFX_MSG_MAP
	ON_CBN_SELENDOK(IDC_RESOLUTIONX, OnCbnSelendokResolutionx)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRenderScene message handlers

void CRenderScene::OnRender() 
{
	UpdateData ();
	//int m=m_cameranames.GetCurSel ();
	//if(m!=-1)
	//{
/*		COMBOBOXEXITEM pitem;
		CString text;
		pitem.mask =CBEIF_TEXT;
pitem.pszText =text.GetBuffer (256);
pitem.iItem =-1;
pitem.cchTextMax=256;
		m_cameranames.GetItem(&pitem);
		text.ReleaseBuffer (256);
		SelectedCameraName = text;
	//}*/
		SelectedCameraName=m_selcam;
EndDialog (IDC_RENDER);	
}

void CRenderScene::OnCbnSelendokResolutionx()
{
	CComboBox * combo=(CComboBox*)this->GetDlgItem (IDC_RESOLUTIONX);
	int index=combo->GetCurSel ();
	if(index==0)
	{
		m_width=160;
		m_height =120;
	}
	else if(index==1)
	{
		m_width=320;
		m_height =200;
	}
	else if(index==2)
	{
		m_width=320;
		m_height =240;
	}
	else if(index==3)
	{
		m_width=512;
		m_height =384;
	}
	else if(index==4)
	{
		m_width=640;
		m_height =480;
	}
	else if(index==5)
	{
		m_width=800;
		m_height =600;
	}
	else if(index==6)
	{
		m_width=1024;
		m_height =768;
	}
this->UpdateData (false);
}

BOOL CRenderScene::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  Add extra initialization here
CComboBox * combo=(CComboBox*)this->GetDlgItem (IDC_DEPTH);
combo->SetCurSel (8);
combo=(CComboBox*)this->GetDlgItem (IDC_RAYS);
combo->SetCurSel (0);
combo=(CComboBox*)this->GetDlgItem (IDC_RESOLUTIONX);
combo->SetCurSel (2);
/*int i=0;
POSITION pos=Cameras->GetStartPosition ();
	while (pos!=NULL)
	{
		CObject *camara;CString key;
		Cameras->GetNextAssoc (pos,key,camara);
		
		int ret=m_cameranames.AddString (key.GetBuffer (256));
key.ReleaseBuffer (256);
		i++;*/

int count=Cameras.GetSize ();
for(int i=0;i<count;i++)
{
	CString key=Cameras[i];
		int ret=m_cameranames.AddString (key.GetBuffer (256));
key.ReleaseBuffer (256);
}
//if(count>0)
//{
//m_cameranames.SetCurSel (0);
//m_cameranames.SelectString (0,SelectedCameraName);
//CComboBox* box=m_cameranames.GetComboBoxCtrl ();
int index=m_cameranames.FindString (-1,SelectedCameraName);
if(index!=-1)
	m_cameranames.SetCurSel (index);
//}
//	}


	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
