#if !defined(AFX_MEDIAOPTIONS_H__790F0910_C897_4207_9D8D_1E5E824B2F03__INCLUDED_)
#define AFX_MEDIAOPTIONS_H__790F0910_C897_4207_9D8D_1E5E824B2F03__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MediaOptions.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMediaOptions dialog

class CMediaOptions : public CDialog
{
// Construction
public:
	CMediaOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMediaOptions)
	enum { IDD = IDD_GLOBAL_MEDIA };
	CListBox	m_list;
	BOOL	m_MediaEnabled;
	CString	m_selMedia;
//	int		m_sel_media_index;
	//}}AFX_DATA
CMapStringToOb *Medias;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMediaOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMediaOptions)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MEDIAOPTIONS_H__790F0910_C897_4207_9D8D_1E5E824B2F03__INCLUDED_)
