// TexMakerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "TexMakerDlg.h"
#include "SlopeMap.h"
#include "photonixdoc.h"
#include "MaterialsDlg.h"

/*
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
*/

/////////////
#include "SerializeAccess.h"
#include "selectcolor.h"
#include "BitmapModifier.h"
#include "BlockPattern.h"
#include "NoisePattern.h"
#include "FinishDlg.h"
#include "MapEntry.h"
#include "Transformation.h"
#include "TextureTreeParser.h"
#include "NoiseModifier.h"
#include "WarpDlg.h"
#include "InteriorDlg.h"
#include "MediaDlg.h"
#include "TextureTreeParser.h"
#include "NodeName.h"
#include "CreateMaterial.h"
#include "RainbowOptions.h"
//#include "PhotonixDlg.h"
//#include "texparse.h"
//TEXTURE * texglobal;
//extern TEXTURE *Default_Texture;

//CTreeCtrl *gtree;
CTextureTreeParser TreeParser;
//void SetRenderSettings(IRayEngine* Eng);
void TexDescScene(IRayEngine* Eng);
void TexSetRenderSettings(IRayEngine*Eng);
void TexDisplay_Plot(int x, int y, int r, int g, int b, int a);
CPictureCtrl CTexMakerDlg::m_Window;

/////////////////////////////////////////////////////////////////////////////
// CTexMakerDlg dialog

CTexMakerDlg::CTexMakerDlg(CWnd* pParent /*=NULL*/)
: CDialog(CTexMakerDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTexMakerDlg)
	m_currainbow = _T("");
	m_curskysphere = _T("");
	m_scenetype = 0;
	m_antialias = TRUE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	//m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	root=hCurItem=0;
	SceneEnviromental=false;
	m_CurrentMaterialName="";
}

void CTexMakerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTexMakerDlg)
	DDX_Control(pDX, IDC_TREE1, m_tree);
	DDX_Text(pDX, IDC_CURRENT_RAINBOW, m_currainbow);
	DDX_Text(pDX, IDC_CURRENT_SKYSPHERE, m_curskysphere);
	DDX_Radio(pDX, IDC_SCENE_MATERIAL, m_scenetype);
	DDX_Check(pDX, IDC_ANTIALIAS, m_antialias);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTexMakerDlg, CDialog)
//{{AFX_MSG_MAP(CTexMakerDlg)
ON_WM_PAINT()
ON_WM_QUERYDRAGICON()
ON_BN_CLICKED(IDC_PREVIEW, OnPreview)
ON_NOTIFY(NM_RCLICK, IDC_TREE1, OnRclickTree1)
ON_NOTIFY(TVN_DELETEITEM, IDC_TREE1, OnDeleteitemTree1)
ON_COMMAND(IDC_STANDARD_TEX, OnAddStandardTex)
ON_UPDATE_COMMAND_UI(IDC_STANDARD_TEX, OnUpdateStandardTex)
ON_COMMAND(IDC_TEX_MAP, OnAddTexMap)
ON_COMMAND(IDC_MAT_MAP, OnAddMatMap)
ON_COMMAND(IDC_TEX_LAYERED, OnAddTexLayered)
ON_COMMAND(IDC_TEX_PAT, OnAddTexPat)
ON_BN_CLICKED(IDC_SAVE, OnSave)
ON_BN_CLICKED(IDC_LOAD, OnLoad)
ON_BN_CLICKED(IDC_PROPERTIES, OnProperties)
ON_COMMAND(IDC_PIGMENT, OnPigment)
ON_COMMAND(IDC_SOLID_COLOR, OnSolidColor)
ON_COMMAND(IDC_TEX_PAT_ENTRY, OnAddTexPatEntry)
ON_COMMAND(IDC_LEY_STAND_TEX, OnAddLeyStandTex)
ON_COMMAND(IDC_BP_ST, OnBpSt)
ON_COMMAND(IDC_BP_BPT, OnBpBpt)
ON_COMMAND(IDC_BP_LT, OnBpLt)
ON_COMMAND(IDC_BP_MM, OnBpMm)
ON_COMMAND(IDC_BP_TM, OnBpTm)
ON_COMMAND(IDC_MATMAP_BPT, OnMatmapBpt)
ON_COMMAND(IDC_MATMAP_LT, OnMatmapLt)
ON_COMMAND(IDC_MATMAP_MM, OnMatmapMm)
ON_COMMAND(IDC_MATMAP_ST, OnMatmapSt)
ON_COMMAND(IDC_MATMAP_TM, OnMatmapTm)
ON_COMMAND(IDC_TEXMAP_BPT, OnTexmapBpt)
ON_COMMAND(IDC_TEXMAP_LT, OnTexmapLt)
ON_COMMAND(IDC_TEXMAP_MM, OnTexmapMm)
ON_COMMAND(IDC_TEXMAP_ST, OnTexmapSt)
ON_COMMAND(IDC_TEXMAP_TM, OnTexmapTm)
ON_COMMAND(ID_PIG_BP_SC, OnPigBpSc)
ON_COMMAND(ID_PIG_BP_PIG, OnPigBpPig)
ON_COMMAND(ID_PIG_IM, OnPigIm)
ON_COMMAND(ID_PIG_CM, OnPigCm)
ON_COMMAND(ID_PIG_PM, OnPigPm)
ON_COMMAND(IDC_FINISH, OnFinish)
ON_COMMAND(IDC_BP_SOLID_COLOR, OnBpSolidColor)
ON_COMMAND(IDC_BP_PIGMENT, OnBpPigment)
ON_COMMAND(IDC_MAP_ENTRY, OnMapEntry)
ON_BN_CLICKED(IDC_SCENE_SETTINGS, OnSceneSettings)
ON_WM_DESTROY()
ON_COMMAND(ID_SYS_CHANGENAME, OnSysChangename)
ON_BN_CLICKED(IDC_RENDER, OnRender)
ON_BN_CLICKED(IDC_ADDMATERIAL, OnAddmaterial)
	ON_COMMAND(ID_ADDTORAINBOWMAT_RAINBOW, OnAddtorainbowmatRainbow)
	ON_BN_CLICKED(IDC_BROWSERAINBOWS, OnBrowseRainbows)
	ON_BN_CLICKED(IDC_BROWSESKYSPHERE, OnBrowseSkysphere)
	//}}AFX_MSG_MAP
//	ON_WM_CHAR()
ON_COMMAND(ID_SYS_DELETE, OnSysDelete)
ON_COMMAND(ID_ADDTONORMAL_NORMALPATTERN, OnAddtonormalNormalpattern)
ON_COMMAND(ID_ADDTONORMAL_BLOCKPATTERNWITHNORMALS, OnAddtonormalBlockpatternwithnormals)
ON_COMMAND(ID_ADDTONORMAL_NORMALMAPPATTERN, OnAddtonormalNormalmappattern)
ON_COMMAND(ID_BUMP_MAP, OnBumpMap)
ON_COMMAND(ID_BPN_NORMAL, OnBpnNormal)
ON_COMMAND(IDC_NORMAL_MAP_ENTRY, OnNOrmalMapEntry)
ON_COMMAND(IDC_NORMAL, OnNormal)
ON_NOTIFY(TVN_SELCHANGED, IDC_TREE1, OnTvnSelchangedTree1)
ON_COMMAND(IDC_INTERIOR, OnInterior)
ON_COMMAND(IDC_MEDIA, OnMedia)
ON_COMMAND(IDC_DENISTY, OnDenisty)
ON_COMMAND(ID_ADDTODENSITY_DENSITYPATTERN, OnAddtodensityDensitypattern)
ON_COMMAND(ID_ADDTODENSITY_BLOCKPATTERNWITHDENSITIES, OnAddtodensityBlockpatternwithdensities)
ON_COMMAND(ID_ADDTODENSITY_DENSITYMAPPATTERN, OnAddtodensityDensitymappattern)
ON_BN_CLICKED(ID_STOPPREVIEW, OnStopPreview)
ON_BN_CLICKED(IDC_SCENE_MATERIAL, OnSceneMaterial)
ON_BN_CLICKED(IDC_SCENE_ENVIROMENTAL, OnSceneEnviromental)
ON_BN_CLICKED(IDC_REMOVEALL, OnRemoveAll)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTexMakerDlg message handlers
BOOL CTexMakerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	CWnd * wnd=this->GetDlgItem (IDC_ROLLUP);
	CRect rect;
	wnd->GetWindowRect (&rect);
	this->ScreenToClient (&rect);
	BOOL bSuccess;	
	bSuccess = m_rollup.Create(WS_CHILD | WS_DLGFRAME | WS_VISIBLE, rect, this, 1100);//CRect(220,0,220+350,400)
	ASSERT(bSuccess);
	
/*	root=m_tree.InsertItem ( "Material1");
	ItemDATA* item=new ItemDATA(I_MATERIAL);
	item->Name ="Material1";
	m_tree.SetItemData (root,(DWORD)item);
	m_tree.SelectItem (root);
*/
	CRect r;
	wnd=this->GetDlgItem (IDC_TEXTURE_PREVIEW);
	wnd->GetWindowRect (&r);
	this->ScreenToClient (&r);
	CTexMakerDlg::m_Window.SetPictureRect (CRect(0,0,r.Width (),r.Height ()));
	CTexMakerDlg::m_Window.Create (this,r,IDC_TEXTPREVIEW_WINDOW,WS_CHILD|WS_VISIBLE);
	CComboBox * combo=(CComboBox *)this->GetDlgItem (IDC_OBJECTS_COMBO);
	combo->SetCurSel (0);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTexMakerDlg::OnPaint() 
{
	/*if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		
		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else*/
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTexMakerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
//CDC* dc;

/**int Error(char* s)
{
AfxMessageBox(s);
return true;
}*/
CWinThread* w;

void CTexMakerDlg::OnPreview() 
{
	UpdateData ();
	{//getting the current material name
		HTREEITEM h=m_tree.GetSelectedItem();
		HTREEITEM Root;
		if(h!=0)
		{
			while(h)
			{
				Root=m_tree.GetParentItem(h);
				if(Root)
				{
					h=Root;
				}
				else
				{				
					m_CurrentMaterialName=m_tree.GetItemText(h);
					break;
				}
			}
		
		}
	}
	//this->Invalidate();
GenerateTexture();	
	(this->GetDlgItem (ID_STOPPREVIEW))->EnableWindow (true);
	(this->GetDlgItem (IDC_PREVIEW))->EnableWindow (false);

	w=	
		AfxBeginThread (CTexMakerDlg::Render,(LPVOID)this);

}


void TexDisplay_Plot(int x, int y, int r, int g, int b, int a)
{
	CTexMakerDlg::m_Window.Plot_Pixel(x,y ,r,g,b,a);
}

void CTexMakerDlg::OnOK() 
{
	Stop_Flag=true;	
	
	//	CDialog::OnOK();
}

void CmdRouteMenu(CWnd* pWnd,CMenu* pPopupMenu)
{
	CCmdUI state;
	state.m_pMenu = pPopupMenu;
	state.m_pParentMenu = pPopupMenu;
	state.m_nIndexMax = pPopupMenu->GetMenuItemCount();
	
	for (state.m_nIndex = 0; 
	state.m_nIndex < state.m_nIndexMax; 
	state.m_nIndex++) 
	{
		state.m_nID = pPopupMenu->GetMenuItemID(state.m_nIndex);
		
		// menu separator or invalid cmd - ignore it
		if (state.m_nID == 0) continue; 
		
		if (state.m_nID == (UINT)-1)
		{
			// possibly a popup menu, route to child menu if so
			CMenu* pSub=pPopupMenu->GetSubMenu(state.m_nIndex);
			if(pSub) CmdRouteMenu(pWnd,pSub);
		}
		else 
		{
			// normal menu item, Auto disable if command is 
			// _not_ a system command.
			state.m_pSubMenu = NULL;
			state.DoUpdate(pWnd, FALSE);
		}
	}
}

void CTexMakerDlg::OnRclickTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{CMenu menutmp;menutmp.CreatePopupMenu ();
// TODO: Add your control notification handler code here
CPoint point;
GetCursorPos (&point);
CTreeCtrl &ctrl=m_tree;
if (point != CPoint (-1, -1))
{
	CPoint ptTree = point;
	ctrl.ScreenToClient (&ptTree);
	hCurItem = ctrl.HitTest (ptTree);	
	if (hCurItem != NULL)
	{
		ItemDATA* d=(ItemDATA*)ctrl.GetItemData (hCurItem);
		CMenu menu,*m=0;
		if(d->menutype ==I_MATERIAL)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (0);ctrl.SelectItem (hCurItem);
			
		}
		else if(d->menutype ==I_STANDARD_TEX)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (1);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_TEX_PIGMENT|| d->menutype ==I_PIGMENT_MAP_VAL)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (2);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_BP_WITH_COLOR)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (3);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_BP_WITH_PIGMENT)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (4);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_PIGMENT_MAP || d->menutype ==I_NORMAL_MAP || d->menutype ==I_DENISTY_MAP)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (5);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_TEX_NORMAL || d->menutype ==I_NORMAL_MAP_VAL)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (6);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_NORMAL_PATTERN)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (7);ctrl.SelectItem (hCurItem);
		}
		
		else if(d->menutype ==I_BP_WITH_NORM)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (8);ctrl.SelectItem (hCurItem);
		}
		/*	else if(d->menutype ==I_NORMAL_MAP)
		{
		menu.LoadMenu (IDR_MENUMAIN);
		m=menu.GetSubMenu (9);ctrl.SelectItem (hCurItem);
	}*/
		else if(d->menutype ==I_TEX_MAP)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (10);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_TEX_LAYERED)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (11);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_MATERIAL_MAP)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (12);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_TEX_BP)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (13);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_TEX_MAP_VAL)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (14);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_INTERIOR)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (15);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_MEDIA)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (16);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_INTERIOR_DENISTY || d->menutype ==I_DENISTY_MAP_VAL)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (17);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_BP_WITH_DENISTY)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (18);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_SKY_SPHERE)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (19);ctrl.SelectItem (hCurItem);
		}
		else if(d->menutype ==I_RAINBOW_MATERIAL)
		{
			menu.LoadMenu (IDR_MENUMAIN);
			m=menu.GetSubMenu (20);ctrl.SelectItem (hCurItem);
		}
		
		else//if(m==0)
		{
			
			
			m=&menutmp;//menu.GetSubMenu (0);
			//m=new CMenu();			
			//				m->CreatePopupMenu ();
			//				m->CreatePopupMenu();
			//	m->LoadMenu();
		}
		CMenu menuadd,* menuaddptr;
		menuadd.LoadMenu (IDR_SYS);
		menuaddptr=menuadd.GetSubMenu (0);
		m->AppendMenu (MF_POPUP   ,(UINT_PTR)menuaddptr->GetSafeHmenu (),"misc");
		//	m->AppendMenu (MF_STRING|MF_POPUP   ,(UINT_PTR)menuadd.GetSafeHmenu ());
		menuaddptr->Detach ();
		menuadd.Detach ();
		CmdRouteMenu(this,m);
		m->TrackPopupMenu (TPM_LEFTBUTTON,point.x,point.y,this);
		}
	}
	
	*pResult = 0;
}

void CTexMakerDlg::OnDeleteitemTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	/*if(((ItemDATA*)pNMTreeView->itemOld.lParam)->data)
	{
	//ver1
	if(((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_TEX_COLOR)
	delete (CSelectColor*)((ItemDATA*)pNMTreeView->itemOld.lParam)->data;
	if(((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_TEX_FINISH)
	delete (CFinishDlg*)((ItemDATA*)pNMTreeView->itemOld.lParam)->data;
	if(((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_PIGMENT_MAP  || ((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_NORMAL_MAP || ((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_NORMAL_PATTERN)
	delete (CNoisePattern*)((ItemDATA*)pNMTreeView->itemOld.lParam)->data;
	if(((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_IMAGE_MAP || ((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_BUMP_MAP)
	delete (CBitmapModifier*)((ItemDATA*)pNMTreeView->itemOld.lParam)->data;
	if(((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_BP_WITH_PIGMENT|| ((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_BP_WITH_COLOR || ((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_BP_WITH_NORM)
	delete (CBlockPattern*)((ItemDATA*)pNMTreeView->itemOld.lParam)->data;
	if(((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_COLOR_MAP)
	delete (CRollUpDlg*)((ItemDATA*)pNMTreeView->itemOld.lParam)->data;
	if(((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_PIGMENT_MAP_VAL || ((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_TEX_MAP_VAL || ((ItemDATA*)pNMTreeView->itemOld.lParam)->menutype==I_NORMAL_MAP_VAL)
	delete (CMapEntry*)((ItemDATA*)pNMTreeView->itemOld.lParam)->data;
	*/
	// ver for virtual distructor
	//delete (CDialog*)((ItemDATA*)pNMTreeView->itemOld.lParam)->data;
	
	// ver3 new rollup ctrl
	m_rollup .RemoveAllPages ();
	CMapStringToOb& hashtable =((ItemDATA*)pNMTreeView->itemOld.lParam)->data;
	POSITION pos=hashtable.GetStartPosition ();
	while (pos!=NULL)
	{
		CObject *dlg;CString key;
		hashtable.GetNextAssoc (pos,key,dlg);
		((CDialog*)dlg)->DestroyWindow ();
		delete dlg;
	}
	//delete hashtable;
	//}
	delete (ItemDATA*)pNMTreeView->itemOld.lParam;
	*pResult = 0;
}

void CTexMakerDlg::OnAddStandardTex() 
{
	HTREEITEM h=this->m_tree .InsertItem ("standard tex",hCurItem);
	CTransformation *dlg=new CTransformation();
	dlg->Create (IDD_TRANSFORMATION,&m_rollup);
	ItemDATA* item=new ItemDATA(I_STANDARD_TEX);
	item->data["CTransformation"]=dlg;
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}

void CTexMakerDlg::OnUpdateStandardTex(CCmdUI* pCmdUI) 
{
/*	HTREEITEM h=this->m_tree.GetChildItem (hCurItem);
if(!h) return;
HTREEITEM h2=h;
do{

		ItemDATA* d=(ItemDATA*)this->m_tree .GetItemData (h2);
		if(d->menutype ==I_STANDARD_TEX)
		{
		//	AfxMessageBox ("updating");
		pCmdUI->Enable (false);
		return;
		}
		h2=this->m_tree .GetNextSiblingItem(h2);
		}
	while(h2);	*/
	/*	ItemDATA* d=(ItemDATA*)this->m_tree .GetItemData (hCurItem);
	if(d->menutype ==I_MATERIAL)
	{
	HTREEITEM h=this->m_tree.GetChildItem (hCurItem);
	if(!h) return;
	pCmdUI->Enable (false);return;
	}
	else if (d->menutype ==I_TEX_BP)
	{
	HTREEITEM h=this->m_tree.GetChildItem (hCurItem);
	if(!h) return;
	HTREEITEM h2=h;
	int count=0;
	do{
	count++;
	ItemDATA* d1=(ItemDATA*)this->m_tree .GetItemData (h2);
				return;
				h2=this->m_tree .GetNextSiblingItem(h2);
				}
				while(h2);
				if(count==2) pCmdUI->Enable (false);
}*/
}

void CTexMakerDlg::OnAddTexMap() 
{
	CNoisePattern *dlg=new CNoisePattern();
	dlg->Create (IDD_NOISE_PATTERN,&m_rollup);
	HTREEITEM h=this->m_tree .InsertItem ("texture map",hCurItem);
	ItemDATA* item=new ItemDATA(I_TEX_MAP);
	item->data["CNoisePattern"]=dlg;
	CTransformation *dlg1=new CTransformation();
	dlg1->Create (IDD_TRANSFORMATION,&m_rollup);
	item->data["CTransformation"]=dlg1;
	CNoiseModifier *dlg3=new CNoiseModifier();
	dlg3->Create (IDD_NOISE_MODIFIER,&m_rollup);
	item->data["CNoiseModifier"]=dlg3;

	CWarpDlg *dlg5=new CWarpDlg();
	dlg5->Create (IDD_WARP,&m_rollup);
	item->data["CWarpDlg"]=dlg5;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
	

}

void CTexMakerDlg::OnAddMatMap() 
{
	// TODO: Add your command handler code here
	HTREEITEM h=this->m_tree .InsertItem ("material map",hCurItem);
	CTransformation *dlg=new CTransformation();
	dlg->Create (IDD_TRANSFORMATION,&m_rollup);
	ItemDATA* item=new ItemDATA(I_MATERIAL_MAP);
	item->data["CTransformation"]=dlg;
	
	CBitmapModifier *dlg1=new CBitmapModifier();
	dlg1->Create (IDD_BITMAP_MODIFIER,&m_rollup);
	item->data["CBitmapModifier"]=dlg1;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}

void CTexMakerDlg::OnAddTexLayered() 
{
	// TODO: Add your command handler code here
	HTREEITEM h=this->m_tree .InsertItem ("layered tex",hCurItem);
	m_tree.SetItemData (h,(DWORD)new ItemDATA(I_TEX_LAYERED));
	m_tree.Expand (hCurItem,TVE_EXPAND);
}



void CTexMakerDlg::OnAddTexPat() 
{
	// TODO: Add your command handler code here
	HTREEITEM h=this->m_tree .InsertItem ("tex pattern",hCurItem);
	CBlockPattern *dlg=new CBlockPattern();
	dlg->Create (IDD_BLOCK_PATTERN,&m_rollup);
	ItemDATA* item=new ItemDATA(I_TEX_BP);
	item->data["CBlockPattern"]=dlg;
	CTransformation *dlg1=new CTransformation();
	dlg1->Create (IDD_TRANSFORMATION,&m_rollup);
	item->data["CTransformation"]=dlg1;
	
	CNoiseModifier *dlg3=new CNoiseModifier();
	dlg3->Create (IDD_NOISE_MODIFIER,&m_rollup);
	item->data["CNoiseModifier"]=dlg3;
	
	CWarpDlg *dlg5=new CWarpDlg();
	dlg5->Create (IDD_WARP,&m_rollup);
	item->data["CWarpDlg"]=dlg5;
	
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}

void CTexMakerDlg::OnSave() 
{
	char szFilters[]=
      "Material Library Files (*.mtl)|*.mtl|All Files (*.*)|*.*||";

	// Create an Open dialog; the default file name extension is ".my".
   CFileDialog fileDlg (FALSE, "mtl", "*.mtl",
       OFN_HIDEREADONLY, szFilters, this);
   
   // Display the file dialog. When user clicks OK, fileDlg.DoModal() 
   // returns IDOK.
   if( fileDlg.DoModal ()==IDOK )
   {
CString fileName = fileDlg.GetPathName ();
	CFile f(fileName,CFile::modeWrite | CFile::modeCreate | CFile::shareDenyWrite);
	CArchive ar(&f,CArchive::store);
	
	TreeAccess access(m_tree,ar);
	GenericSerialize(access);
   }
}

void CTexMakerDlg::OnLoad() 
{
	char szFilters[]=
      "Material Library Files (*.mtl)|*.mtl|All Files (*.*)|*.*||";

// Create an Open dialog; the default file name extension is ".my".
   CFileDialog fileDlg (TRUE, "mtl", "*.mtl",
      OFN_FILEMUSTEXIST| OFN_HIDEREADONLY, szFilters, this);
   
   // Display the file dialog. When user clicks OK, fileDlg.DoModal() 
   // returns IDOK.
   if( fileDlg.DoModal ()==IDOK )
   {
CString fileName = fileDlg.GetPathName ();

	CFile f(fileName,CFile::modeRead);
	CArchive ar(&f,CArchive::load);
	TreeAccess access(m_tree,ar);
	access.rollup=&m_rollup;
	
	this->m_tree .DeleteAllItems ();
	GenericDeserialize(access); 
   }
}



void CTexMakerDlg::OnProperties() 
{
	//	HTREEITEM h=m_tree.GetSelectedItem ();	
	//	ItemDATA* d=(ItemDATA*)this->m_tree .GetItemData (h);
	//	if(d->data )
	//	{
	//		((CDialog*)d->data)->DoModal ();
	//	}
}

void CTexMakerDlg::OnPigment() 
{
	HTREEITEM h=this->m_tree .InsertItem ("PIGMENT",hCurItem);
	CTransformation *dlg=new CTransformation();
	dlg->Create (IDD_TRANSFORMATION,&m_rollup);
	ItemDATA* item=new ItemDATA(I_TEX_PIGMENT);
	item->data["CTransformation"]=dlg;
	
	CNoiseModifier *dlg3=new CNoiseModifier();
	dlg3->Create (IDD_NOISE_MODIFIER,&m_rollup);
	item->data["CNoiseModifier"]=dlg3;
	
	CWarpDlg *dlg5=new CWarpDlg();
	dlg5->Create (IDD_WARP,&m_rollup);
	item->data["CWarpDlg"]=dlg5;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
	
}

void CTexMakerDlg::OnSolidColor() 
{
	HTREEITEM h=this->m_tree .InsertItem ("solid color",hCurItem);
	CSelectColor *dlg=new CSelectColor();
	dlg->m_usegradient=false;
	dlg->Create (IDD_COLORRANGE,&m_rollup);
	ItemDATA* item=new ItemDATA(I_TEX_COLOR);
	item->data["CSelectColor"]=dlg;
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
	
}

void CTexMakerDlg::OnAddTexPatEntry() 
{
	CMapEntry *dlg=new CMapEntry();
	//dlg->DoModal ();
	CString s;s.Format ("%f",dlg->m_pos);
	HTREEITEM h=this->m_tree .InsertItem ("tex pattern entry at "+s,hCurItem);
	dlg->Create (IDD_MAP_ENTRY,&m_rollup);
	ItemDATA* item=new ItemDATA(I_TEX_MAP_VAL);
	item->data["CMapEntry"]=dlg;
	
	CNoiseModifier *dlg3=new CNoiseModifier();
	dlg3->Create (IDD_NOISE_MODIFIER,&m_rollup);
	item->data["CNoiseModifier"]=dlg3;
	
	CWarpDlg *dlg5=new CWarpDlg();
	dlg5->Create (IDD_WARP,&m_rollup);
	item->data["CWarpDlg"]=dlg5;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);	
}

void CTexMakerDlg::OnAddLeyStandTex() 
{
/*HTREEITEM h=this->m_tree .InsertItem ("standard tex",hCurItem);
m_tree.SetItemData (h,(DWORD)new ItemDATA(I_STANDARD_TEX));
m_tree.Expand (hCurItem,TVE_EXPAND);
	*/
	OnAddStandardTex() ;
}

void CTexMakerDlg::OnBpSt()
{
	OnAddStandardTex() ;
}

void CTexMakerDlg::OnBpBpt() 
{
	// TODO: Add your command handler code here
	OnAddTexPat();
}

void CTexMakerDlg::OnBpLt() 
{
	// TODO: Add your command handler code here
	OnAddTexLayered();
}

void CTexMakerDlg::OnBpMm() 
{
	// TODO: Add your command handler code here
	OnAddMatMap();
}

void CTexMakerDlg::OnBpTm() 
{
	// TODO: Add your command handler code here
	OnAddTexMap();
}

void CTexMakerDlg::OnMatmapBpt() 
{
	// TODO: Add your command handler code here
	OnAddTexPat();
}

void CTexMakerDlg::OnMatmapLt() 
{
	// TODO: Add your command handler code here
	OnAddTexLayered();
}

void CTexMakerDlg::OnMatmapMm() 
{
	// TODO: Add your command handler code here
	OnAddMatMap();
}

void CTexMakerDlg::OnMatmapSt() 
{
	// TODO: Add your command handler code here
	OnAddStandardTex() ;
}

void CTexMakerDlg::OnMatmapTm() 
{
	// TODO: Add your command handler code here
	OnAddTexMap();
}

void CTexMakerDlg::OnTexmapBpt() 
{
	// TODO: Add your command handler code here
	OnAddTexPat();
}

void CTexMakerDlg::OnTexmapLt() 
{
	// TODO: Add your command handler code here
	OnAddTexLayered();
}

void CTexMakerDlg::OnTexmapMm() 
{
	// TODO: Add your command handler code here
	OnAddMatMap();
}

void CTexMakerDlg::OnTexmapSt() 
{
	// TODO: Add your command handler code here
	OnAddStandardTex() ;
	
}

void CTexMakerDlg::OnTexmapTm() 
{
	// TODO: Add your command handler code here
	OnAddTexMap();
}

void CTexMakerDlg::OnPigBpSc() 
{
	// TODO: Add your command handler code here
	HTREEITEM h=this->m_tree .InsertItem ("I_BP_WITH_COLOR",hCurItem);
	
	CBlockPattern *dlg=new CBlockPattern();
	dlg->Create (IDD_BLOCK_PATTERN,&m_rollup);
	ItemDATA* item=new ItemDATA(I_BP_WITH_COLOR);
	item->data["CBlockPattern"]=dlg;
	m_tree.SetItemData (h,(DWORD)item);
	
	m_tree.Expand (hCurItem,TVE_EXPAND);
}

void CTexMakerDlg::OnPigBpPig() 
{
	HTREEITEM h=this->m_tree .InsertItem ("I_BP_WITH_PIGMENT",hCurItem);
	CBlockPattern *dlg=new CBlockPattern();
	dlg->Create (IDD_BLOCK_PATTERN,&m_rollup);
	ItemDATA* item=new ItemDATA(I_BP_WITH_PIGMENT);
	item->data["CBlockPattern"]=dlg;
	m_tree.SetItemData (h,(DWORD)item);
	
	m_tree.Expand (hCurItem,TVE_EXPAND);
	
}

void CTexMakerDlg::OnPigIm() 
{
	HTREEITEM h=this->m_tree .InsertItem ("I_IMAGE_MAP",hCurItem);
	CBitmapModifier *dlg=new CBitmapModifier();
	dlg->Create (IDD_BITMAP_MODIFIER,&m_rollup);
	ItemDATA* item=new ItemDATA(I_IMAGE_MAP);
	item->data["CBitmapModifier"]=dlg;
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
	
	
}

void CTexMakerDlg::OnPigCm() 
{
	HTREEITEM h=this->m_tree .InsertItem ("I_COLOR_MAP",hCurItem);
	
	
	//	CNoisePattern *dlg=new CNoisePattern();
	//CRollUpDlg *dlg=new CRollUpDlg();
	//	CMergeNoiseAndColor dlg=new CMergeNoiseAndColor();
	CNoisePattern *dlg1=new CNoisePattern();
	CSelectColor *dlg2=new CSelectColor();
	
	dlg1->Create (IDD_NOISE_PATTERN,&m_rollup);
	dlg2->Create (IDD_COLORRANGE,&m_rollup);
	ItemDATA* item=new ItemDATA(I_COLOR_MAP);
	item->data["CNoisePattern"]=dlg1;
	item->data["CSelectColor"]=dlg2;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
	
	
	
}
void CTexMakerDlg::GenerateTexture()
{
	UpdateRollUpCtrl();
	TreeParser.m_tree =&m_tree ;
	TreeParser.GenerateTexture ();
	
	/*
	Default_Texture = new TEXTURE();
	Default_Texture->Pigment = new PIGMENT();
	Default_Texture->Tnormal = NULL;
	Default_Texture->Finish  = new FINISH();
	
	  //m_tree.
	  CMapStringToOb arr;
	  CMapStringToOb Interiors;
	  gtree=&m_tree;
	  HTREEITEM hroot=m_tree.GetRootItem ();//GetChildItem (hCurItem);
	  
		HTREEITEM h=hroot;//this->m_tree.GetChildItem (hroot);
		if(!h) return;
		HTREEITEM h2=h;
		do
		{
		
		  CString s=this->m_tree .GetItemText (h2);
		  INTERIOR *i;
		  arr[s]=(CObject*)ParseTexture(m_tree.GetChildItem (h2),i);
		  if(i)
		  {
		  Interiors[s]=i;
		  }
		  h2=this->m_tree .GetNextSiblingItem(h2);
		  }
		  while(h2);	
		  texglobal=(TEXTURE*)arr["Material1"];
		  
	*/
}
void CTexMakerDlg::OnPigPm() 
{
	HTREEITEM h=this->m_tree .InsertItem ("I_PIGMENT_MAP",hCurItem);
	CNoisePattern *dlg=new CNoisePattern();
	dlg->Create (IDD_NOISE_PATTERN,&m_rollup);
	ItemDATA* item=new ItemDATA(I_PIGMENT_MAP);
	item->data["CNoisePattern"]=dlg;
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}
void CTexMakerDlg::OnFinish() 
{
	// TODO: Add your command handler code here
	HTREEITEM h=this->m_tree .InsertItem ("the finish",hCurItem);
	CFinishDlg *dlg=new CFinishDlg();
	dlg->Create (IDD_FINISH,&m_rollup);
	ItemDATA* item=new ItemDATA(I_TEX_FINISH);
	item->data["CFinishDlg"]=dlg;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}

void CTexMakerDlg::OnBpSolidColor() 
{
	// TODO: Add your command handler code here
	HTREEITEM h=this->m_tree .InsertItem ("solid color",hCurItem);
	CSelectColor *dlg=new CSelectColor();
	dlg->m_usegradient=false;
	
	dlg->Create (IDD_COLORRANGE,&m_rollup);
	ItemDATA* item=new ItemDATA(I_TEX_COLOR);
	item->data["CSelectColor"]=dlg;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
	
}


void CTexMakerDlg::OnMapEntry() 
{
	//d->menutype ==I_PIGMENT_MAP || d->menutype ==I_NORMAL_MAP || d->menutype ==I_DENISTY_MAP
	ItemDATA* parent=(ItemDATA*)this->m_tree .GetItemData (hCurItem);
	ItemDATA* item;
	HTREEITEM h;
	if(parent->menutype  ==I_PIGMENT_MAP)
	{
		// TODO: Add your command handler code here
		//dlg->DoModal ();
		//		CString s;s.Format ("%f",dlg->m_pos);
		item=new ItemDATA(I_PIGMENT_MAP_VAL);
		h=this->m_tree .InsertItem ("PIG entry ",hCurItem);
	}
	else if(parent->menutype ==I_NORMAL_MAP)
	{
		//dlg->DoModal ();
		//	CString s;s.Format ("%f",dlg->m_pos);
		h=this->m_tree .InsertItem ("NORMAL entry ",hCurItem);
		item=new ItemDATA(I_NORMAL_MAP_VAL);
	}
	else if(parent->menutype ==I_DENISTY_MAP)
	{
		//	CString s;s.Format ("%f",dlg->m_pos);
		h=this->m_tree .InsertItem ("Denisty entry ",hCurItem);
		item=new ItemDATA(I_DENISTY_MAP_VAL);
		
	}
	
	CMapEntry *dlg=new CMapEntry();
	dlg->Create (IDD_MAP_ENTRY,&m_rollup);
	item->data["CMapEntry"]=dlg;
	
	CTransformation *dlg1=new CTransformation();
	dlg1->Create (IDD_TRANSFORMATION,&m_rollup);
	item->data["CTransformation"]=dlg1;
	
	CNoiseModifier *dlg2=new CNoiseModifier();
	dlg2->Create (IDD_NOISE_MODIFIER,&m_rollup);
	item->data["CNoiseModifier"]=dlg2;
	
	CWarpDlg *dlg3=new CWarpDlg();
	dlg3->Create (IDD_WARP,&m_rollup);
	item->data["CWarpDlg"]=dlg3;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
	
}
void CTexMakerDlg::OnAddtonormalNormalpattern()
{
	HTREEITEM h=this->m_tree .InsertItem ("normal pattern",hCurItem);
	CNoisePattern *dlg=new CNoisePattern();
	dlg->Create (IDD_NOISE_PATTERN,&m_rollup);
	ItemDATA* item=new ItemDATA(I_NORMAL_PATTERN);
	item->data["CNoisePattern"]=dlg;
	
	CSlopeMap *dlg2=new CSlopeMap();
	dlg2->Create (IDD_SLOPE_MAP,&m_rollup);
	item->data["CSlopeMap"]=dlg2;
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}
void CTexMakerDlg::OnAddtonormalBlockpatternwithnormals()
{
	HTREEITEM h=this->m_tree .InsertItem ("block norm",hCurItem);
	CBlockPattern *dlg=new CBlockPattern();
	dlg->Create (IDD_BLOCK_PATTERN,&m_rollup);
	ItemDATA* item=new ItemDATA(I_BP_WITH_NORM);
	item->data["CBlockPattern"]=dlg;
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}
void CTexMakerDlg::OnAddtonormalNormalmappattern()
{
	HTREEITEM h=this->m_tree .InsertItem ("normal pattern",hCurItem);
	CNoisePattern *dlg1=new CNoisePattern();
	dlg1->Create (IDD_NOISE_PATTERN,&m_rollup);
	ItemDATA* item=new ItemDATA(I_NORMAL_MAP);
	item->data["CNoisePattern"]=dlg1;
	
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}
void CTexMakerDlg::OnBumpMap()
{
	HTREEITEM h=this->m_tree .InsertItem ("bump map",hCurItem);
	CBitmapModifier *dlg=new CBitmapModifier();
	dlg->Create (IDD_BITMAP_MODIFIER,&m_rollup);
	ItemDATA* item=new ItemDATA(I_BUMP_MAP);
	item->data["CBitmapModifier"]=dlg;
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}
void CTexMakerDlg::OnNOrmalMapEntry()
{
	CMapEntry *dlg=new CMapEntry();
	//dlg->DoModal ();
	CString s;s.Format ("%f",dlg->m_pos);
	HTREEITEM h=this->m_tree .InsertItem ("NORMAL entry at "+s,hCurItem);
	dlg->Create (IDD_MAP_ENTRY,&m_rollup);
	ItemDATA* item=new ItemDATA(I_NORMAL_MAP_VAL);
	item->data["CMapEntry"]=dlg;
	
	CTransformation *dlg1=new CTransformation();
	dlg1->Create (IDD_TRANSFORMATION,&m_rollup);
	item->data["CTransformation"]=dlg1;
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);	
	
}

void CTexMakerDlg::OnBpPigment() 
{
	OnPigment();
}

void CTexMakerDlg::OnSysDelete()
{
	this->m_tree .DeleteItem (hCurItem);
	
}

void CTexMakerDlg::OnBpnNormal()
{
	OnNormal();
}

void CTexMakerDlg::OnNormal()
{
	HTREEITEM h=this->m_tree .InsertItem ("NORMAL",hCurItem);
	CTransformation *dlg=new CTransformation();
	dlg->Create (IDD_TRANSFORMATION,&m_rollup);
	ItemDATA* item=new ItemDATA(I_TEX_NORMAL);
	item->data["CTransformation"]=dlg;
	
	CNoiseModifier *dlg3=new CNoiseModifier();
	dlg3->Create (IDD_NOISE_MODIFIER,&m_rollup);
	item->data["CNoiseModifier"]=dlg3;
	
	CWarpDlg *dlg5=new CWarpDlg();
	dlg5->Create (IDD_WARP,&m_rollup);
	item->data["CWarpDlg"]=dlg5;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}

void CTexMakerDlg::OnTvnSelchangedTree1(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	// TODO: Add your control notification handler code here
	CMapStringToOb& hashtable =((ItemDATA*)pNMTreeView->itemNew.lParam)->data;
	m_rollup.RemoveAllPages ();
	POSITION pos=hashtable.GetStartPosition ();
	while (pos!=NULL)
	{
		CObject *dlg;CString key;
		hashtable.GetNextAssoc (pos,key,dlg);
		m_rollup.InsertPage (key,(CDialog*)dlg,false);
	}
	*pResult = 0;
}

void CTexMakerDlg::OnInterior()
{
	HTREEITEM h=this->m_tree .InsertItem ("Interior",hCurItem);
	ItemDATA* item=new ItemDATA(I_INTERIOR);
	CInteriorDlg *dlg=new CInteriorDlg();
	dlg->Create (IDD_INTERIOR,&m_rollup);
	item->data["CInteriorDlg"]=dlg;
	
	/*	CMediaDlg *dlg=new CMediaDlg();
	dlg->Create (IDD_MEDIA,&m_rollup);
	item->data["CMediaDlg"]=dlg;
	*/
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
	
}

void CTexMakerDlg::OnMedia()
{
	HTREEITEM h=this->m_tree .InsertItem ("Media",hCurItem);
	ItemDATA* item=new ItemDATA(I_MEDIA);
	CMediaDlg *dlg=new CMediaDlg();
	dlg->Create (IDD_MEDIA,&m_rollup);
	item->data["CMediaDlg"]=dlg;
	
	CSelectColor* ecdlg=new CSelectColor();
	ecdlg->m_usegradient=false;
	
	ecdlg->Create (IDD_COLORRANGE,&m_rollup);
	item->data["Emmision Color"]=ecdlg;
	
	CSelectColor* acdlg=new CSelectColor();
	acdlg->m_usegradient=false;
	
	acdlg->Create (IDD_COLORRANGE,&m_rollup);
	item->data["Absorbtion Color"]=acdlg;
	
	CSelectColor* scdlg=new CSelectColor();
	scdlg->m_usegradient=false;
	
	scdlg->Create (IDD_COLORRANGE,&m_rollup);
	item->data["Scattering Color"]=scdlg;
	
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}

void CTexMakerDlg::OnDenisty()
{
	HTREEITEM h=this->m_tree .InsertItem ("Denisty",hCurItem);
	ItemDATA* item=new ItemDATA(I_INTERIOR_DENISTY);
	
	CTransformation *dlg1=new CTransformation();
	dlg1->Create (IDD_TRANSFORMATION,&m_rollup);
	item->data["CTransformation"]=dlg1;
	
	CNoiseModifier *dlg2=new CNoiseModifier();
	dlg2->Create (IDD_NOISE_MODIFIER,&m_rollup);
	item->data["CNoiseModifier"]=dlg2;
	
	CWarpDlg *dlg3=new CWarpDlg();
	dlg3->Create (IDD_WARP,&m_rollup);
	item->data["CWarpDlg"]=dlg3;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
	
}

void CTexMakerDlg::OnAddtodensityDensitypattern()
{
	HTREEITEM h=this->m_tree .InsertItem ("Denisty Pattern",hCurItem);
	ItemDATA* item=new ItemDATA(I_DENISTY_PAT);
	
	CNoisePattern *dlg1=new CNoisePattern();
	dlg1->Create (IDD_NOISE_PATTERN,&m_rollup);
	item->data["CNoisePattern"]=dlg1;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
	
}

void CTexMakerDlg::OnAddtodensityBlockpatternwithdensities()
{
	HTREEITEM h=this->m_tree .InsertItem ("Bp with denisty",hCurItem);
	ItemDATA* item=new ItemDATA(I_BP_WITH_DENISTY);
	
	CBlockPattern *dlg=new CBlockPattern();
	dlg->Create (IDD_BLOCK_PATTERN,&m_rollup);
	item->data["CBlockPattern"]=dlg;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}

void CTexMakerDlg::OnAddtodensityDensitymappattern()
{
	HTREEITEM h=this->m_tree .InsertItem ("Denisty Map",hCurItem);
	ItemDATA* item=new ItemDATA(I_DENISTY_MAP);
	
	CNoisePattern *dlg1=new CNoisePattern();
	dlg1->Create (IDD_NOISE_PATTERN,&m_rollup);
	item->data["CNoisePattern"]=dlg1;
	
	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
}

void CTexMakerDlg::OnSceneSettings() 
{

	
}

void CTexMakerDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	

}


void CTexMakerDlg::OnSysChangename() 
{
	// TODO: Add your command handler code here
	ItemDATA* id=(ItemDATA*)this->m_tree .GetItemData (	hCurItem);
	CNodeName dlg;
	dlg.m_name =	id->Name ;
	if(dlg.DoModal ()==IDOK)
	{
		if(!NameExistinTree(dlg.m_name ))
		{
			id->Name =dlg.m_name ;
		}
	}
	
}

bool CTexMakerDlg::NameExistinTree(CString Name)
{

	HTREEITEM h= m_tree.GetRootItem ();
	while (h)
	{
		if(h)
		{
			if(Name==m_tree.GetItemText (h))
			{
				return true;
			}
		}
		h=m_tree.GetNextSiblingItem (h);
	}
	return false;
}


void CTexMakerDlg::OnRender() 
{

}


void CTexMakerDlg::OnAddmaterial() 
{
	CCreateMaterial dlg;
	if(dlg.DoModal ()==IDOK)	
	{
		switch(dlg.m_mat_type )
		{
		case 0:
			if (!NameExistinTree(dlg.m_name ))
			{
				HTREEITEM root=m_tree.InsertItem ( dlg.m_name );
				ItemDATA* item=new ItemDATA(I_MATERIAL);
				item->Name =dlg.m_name ;
				m_tree.SetItemData (root,(DWORD)item);
				m_tree.SelectItem (root);
			}
			else
				AfxMessageBox ("This Material Name is Already Exist");
			break;
		case 1:
			if (!NameExistinTree(dlg.m_name ))
			{
				HTREEITEM h=this->m_tree .InsertItem ("Rainbow");
				ItemDATA* item=new ItemDATA(I_RAINBOW_MATERIAL);
				item->Name =dlg.m_name ;
				CSelectColor *dlg=new CSelectColor();
				dlg->m_usegradient=false;
				dlg->Create (IDD_COLORRANGE,&m_rollup);
				item->data["CSelectColor"]=dlg;
				
				m_tree.SetItemData (h,(DWORD)item);
				m_tree.Expand (hCurItem,TVE_EXPAND);
				
			}
			else
				AfxMessageBox ("This Material Name is Already Exist");
			break;
		case 2:
			if (!NameExistinTree(dlg.m_name ))
			{
				HTREEITEM h=this->m_tree .InsertItem ("Sky Sphere");
				ItemDATA* item=new ItemDATA(I_SKY_SPHERE);
				item->Name =dlg.m_name ;
				CTransformation *dlg1=new CTransformation();
				dlg1->Create (IDD_TRANSFORMATION,&m_rollup);
				item->data["CTransformation"]=dlg1;
				m_tree.SetItemData (h,(DWORD)item);
				m_tree.Expand (hCurItem,TVE_EXPAND);
			}
			else
				AfxMessageBox ("This Material Name is Already Exist");
			break;
		}
	}
}




void CTexMakerDlg::OnAddtorainbowmatRainbow() 
{
	HTREEITEM h=this->m_tree .InsertItem ("rainbow",hCurItem);
	ItemDATA* item=new ItemDATA(I_RAINBOW);

	CSelectColor *dlg=new CSelectColor();
	dlg->Create (IDD_COLORRANGE,&m_rollup);
	item->data["CSelectColor"]=dlg;

	CRainbowOptions* dlg1=new CRainbowOptions();
	dlg1->Create (IDD_RAINBOW_OPTIONS,&m_rollup);
	item->data["CRainbowOptions"]=dlg1;


	m_tree.SetItemData (h,(DWORD)item);
	m_tree.Expand (hCurItem,TVE_EXPAND);
	
}
#include "matrices.h"
void TexDescScene(IRayEngine* Eng)
{
	CTexMakerDlg * dlg=(CTexMakerDlg *)Eng->m_Data;
	/**********************************************************************/
	Frame.Camera=new CAMERA();
	Frame.Number_Of_Light_Sources = 0;  
	Frame.Light_Sources = NULL;
	Frame.Light_Group_Lights = NULL;
	Frame.Objects = NULL;
	Frame.Atmosphere_IOR = 1.0;
	Frame.Atmosphere_Dispersion = 1.0;
	Frame.Antialias_Threshold = opts.Antialias_Threshold;

	Make_Colour (Frame.Background_Colour,0,0,0);

	/* dmf -- the first is physically "more correct".  The second works better */
	/*   Make_Colour (Frame.Irid_Wavelengths, 0.70, 0.52, 0.48); */
	/*	Make_Colour (Frame.Irid_Wavelengths, 0.25, 0.18, 0.14);
	Make_Colour (Frame.Background_Colour, 0.0, 0.0, 0.0);
	Make_Colour (Frame.Ambient_Light, 1.0, 1.0, 1.0);
	*/	
	/* Init atmospheric stuff. [DB 12/94] */
	//CPhotonixDoc::InitAtmosphericEffects();
	/*
	Frame.Atmosphere = NULL;

	Frame.Fog = NULL;
	*/  
	Frame.Rainbow = NULL;
	Frame.Skysphere = NULL;

	SKYSPHERE* s=(SKYSPHERE*)TreeParser.SkySpheres [dlg->m_curskysphere];
	if(s)
		Frame.Skysphere = s->GetCopy ();
	RAINBOW* r=(RAINBOW*)TreeParser.Rainbows [dlg->m_curskysphere];
	if(r)
		Frame.Rainbow= r->GetCopy ();
	/*********************************************************************/

	/////////////////////////////////////////
	//global settings

	//	opts.GammaFactor = 1/opts.DisplayGamma;
	//	opts.Options |= GAMMA_CORRECT; // turn on gamma correction 
	//	Max_Trace_Level = 5;
	//	Had_Max_Trace_Level = true;
	photonOptions.surfaceSeparation = 0.02;

	// max_gather_count = 0  means no photon maps 
	if (photonOptions.maxGatherCount > 0)
		photonOptions.photonsEnabled = true;
	else
		photonOptions.photonsEnabled = false;

	if(photonOptions.photonsEnabled)
	{
		// check for range errors 
		if (photonOptions.minGatherCount < 0)
			Error("min_gather_count cannot be negative.");
		if (photonOptions.maxGatherCount < 0)
			Error("max_gather_count cannot be negative.");
		if (photonOptions.minGatherCount > photonOptions.maxGatherCount)
			Error("min_gather_count must be less than max_gather_count.");
	}


	if((photonOptions.photonsEnabled == false) && (opts.Quality < 9))
	{
		photonOptions.photonsEnabled = false;
		Warning(0, "A photons{}-block has been found but photons remain disabled because\n"
			"the output quality is set to 8 or less.");
	}

	///////////////////////////////////
	DBL k1, k2, k3;
	DBL Direction_Length = 1.0, Up_Length, Right_Length, Handedness;
	VECTOR tempv;
	//	TRANSFORM Local_Trans;
	//	CAMERA *New;
	//	bool only_mods = false;
	/////////////////////////////////////////
	//#defing New
	double camlocation[3],camdlook[3];
	
	if(!dlg->SceneEnviromental )
	{
	
	Make_Vector( camlocation,0,-2,2);
	//	double camdir[3]={0,0,1.6542};

	Make_Vector(camdlook,0,-.1,0);
	//Compute_Translation_Transform
	//	double up[3]={0,0,1};
	}
	else
	{
	Make_Vector( camlocation,0,-10,2);
	Make_Vector(camdlook,0,0,0);
	}

	//setting properties
	//	Frame.Camera=Create_Camera();
	Frame.Camera->Type=PERSPECTIVE_CAMERA;
	Frame.Camera->Angle=50;
	VNormalize(Frame.Camera->Direction, Frame.Camera->Direction);
	VLength (Right_Length, Frame.Camera->Right);
	Direction_Length = Right_Length / tan(Frame.Camera->Angle * M_PI_360)/2.0;
	VScaleEq(Frame.Camera->Direction, Direction_Length);
	///	Assign_Vector(Frame.Camera->Direction,camdir);
	Assign_Vector(Frame.Camera->Location,camlocation);
	//	Assign_Vector(Frame.Camera->Up,up);
	//	Assign_Vector(Frame.Camera->Sky ,up);


	///setting up look at
	VLength (Direction_Length, Frame.Camera->Direction);
	VLength (Up_Length,        Frame.Camera->Up);
	VLength (Right_Length,     Frame.Camera->Right);
	VCross  (tempv,            Frame.Camera->Up, Frame.Camera->Direction);
	VDot    (Handedness,       tempv,   Frame.Camera->Right);

	//	Parse_Vector (Frame.Camera->Direction);
	Assign_Vector(Frame.Camera->Direction,camdlook);

	Assign_Vector(Frame.Camera->Look_At, Frame.Camera->Direction);

	VSub          (Frame.Camera->Direction, Frame.Camera->Direction, Frame.Camera->Location);

	// Check for zero length direction vector.
	if (VSumSqr(Frame.Camera->Direction) < EPSILON)
		Error("Camera location and look_at point must be different.");

	VNormalize (Frame.Camera->Direction, Frame.Camera->Direction);

	// Save Right vector
	Assign_Vector (tempv, Frame.Camera->Right);

	VCross        (Frame.Camera->Right, Frame.Camera->Sky, Frame.Camera->Direction);

	// Avoid DOMAIN error (from Terry Kanakis)
	if((fabs(Frame.Camera->Right[X]) < EPSILON) &&
		(fabs(Frame.Camera->Right[Y]) < EPSILON) &&
		(fabs(Frame.Camera->Right[Z]) < EPSILON))
	{
		// Restore Right vector
		Assign_Vector (Frame.Camera->Right, tempv);
	}

	VNormalize (Frame.Camera->Right,     Frame.Camera->Right);
	VCross     (Frame.Camera->Up,        Frame.Camera->Direction, Frame.Camera->Right);
	VScale     (Frame.Camera->Direction, Frame.Camera->Direction, Direction_Length);

	if (Handedness > 0.0)
		VScaleEq (Frame.Camera->Right, Right_Length)
	else
	VScaleEq (Frame.Camera->Right, -Right_Length);

	VScaleEq(Frame.Camera->Up, Up_Length);
	////post
	// Make sure the focal distance hasn't been explicitly given
	if (Frame.Camera->Focal_Distance < 0.0)
		Frame.Camera->Focal_Distance = Direction_Length;
	if (Frame.Camera->Focal_Distance == 0.0)
		Frame.Camera->Focal_Distance = 1.0;

	// Print a warning message if vectors are not perpendicular. [DB 10/94]
	VDot(k1, Frame.Camera->Right, Frame.Camera->Up);
	VDot(k2, Frame.Camera->Right, Frame.Camera->Direction);
	VDot(k3, Frame.Camera->Up, Frame.Camera->Direction);

	if ((fabs(k1) > EPSILON) || (fabs(k2) > EPSILON) || (fabs(k3) > EPSILON))
	{
		Warning(0, "Camera vectors are not perpendicular.\n"
			"Making look_at the last statement may help.");
	}
	////////////////////////////////////////////
	//first light ;
	double light1center[3]={5.820, -8.500, 6.316};
	float light1color[5]={1,1,1,0,0};
	DBL Len1;
	//desc lights
	LIGHT_SOURCE *lsource1;
	lsource1 = new LIGHT_SOURCE;//Create_Light_Source ();
	Assign_Vector(lsource1->Center,light1center);
	Assign_Colour(lsource1->Colour,light1color);

	//Object->Fade_Distance=20;
	//Object-> Fade_Power=2;				

	VSub(lsource1->Direction, lsource1->Points_At, lsource1->Center);

	VLength(Len1, lsource1->Direction);

	if (Len1 > EPSILON)
	{
		VInverseScaleEq(lsource1->Direction, Len1);
	}

	// Make sure that circular light sources are larger than 1 by x [ENB 9/97] 
	if (lsource1->Circular)
	{
		if ((lsource1->Area_Size1 <= 1) || (lsource1->Area_Size2 <= 1))
		{
			Error("Circular area light must have more than 1 point per axis");
		}
	}

	Post_Process (lsource1, NULL);
	Link_To_Frame (lsource1);
	////////////////////////////////////////////
	//second light ;
	double light2center[3]={5.820, -1.500, 3};
	float light2color[5]={0.400, 0.400, 0.400,0,0};
	DBL Len2;
	//desc lights
	LIGHT_SOURCE *lsource2;
	lsource2 = new LIGHT_SOURCE;//Create_Light_Source ();
	Assign_Vector(lsource2->Center,light2center);
	Assign_Colour(lsource2->Colour,light2color);

	//Object->Fade_Distance=20;
	//Object-> Fade_Power=2;				

	VSub(lsource2->Direction, lsource2->Points_At, lsource2->Center);

	VLength(Len2, lsource2->Direction);

	if (Len2 > EPSILON)
	{
		VInverseScaleEq(lsource2->Direction, Len2);
	}

	// Make sure that circular light sources are larger than 1 by x [ENB 9/97] 
	if (lsource2->Circular)
	{
		if ((lsource2->Area_Size1 <= 1) || (lsource2->Area_Size2 <= 1))
		{
			Error("Circular area light must have more than 1 point per axis");
		}
	}

	Post_Process (lsource2, NULL);
	Link_To_Frame (lsource2);
	////////////////////////////////////////////
	//plane vectors
	/*	double planevector[3]={0, 1, 0};
	float color[5]={1,1,1,0,0};
	DBL len;
	//desc objects
	PLANE *Object1;
	Object1 = new PLANE;//Create_Plane();
	Assign_Vector(Object1->Normal_Vector,planevector);

	VLength(len, Object1->Normal_Vector);
	if (len < EPSILON)
	{
	Error("Degenerate plane normal.");
	}
	VInverseScaleEq(Object1->Normal_Vector, len);
	Object1->Distance =1.5;

	Compute_Plane_BBox(Object1);
	Object1->Type |= TEXTURED_OBJECT;
	// define a new texture;
	TEXTURE *tex1 =new TEXTURE();//Create_Texture();

	tex1->Pigment = new PIGMENT();//Create_Pigment();
	tex1->Tnormal = new TNORMAL();
	tex1->Finish  = new FINISH ();//Create_Finish();
	//tex1->Pigment->Type = PLAIN_PATTERN;
	//Assign_Colour(tex1->Pigment->Colour,color);

	tex1->Pigment->Type = CHECKER_PATTERN;
	tex1->Pigment->Frequency = 0.0;
	Destroy_Blend_Map(tex1->Pigment->Blend_Map);
	///parsing blend list

	float Colour1[5]={1,1,1,0,0};
	float Colour2[5]={.2,.2,.2,0,0};
	BLEND_MAP *New;
	BLEND_MAP_ENTRY *Temp_Ent;

	Temp_Ent = Create_BMap_Entries(2);
	//Temp_Ent[0].Vals.Pigment=new PIGMENT();
	//Assign_Colour(Temp_Ent[0].Vals.Pigment->Colour,Colour1);
	Assign_Colour(Temp_Ent[0].Vals.Colour,Colour1);
	Temp_Ent[0].value = (SNGL)0;

	//Temp_Ent[1].Vals.Pigment=new PIGMENT();
	//Assign_Colour(Temp_Ent[1].Vals.Pigment->Colour,Colour2);
	Assign_Colour(Temp_Ent[1].Vals.Colour,Colour2);

	Temp_Ent[1].value = (SNGL)1;

	New = Create_Blend_Map ();
	New->Number_Of_Entries = 2;
	New->Type=COLOUR_TYPE;
	// New->Transparency_Flag=true; //Temp fix.  Really set in Post_???
	New->Blend_Map_Entries = Temp_Ent;
	tex1->Pigment->Blend_Map=New;


	///////////CHECKER
	tex1->Tnormal->Type = CHECKER_PATTERN;
	tex1->Tnormal->Frequency = 0.0;	
	Destroy_Blend_Map(tex1->Tnormal->Blend_Map);		

	Link_Textures(&(Object1->Texture), tex1);

	Post_Process (Object1, NULL);//used next object
	Link_To_Frame (Object1);
	*/
	//////////////////////////////////////////////


	/*	BOX *Objectt = new BOX;//Create_Box();
	DBL temp;

	//  Parse_Vector(Object->bounds[0]);     Parse_Comma();
	//  Parse_Vector(Object->bounds[1]);
	Make_Vector(Objectt->bounds[0],2,-1,1);
	Make_Vector(Objectt->bounds[1],3,1,-1);
	if (Objectt->bounds[0][X] > Objectt->bounds[1][X]) {
	temp = Objectt->bounds[0][X];
	Objectt->bounds[0][X] = Objectt->bounds[1][X];
	Objectt->bounds[1][X] = temp;
	}
	if (Objectt->bounds[0][Y] > Objectt->bounds[1][Y]) {
	temp = Objectt->bounds[0][Y];
	Objectt->bounds[0][Y] = Objectt->bounds[1][Y];
	Objectt->bounds[1][Y] = temp;
	}
	if (Objectt->bounds[0][Z] > Objectt->bounds[1][Z]) {
	temp = Objectt->bounds[0][Z];
	Objectt->bounds[0][Z] = Objectt->bounds[1][Z];
	Objectt->bounds[1][Z] = temp;
	}

	Objectt->Compute_Box_BBox();

	Objectt->Type |= TEXTURED_OBJECT;
	Objectt->Interior=TreeParser.GetInterior("Material1");
	if(Objectt->Interior)
	{
	Set_Flag(Objectt,HOLLOW_FLAG);
	Set_Flag (Objectt, HOLLOW_SET_FLAG);
	}
	Link_Textures(&(Objectt->Texture),TreeParser.GetTexture ("Material1"));
	Post_Process (Objectt, NULL);//used next object
	Link_To_Frame (Objectt);
	*/

	double center[3]={0,0,0};
	//	float color1[5]={.75,.75,.75,0,0};
	SPHERE*Object4;
	Object4=new SPHERE();//Create_Sphere();
	Assign_Vector(Object4->Center,center);
	Object4->Radius=.5;

	Compute_Sphere_BBox(Object4);  

	Object4->Type |= TEXTURED_OBJECT;
	// define a new texture;
	/*
	TEXTURE *tex4 =new TEXTURE();

	tex4->Pigment = new PIGMENT();
	tex4->Tnormal = NULL;
	tex4->Finish  = new FINISH ();*/
	//tex4->Pigment->Type = PLAIN_PATTERN;
	//Assign_Colour(tex4->Pigment->Colour,color);
	/*
	tex4->Pigment->Type = MANDEL_PATTERN;
	tex4->Pigment->Vals.Fractal.Iterations = 50;
	tex4->Pigment->Vals.Fractal.interior_type = 1;
	tex4->Pigment->Vals.Fractal.exterior_type = 5;
	tex4->Pigment->Vals.Fractal.efactor = .01;
	tex4->Pigment->Vals.Fractal.ifactor = .5;
	tex4->Pigment->Vals.Fractal.Exponent = 4;*/
	/*
	Make_UV_Vector(tex4->Pigment->Vals.Fractal.Coord,.3,.44);
	tex4->Pigment->Type = JULIA_PATTERN;
	tex4->Pigment->Vals.Fractal.Iterations = 30;
	tex4->Pigment->Vals.Fractal.interior_type = DEFAULT_FRACTAL_INTERIOR_TYPE;
	tex4->Pigment->Vals.Fractal.exterior_type = DEFAULT_FRACTAL_EXTERIOR_TYPE;
	tex4->Pigment->Vals.Fractal.efactor = DEFAULT_FRACTAL_EXTERIOR_FACTOR;
	tex4->Pigment->Vals.Fractal.ifactor = DEFAULT_FRACTAL_INTERIOR_FACTOR;
	tex4->Pigment->Vals.Fractal.Exponent = 4;
	tex4->Finish->Specular=1;
	Make_RGB(tex4->Finish->Ambient,.1,.1,.1);
	tex4->Finish->Diffuse =1.1;
	*/
	Object4->Interior=TreeParser.GetInterior(dlg->m_CurrentMaterialName );
	if(Object4->Interior)
	{
		Set_Flag(Object4,HOLLOW_FLAG);
		Set_Flag (Object4, HOLLOW_SET_FLAG);
	}
	Link_Textures(&(Object4->Texture),TreeParser.GetTexture (dlg->m_CurrentMaterialName ));
	Post_Process (Object4, NULL);//used next object
	Link_To_Frame (Object4);

	
	//aiz- add 27 feb
	//making the Floor
	{
		DISC *disc=new DISC();
		VECTOR disccenter,discnormal;
		Make_Vector(disccenter,0,0,-1);
		Make_Vector(discnormal,0,0,1);
		Assign_Vector(disc->center,disccenter);
		Assign_Vector(disc->normal,discnormal);
		VNormalize(disc->normal, disc->normal);
		disc->oradius2=25;
		DBL tmpf;
		VDot(tmpf, disc->center, disc->normal);
		disc->d = -tmpf;
		Compute_Disc(disc);  

		disc->Type |= TEXTURED_OBJECT;
		/*to be used for the hollow key word
		{
		Bool_Flag (Object, HOLLOW_FLAG, (Allow_Float(1.0) > 0.0));
		Set_Flag (Object, HOLLOW_SET_FLAG);
		if ((Object->Methods == &CSG_Intersection_Methods) ||
		(Object->Methods == &CSG_Merge_Methods) ||
		(Object->Methods == &CSG_Union_Methods))
		{
		Set_CSG_Children_Flag(Object, Test_Flag(Object, HOLLOW_FLAG), HOLLOW_FLAG, HOLLOW_SET_FLAG);
		}
		}
		*/
		//making the texture of the floor
		// define a new texture;
		TEXTURE *texfloor =new TEXTURE();//Create_Texture();

		texfloor->Pigment = new PIGMENT();//Create_Pigment();
		texfloor->Tnormal = NULL;//new TNORMAL();
		texfloor->Finish  = new FINISH ();//Create_Finish();
		//tex1->Pigment->Type = PLAIN_PATTERN;
		//Assign_Colour(tex1->Pigment->Colour,color);

		texfloor->Pigment->Type = CHECKER_PATTERN;
		texfloor->Pigment->Frequency = 0.0;
		Destroy_Blend_Map(texfloor->Pigment->Blend_Map);
		///parsing blend list

		float Colour1[5]={1,1,1,0,0};
		float Colour2[5]={.2,.2,.2,0,0};
		BLEND_MAP *New;
		BLEND_MAP_ENTRY *Temp_Ent;

		Temp_Ent = Create_BMap_Entries(2);
		//Temp_Ent[0].Vals.Pigment=new PIGMENT();
		//Assign_Colour(Temp_Ent[0].Vals.Pigment->Colour,Colour1);
		Assign_Colour(Temp_Ent[0].Vals.Colour,Colour1);
		Temp_Ent[0].value = (SNGL)0;

		//Temp_Ent[1].Vals.Pigment=new PIGMENT();
		//Assign_Colour(Temp_Ent[1].Vals.Pigment->Colour,Colour2);
		Assign_Colour(Temp_Ent[1].Vals.Colour,Colour2);

		Temp_Ent[1].value = (SNGL)1;

		New = Create_Blend_Map ();
		New->Number_Of_Entries = 2;
		New->Type=COLOUR_TYPE;
		// New->Transparency_Flag=true; //Temp fix.  Really set in Post_???
		New->Blend_Map_Entries = Temp_Ent;
		texfloor->Pigment->Blend_Map=New;

		Make_Vector(texfloor->Finish ->Ambient ,0.25,0.25,0.25);
		texfloor->Finish ->Diffuse =0.80;
		///////////CHECKER
		/*
		texfloor->Tnormal->Type = CHECKER_PATTERN;
		texfloor->Tnormal->Frequency = 0.0;	
		Destroy_Blend_Map(texfloor->Tnormal->Blend_Map);		
		*/
		//scale the pig with.45
		VECTOR Vector;
		TRANSFORM Trans;
		Make_Vector(Vector,0.45,0.45,0.45);
		Compute_Scaling_Transform (&Trans, Vector);
		Transform_Tpattern (texfloor->Pigment, &Trans);

		Link_Textures(&(disc->Texture), texfloor);
		Post_Process (disc, NULL);//used next object
		Link_To_Frame (disc);
	}
	
	//////////////////////////////////////////////////
	if(!dlg->SceneEnviromental )
	{
	//make the back ground
	{
		DISC *disc2=new DISC();
		VECTOR disc2center,disc2normal;
		Make_Vector(disc2center,0,2.5,0);
		Make_Vector(disc2normal,0,1,0);
		Assign_Vector(disc2->center,disc2center);
		Assign_Vector(disc2->normal,disc2normal);
		VNormalize(disc2->normal, disc2->normal);
		disc2->oradius2=25;
		DBL tmpf;
		VDot(tmpf, disc2->center, disc2->normal);
		disc2->d = -tmpf;
		Compute_Disc(disc2);  

		disc2->Type |= TEXTURED_OBJECT;
		//making the texture of the floor
		// define a new texture;

		TEXTURE *texback =new TEXTURE();//Create_Texture();

		texback->Pigment = new PIGMENT();//Create_Pigment();
		texback->Tnormal = NULL;//new TNORMAL();
		texback->Finish  = new FINISH ();//Create_Finish();
		//tex1->Pigment->Type = PLAIN_PATTERN;
		//Assign_Colour(tex1->Pigment->Colour,color);

		texback->Pigment->Type = CHECKER_PATTERN;
		texback->Pigment->Frequency = 0.0;
		Destroy_Blend_Map(texback->Pigment->Blend_Map);
		///parsing blend list

		float Colour1[5]={1,1,1,0,0};
		float Colour2[5]={.2,.2,.2,0,0};
		BLEND_MAP *New;
		BLEND_MAP_ENTRY *Temp_Ent;

		Temp_Ent = Create_BMap_Entries(2);
		//Temp_Ent[0].Vals.Pigment=new PIGMENT();
		//Assign_Colour(Temp_Ent[0].Vals.Pigment->Colour,Colour1);
		Assign_Colour(Temp_Ent[0].Vals.Colour,Colour1);
		Temp_Ent[0].value = (SNGL)0;

		//Temp_Ent[1].Vals.Pigment=new PIGMENT();
		//Assign_Colour(Temp_Ent[1].Vals.Pigment->Colour,Colour2);
		Assign_Colour(Temp_Ent[1].Vals.Colour,Colour2);

		Temp_Ent[1].value = (SNGL)1;

		New = Create_Blend_Map ();
		New->Number_Of_Entries = 2;
		New->Type=COLOUR_TYPE;
		// New->Transparency_Flag=true; //Temp fix.  Really set in Post_???
		New->Blend_Map_Entries = Temp_Ent;
		texback->Pigment->Blend_Map=New;

		Make_Vector(texback->Finish ->Ambient ,0.25,0.25,0.25);
		texback->Finish ->Diffuse =0.80;
		///////////CHECKER
		/*	texback->Tnormal->Type = CHECKER_PATTERN;
		texback->Tnormal->Frequency = 0.0;	
		Destroy_Blend_Map(texback->Tnormal->Blend_Map);		
		*/
		//scale the pig with.45
		TRANSFORM Trans;
		VECTOR Vector;
		Make_Vector(Vector,1000, 0.2, 0.2);
		Compute_Scaling_Transform (&Trans, Vector);
		Transform_Tpattern (texback->Pigment, &Trans);
		//translate
		Make_Vector(Vector,500,0,0);
		Compute_Translation_Transform (&Trans, Vector);
		Transform_Tpattern (texback->Pigment, &Trans);


		Link_Textures(&(disc2->Texture), texback);

		Post_Process (disc2, NULL);//used next object
		Link_To_Frame (disc2);
	}
	}
}
void TexSetRenderSettings(IRayEngine*Eng)
{
//	CRenderScene &rs=CPhotonixDoc::renderscene;
//	if(rs.m_antialiasing )
	CTexMakerDlg * dlg=(CTexMakerDlg *)Eng->m_Data;
	if(dlg->m_antialias)
		opts.Options |= ANTIALIAS;
/*	opts.Tracing_Method=rs.m_sampling_method ;
	opts.Antialias_Threshold=rs.m_threshold ;
	opts.AntialiasDepth=rs.m_depth ;
	opts.Quality=9;
*///	CPhotonixDlg::RenderDlg.m_Window.SetPictureRect(CRect (0,0,rs.m_width ,rs.m_height ));
	CRect rect=CTexMakerDlg::m_Window.GetPictureRect();
	Frame.Screen_Width  = rect.Width ();
	Frame.Screen_Height = rect.Height ();


/*	if(rs.m_jitter )
		opts.Options |= JITTER;
	opts.JitterScale=rs.m_jitter ;
	
	if(rs.m_mosaic )
	{
		opts.PreviewGridSize_Start=rs.m_start ;
		opts.PreviewGridSize_End=rs.m_stop ;
	}*/
}
int PreviewFinished(IRayEngine*Eng)
{
CTexMakerDlg* dlg=(CTexMakerDlg*)Eng->m_Data;
dlg->StopRendering();
return 0;
}
UINT CTexMakerDlg::Render(LPVOID p)
{
	CTexMakerDlg* dlg=(CTexMakerDlg*)p;
//	dc=dlg->GetDC ();
//	CBitmap *b=new CBitmap();
//	b->CreateCompatibleBitmap(dc,300,300);
//	dc->SelectObject (b);
	RayEngine=new IRayEngine();
	RayEngine->DescScene =&TexDescScene;
	RayEngine->Display_Plot= &TexDisplay_Plot;
	RayEngine->ExitThread =&PreviewFinished;
	RayEngine->ThreadFinished=&PreviewFinished;
	RayEngine->SetRenderSettings =&TexSetRenderSettings;
	RayEngine->m_Data =dlg;
	RayEngine->StartRendering ();
//	povray_init();
	
	/*int argc=5;
	char a1[10]="a.pov",b1[10]="+w320",c1[10]="+h320";
	char a2[10]="raytest1",b2[60]="C:\\toot\\RayTest1\\debug\\raytest1.exe";
	char **argv=new char*[5];
	
	  argv[0]=&b2[0];
	  argv[1]=&(a2[0]);
	  argv[2]=&a1[0];
	  argv[3]=&b1[0];
	  argv[4]=&c1[0];
	*/
	
//	povray_render();//argc, argv

	//delete argv;
	// Finish 
//	povray_terminate();
	
//	delete b;
	//	Destroy_Textures( Default_Texture);
	//	delete texglobal;
	//	texglobal=NULL;
	//Default_Texture=NULL;
	delete RayEngine;
	return 0;
}

void CTexMakerDlg::OnStopPreview()
{
	Stop_Flag=true;	
}

void CTexMakerDlg::UpdateRollUpCtrl(void)
{
	//updating the last values in the rollup ctrl
	{
		HTREEITEM h=m_tree.GetSelectedItem ();
		if(h)
		{
			CMapStringToOb& hashtable =((ItemDATA*)m_tree.GetItemData (h))->data;
			POSITION pos=hashtable.GetStartPosition ();
			while (pos!=NULL)
			{
				CObject *dlg;CString key;
				hashtable.GetNextAssoc (pos,key,dlg);
				//m_rollup.GetPageInfo (i)InsertPage (key,(CDialog*)dlg,false);
				((CDialog*)dlg)->UpdateData ();
			}
		}
	}
}

void CTexMakerDlg::OnBrowseRainbows() 
{
	// TODO: Add your control notification handler code here
	CMaterialsDlg dlg;
	dlg.m_Searchtype=I_RAINBOW_MATERIAL;
	if(dlg.DoModal ()==IDOK)
	{
this->m_currainbow=dlg.m_MaterialName;
UpdateData (false);
	}
}

void CTexMakerDlg::OnBrowseSkysphere() 
{
	// TODO: Add your control notification handler code here
	
	CMaterialsDlg dlg;
	dlg.m_Searchtype=I_SKY_SPHERE;
	if(dlg.DoModal ()==IDOK)
	{
		m_curskysphere=dlg.m_MaterialName;
		UpdateData (false);
	}
}

void CTexMakerDlg::OnSceneMaterial()
{
	// TODO: Add your control notification handler code here
	CComboBox * combo=(CComboBox *)this->GetDlgItem (IDC_OBJECTS_COMBO);
	combo->EnableWindow ();
	SceneEnviromental=0;
}

void CTexMakerDlg::OnSceneEnviromental()
{
	// TODO: Add your control notification handler code here
	CComboBox * combo=(CComboBox *)this->GetDlgItem (IDC_OBJECTS_COMBO);
	combo->EnableWindow (false);
SceneEnviromental=1;
}

// enables the render button
void CTexMakerDlg::StopRendering(void)
{
	(this->GetDlgItem (ID_STOPPREVIEW))->EnableWindow (false);
	(this->GetDlgItem (IDC_PREVIEW))->EnableWindow (true);
}

void CTexMakerDlg::OnRemoveAll()
{
m_tree .DeleteAllItems ();
}
