// MediaDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "MediaDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMediaDlg dialog

IMPLEMENT_SERIAL(CMediaDlg,CAccessDialog,1)

CMediaDlg::CMediaDlg(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CMediaDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMediaDlg)
	m_intervals = 10;
	m_minsamples = 1;
	m_maxsamples = 1;
	m_confidence = 0.9f;
	m_variance = 0.007f;
	m_ratio = 0.9f;
	m_ecc = 0.0f;
	m_extinction = 1.0f;
	m_is_extiction = FALSE;
	m_is_scattering = FALSE;
	m_type = 0;
	//}}AFX_DATA_INIT
}


void CMediaDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMediaDlg)
	DDX_Text(pDX, IDC_INTERVALS, m_intervals);
	DDV_MinMaxInt(pDX, m_intervals, 1, 1000);
	DDX_Text(pDX, IDC_MINSAMP, m_minsamples);
	DDV_MinMaxInt(pDX, m_minsamples, 1, 1000);
	DDX_Text(pDX, IDC_MAXSAMP, m_maxsamples);
	DDV_MinMaxInt(pDX, m_maxsamples, 1, 1000);
	DDX_Text(pDX, IDC_CONFIDENCE, m_confidence);
	DDV_MinMaxFloat(pDX, m_confidence, 1.e-004f, 1.f);
	DDX_Text(pDX, IDC_VARIANCE, m_variance);
	DDV_MinMaxFloat(pDX, m_variance, 1.e-004f, 1.f);
	DDX_Text(pDX, IDC_RATIO, m_ratio);
	DDV_MinMaxFloat(pDX, m_ratio, 0.f, 1.f);
	DDX_Text(pDX, IDC_ECCENTRICITY, m_ecc);
	DDX_Text(pDX, IDC_EXTINCTION, m_extinction);
	DDV_MinMaxFloat(pDX, m_extinction, 0.f, 5.f);
	DDX_Check(pDX, IDC_IS_EXTINCTION, m_is_extiction);
	DDX_Check(pDX, IDC_IS_SCATTERING, m_is_scattering);
	DDX_CBIndex(pDX, IDC_TYPE, m_type);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMediaDlg, CDialog)
	//{{AFX_MSG_MAP(CMediaDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMediaDlg message handlers

BOOL CMediaDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CComboBox * combo=((CComboBox*)this->GetDlgItem (IDC_TYPE));
combo->AddString ("Isotropic");
combo->AddString ("mie hazy");
combo->AddString ("mie murky");
combo->AddString ("rayleigh");
combo->AddString ("henyey greenstein");

this->UpdateData (false);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
void CMediaDlg::Serialize(CArchive &ar)
{
	if(ar.IsStoring ())
	{

	ar<<m_intervals<<m_minsamples<<m_maxsamples<<m_confidence<<m_variance<<m_ratio<<m_ecc<<m_extinction<<m_is_extiction<<m_is_scattering<<m_type;

	}

	else
	{
	ar>>m_intervals>>m_minsamples>>m_maxsamples>>m_confidence>>m_variance>>m_ratio>>m_ecc>>m_extinction>>m_is_extiction>>m_is_scattering>>m_type;

	}

}