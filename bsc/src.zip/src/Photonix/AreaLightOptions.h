#if !defined(AFX_AREALIGHTOPTIONS_H__3BDACCE4_9484_41D9_A1E2_5E6BDAF1BEA9__INCLUDED_)
#define AFX_AREALIGHTOPTIONS_H__3BDACCE4_9484_41D9_A1E2_5E6BDAF1BEA9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AreaLightOptions.h : header file
//
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CAreaLightOptions dialog
class CAreaLightOptions : public CAccessDialog//CDialog
{
// Construction
public:
	CAreaLightOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAreaLightOptions)
	enum { IDD = IDD_AREALIGHTOPTIONS };
	BOOL	m_enablearea;
	UINT	m_samplesu;
	UINT	m_samplesv;
	float	m_axis1x;
	float	m_axis1y;
	float	m_axis1z;
	float	m_axis2x;
	float	m_axis2y;
	float	m_axis2z;
	//}}AFX_DATA
AreaLightData * m_Obj;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAreaLightOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAreaLightOptions)
	afx_msg void OnKillfocusHeight();
	afx_msg void OnKillfocusSamplesu();
	afx_msg void OnKillfocusSamplesv();
	afx_msg void OnKillfocusWidth();
	afx_msg void OnEnablearea();
	afx_msg void OnKillfocusAxis1x();
	afx_msg void OnKillfocusAxis1y();
	afx_msg void OnKillfocusAxis1z();
	afx_msg void OnKillfocusAxis2x();
	afx_msg void OnKillfocusAxis2y();
	afx_msg void OnKillfocusAxis2z();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AREALIGHTOPTIONS_H__3BDACCE4_9484_41D9_A1E2_5E6BDAF1BEA9__INCLUDED_)
