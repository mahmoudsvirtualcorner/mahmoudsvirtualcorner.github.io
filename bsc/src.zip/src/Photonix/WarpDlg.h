#if !defined(AFX_WARPDLG_H__75128AC4_39C0_4D1E_869D_8B57E98236C1__INCLUDED_)
#define AFX_WARPDLG_H__75128AC4_39C0_4D1E_869D_8B57E98236C1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WarpDlg.h : header file
//
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CWarpDlg dialog

class CWarpDlg : public CAccessDialog//CDialog
{
// Construction
public:
	DECLARE_SERIAL(CWarpDlg)
	CWarpDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CWarpDlg)
	enum { IDD = IDD_WARP };
	float	m_brepeat_x;
	float	m_brepeat_y;
	float	m_brepeat_z;
	float	m_bturbulence_x;
	float	m_bturbulence_y;
	float	m_bturbulence_z;
	float	m_center_x;
	float	m_center_y;
	float	m_center_z;
	float	m_flip_x;
	float	m_flip_y;
	float	m_flip_z;
	float	m_offset_x;
	float	m_offset_y;
	float	m_offset_z;
	float	m_rrepeat_x;
	float	m_rrepeat_y;
	float	m_rrepeat_z;
	float	m_tturbulence_x;
	float	m_tturbulence_y;
	float	m_tturbulence_z;
	float	m_strength;
	int		m_octaves;
	float	m_omega;
	float	m_radius;
	float	m_lambda;
	BOOL	m_is_tw;
	BOOL	m_is_rw;
	BOOL	m_is_inverse;
	BOOL	m_is_bhw;
	float	m_fallof;
	//}}AFX_DATA
virtual void Serialize(CArchive &ar);


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWarpDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CWarpDlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WARPDLG_H__75128AC4_39C0_4D1E_869D_8B57E98236C1__INCLUDED_)
