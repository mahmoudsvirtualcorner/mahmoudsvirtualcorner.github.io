// PhotonixView.cpp : implementation of the CPhotonixView class
//

#include "stdafx.h"
#include "Photonix.h"

#include "PhotonixDoc.h"
#include "PhotonixView.h"
#include "mainfrm.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#include "renderwindow.h"
#include "viewport.h"
#include "sceneselector.h"

/////////////////////////////////////////////////////////////////////////////
// CPhotonixView
int CPhotonixView::ViewPortCounter=0;

IMPLEMENT_DYNCREATE(CPhotonixView, CView)

BEGIN_MESSAGE_MAP(CPhotonixView, CView)
	//{{AFX_MSG_MAP(CPhotonixView)
	// NOTE - the ClassWizard will add and remove mapping macros here.
	//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	ON_WM_SIZE()
	ON_WM_DESTROY()
	ON_WM_ERASEBKGND()
	ON_WM_ACTIVATE()
	ON_WM_SETFOCUS()
	ON_WM_KILLFOCUS()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPhotonixView construction/destruction

CPhotonixView::CPhotonixView()
{
	// TODO: add construction code here
	win=NULL;RenderWnd=0;

	//	s="";
}

CPhotonixView::~CPhotonixView()
{
}

BOOL CPhotonixView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPhotonixView drawing

void CPhotonixView::OnDraw(CDC* pDC)
{
	CPhotonixDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CPhotonixView diagnostics

#ifdef _DEBUG
void CPhotonixView::AssertValid() const
{
	CView::AssertValid();
}

void CPhotonixView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPhotonixDoc* CPhotonixView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPhotonixDoc)));
	return (CPhotonixDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPhotonixView message handlers

void CPhotonixView::OnInitialUpdate()
{
	//create the shared dialogs
	CPhotonixDoc * pDoc=this->GetDocument ();
	/*	if(!pDoc->DialogsCreated)
	{

	CWnd* mwnd=AfxGetMainWnd ();
	CPhotonixDoc::RenderDlg.m_Window.SetPictureRect(CRect (0,0,200 ,200));
	CPhotonixDoc::RenderDlg.Create (IDD_DIALOG1,mwnd);
	CPhotonixDoc::TextureEditor.Create (IDD_TEXMAKER_DIALOG,mwnd);
	pDoc->m_ObjectsTree.Create (IDD_OBJTREE,mwnd);
	pDoc->m_ObjectsTree.pDoc=pDoc;
	//finished creating dialogs
	this->GetDocument ()->DialogsCreated=true;
	CMainFrame * mainfrm=(CMainFrame *)AfxGetMainWnd();
	CSliderCtrl * pCtrl=(CSliderCtrl *)mainfrm->m_AnimationDialogBar .GetDlgItem (IDC_KEYFRAMES);
	pCtrl->SetRange (0,100);
	//	mainfrm->OnAutomaticsplit ();
	}
	*/
	CRect r;
	this->GetClientRect (&r);
	RenderWnd=new CRenderWnd();
	RenderWnd->m_Container=this;
	RenderWnd->Create (NULL,"",WS_VISIBLE|WS_CHILD,r,this,1000);
	RenderWnd ->pDoc=this->GetDocument ();
	CMyApplication * app=this->GetDocument ()->MainApp;
	win= app->rs ->createRenderWindow (RenderWnd->GetSafeHwnd (),24);
	app->rs->mRenderIn .Add (win);
	win->Register (RenderWnd);
	app->Register (RenderWnd);
	//->&RenderWnd);
	//int width, height,colourDepth,left,top;
	//window->getMetrics(width,height,colourDepth,left,top);
	//create viewport
	//	if(s=="")
	//	{
	//create a new viewport for this camera
	CViewPort *vp1=new CViewPort( win,0,0,1,1,TRUE);//"my view port1"
	vp1->Clear =true;
	vp1->DrawGrid =true;
	vp1->BackColour=ColourValue(.5,.5,.5);//ColourValue ::Blue ;
	//	s.Format ("view port%d",ViewPortCounter);
	//	ViewPortCounter++;
	CString ViewportName=app->stringgenerator .RequestString ("ViewPort");
	app->mViewPorts[ViewportName]=vp1;

	//create a new scene selector also	
	CString s1;
	s1="SceneSel1";
	if(pDoc->m_Selector==NULL)
	{
		pDoc->m_Selector=(SceneSelector *)app->mSelectors[s1];
		pDoc->m_Selector->Register (pDoc);
		//pDoc->m_Selector->Register (&pDoc->m_ObjectsTree);
	}

	vp1->mSelector=pDoc->m_Selector;
	RenderWnd->Register ((SceneSelector*)app->mSelectors[s1]);
	RenderWnd->m_CurViewPort =vp1;

	
	RenderWnd->m_CurViewPort->mSceneDetail=mInitialSceneDetail ;


	//set the view port to viwndow and assign camera and scene to it
	CameraObj* cam=(CameraObj*)app->mCameras[InitCameraName];//"Camera1"
	vp1->mCamera=cam->camera;
	vp1->scene=pDoc->m_CurScene;
	win->mViewPorts.Add(vp1);
	RenderWnd->SetViewportCamera(cam->camera );	
	
	RenderWnd->OnRefresh();
	CView::OnInitialUpdate();

}

void CPhotonixView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);
	if(win)
		RenderWnd->MoveWindow(0,0,cx,cy);
}

void CPhotonixView::OnDestroy()
{
	Free();
	CView::OnDestroy();
}
void CPhotonixView::Free()
{

	CMyApplication * app=this->GetDocument ()->MainApp;
	if(app)
	{
		RenderWnd->m_CurCamera =0;
	RenderWnd->m_CurViewPort =0;

		int count=app->rs->mRenderIn .GetSize ();
		for (int i=0;i<count;i++)
		{
			if(win==(RenderWindow*)app->rs->mRenderIn [i])
			{
				app->rs->mRenderIn .RemoveAt (i);
				delete win;
				break;
			}
		}
		app->UnRegister (RenderWnd);
		if(RenderWnd)
		{
			if(RenderWnd->GetSafeHwnd ())
			{
				RenderWnd->SendMessage (WM_CLOSE,0,0);
			}
			delete RenderWnd;
			RenderWnd=0;
		}
	}
}
BOOL CPhotonixView::OnEraseBkgnd(CDC* pDC)
{
	// TODO: Add your message handler code here and/or call default
	return TRUE; 
	//return CView::OnEraseBkgnd(pDC);
}

void CPhotonixView::OnUpdate(CView* /*pSender*/, LPARAM lHint, CObject* /*pHint*/)
{
	if(lHint==0)
	{
		//this->Invalidate ();
		if(RenderWnd)
		{
		//	RenderWnd->Invalidate (false);
		//	RenderWnd->SendMessage(WM_PAINT ,1,0);
			RenderWnd->RedrawWindow();
		}
	}
	else if(lHint==2)  //it's about to delete all
	{
		Free();
	}
}

void CPhotonixView::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
{
	CView::OnActivate(nState, pWndOther, bMinimized);
}

void CPhotonixView::OnSetFocus(CWnd* pOldWnd)
{
	CView::OnSetFocus(pOldWnd);
	((CMainFrame*)GetParentFrame())->m_wndSplitter.RefreshSplitBars();

}

void CPhotonixView::OnKillFocus(CWnd* pNewWnd)
{
	CView::OnKillFocus(pNewWnd);
	((CMainFrame*)GetParentFrame())->m_wndSplitter.RefreshSplitBars();
}
