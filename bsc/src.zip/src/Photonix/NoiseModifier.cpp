// NoiseModifier.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "NoiseModifier.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNoiseModifier dialog

IMPLEMENT_SERIAL(CNoiseModifier,CAccessDialog,1)
CNoiseModifier::CNoiseModifier(CWnd* pParent /*=NULL*/)
	: CAccessDialog(CNoiseModifier::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNoiseModifier)
	m_is_uniform = FALSE;
	m_uniform = 0.0f;
	m_uniform_x = 0.0f;
	m_uniform_y = 0.0f;
	m_uniform_z = 0.0f;
	m_wavetype = 0;
	m_octaves = 6;
	m_phase = 0.0f;
	m_omega = 0.5f;
	m_lambda = 2.0f;
	m_frequency = 1.0f;
	m_exp = 1.0f;
	//}}AFX_DATA_INIT
}


void CNoiseModifier::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNoiseModifier)
	DDX_Check(pDX, IDC_IS_UNIFORM, m_is_uniform);
	DDX_Text(pDX, IDC_UNIFORM, m_uniform);
	DDV_MinMaxFloat(pDX, m_uniform, 0.f, 5.f);
	DDX_Text(pDX, IDC_UNIFORM_X, m_uniform_x);
	DDV_MinMaxFloat(pDX, m_uniform_x, 0.f, 5.f);
	DDX_Text(pDX, IDC_UNIFORM_Y, m_uniform_y);
	DDV_MinMaxFloat(pDX, m_uniform_y, 0.f, 5.f);
	DDX_Text(pDX, IDC_UNIFORM_Z, m_uniform_z);
	DDV_MinMaxFloat(pDX, m_uniform_z, 0.f, 5.f);
	DDX_CBIndex(pDX, IDC_WAVETYPE, m_wavetype);
	DDX_Text(pDX, IDC_OCTAVES, m_octaves);
	DDV_MinMaxInt(pDX, m_octaves, 1, 10);
	DDX_Text(pDX, IDC_PHASE, m_phase);
	DDV_MinMaxFloat(pDX, m_phase, 0.f, 360.f);
	DDX_Text(pDX, IDC_OMEGA, m_omega);
	DDV_MinMaxFloat(pDX, m_omega, 0.f, 100.f);
	DDX_Text(pDX, IDC_LAMBDA, m_lambda);
	DDV_MinMaxFloat(pDX, m_lambda, 0.f, 100.f);
	DDX_Text(pDX, IDC_FREQUENCY, m_frequency);
	DDV_MinMaxFloat(pDX, m_frequency, 0.f, 100.f);
	DDX_Text(pDX, IDC_EXP, m_exp);
	DDV_MinMaxFloat(pDX, m_exp, 1.e-003f, 100.f);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNoiseModifier, CDialog)
	//{{AFX_MSG_MAP(CNoiseModifier)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNoiseModifier message handlers
void CNoiseModifier::Serialize(CArchive &ar)
{
	if(ar.IsStoring ())
	{
			ar<<m_is_uniform<<m_uniform<<m_uniform_x<<m_uniform_y<<m_uniform_z<<m_wavetype<<m_octaves<<m_phase<<m_omega<<m_lambda<<m_frequency<<m_exp;
	}

	else
	{
		ar>>m_is_uniform>>m_uniform>>m_uniform_x>>m_uniform_y>>m_uniform_z>>m_wavetype>>m_octaves>>m_phase>>m_omega>>m_lambda>>m_frequency>>m_exp;

	}

}

BOOL CNoiseModifier::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CComboBox * combo=((CComboBox*)this->GetDlgItem (IDC_WAVETYPE));
combo->AddString ("ramp");
combo->AddString ("triangle");
combo->AddString ("sin");
combo->AddString ("Scallop");
combo->AddString ("cubic");
combo->AddString ("poly");

this->UpdateData (false);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
