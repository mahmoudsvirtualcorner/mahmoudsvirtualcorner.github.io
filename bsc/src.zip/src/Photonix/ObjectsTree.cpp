// ObjectsTree.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "ObjectsTree.h"
#include "PhotonixDoc.h"
#include "ObjMaterialDlg.h"

//#include "irenderable.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CObjectsTree dialog


CObjectsTree::CObjectsTree(CWnd* pParent /*=NULL*/)
	: CDialog(CObjectsTree::IDD, pParent)
{
	//{{AFX_DATA_INIT(CObjectsTree)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CObjectsTree::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CObjectsTree)
	DDX_Control(pDX, IDC_OBJECTS, m_objtree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CObjectsTree, CDialog)
	//{{AFX_MSG_MAP(CObjectsTree)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
	ON_NOTIFY(TVN_DELETEITEM, IDC_OBJECTS, OnTvnDeleteitemObjects)
	ON_NOTIFY(TVN_SELCHANGED, IDC_OBJECTS, OnTvnSelchangedObjects)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CObjectsTree message handlers
void CObjectsTree::OnMessage(VOID *pSender,CString Message)
{
/*	if(Message=="Selection")
	{
		// select object in the tree
		//	AfxMessageBox ("obj sel");
//		CObArray *pPicked=&((SceneSelector*)pSender)->mPicked;
//				int count=pPicked->GetSize ();
//		for (int i=0;i<count;i++)
//		{
//		//	pPicked[i]
//		}
		
		if(pPicked->GetSize ()==1)
		{
			IRenderable* IRend=(IRenderable*)(pPicked->GetAt (0));
			HTREEITEM h=m_objtree.GetRootItem ();
			if(h)
			{
				SceneObjectData* pdata=(SceneObjectData*)m_objtree.GetItemData (h);
				if(pdata->pObject->pRenderable==IRend)
				{
					m_objtree.SelectItem (h);
					return;
				}
			}
			// Look at all of the root-level items
			HTREEITEM hCurrent =m_objtree.GetNextItem(h, TVGN_NEXT);
			while (hCurrent != NULL)
			{
				SceneObjectData* pdata=(SceneObjectData*)m_objtree.GetItemData (hCurrent);
				if(pdata->pObject->pRenderable==IRend)
				{
					m_objtree.SelectItem (hCurrent);
					break;
				}

				// Try to get the next item
				hCurrent = m_objtree.GetNextItem(hCurrent, TVGN_NEXT);
			}
		}
	}
	*/
}

void CObjectsTree::OnTvnDeleteitemObjects(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	// TODO: Add your control notification handler code here

//	m_rollup .RemoveAllPages ();
	
	*pResult = 0;
}

void CObjectsTree::OnTvnSelchangedObjects(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	// TODO: Add your control notification handler code here
/*	SceneObjectData* pdata=(SceneObjectData*)pNMTreeView->itemNew.lParam;
	if(pdata)
	{
		{//working to select object oin the scene
			CObArray *pPicked=&(pDoc->m_Selector->mPicked);
			int count=pPicked->GetSize ();
			for (int i=0;i<count;i++)
			{
				IRenderable* IRend=(IRenderable*)pPicked->GetAt (i);
				IRend->DoDeSelect ();
			}
			pPicked->RemoveAll ();
			pdata->pObject->pRenderable->DoSelect ();
			pPicked->Add (pdata->pObject->pRenderable );
			pDoc->m_Selector->ReConstructTool();
		}
		{//working to show it's options in the dialog
			m_rollup.RemoveAllPages ();
			CMapStringToOb& hashtable =pdata->pObject->OptionDialogs;
			POSITION pos=hashtable.GetStartPosition ();
			while (pos!=NULL)
			{
				CObject *dlg;CString key;
				hashtable.GetNextAssoc (pos,key,dlg);
				CDialog *dialog=(CDialog*)dlg;
				dialog->SetParent (&m_rollup);
				m_rollup.InsertPage (key,dialog,false);
			}
		}

		pDoc->UpdateAllViews(0,0,0);
	}*/
	*pResult = 0;
}

BOOL CObjectsTree::OnInitDialog()
{
	CDialog::OnInitDialog();
/*	BOOL bSuccess;
	CWnd * wnd=this->GetDlgItem (IDC_OBJECT_OPTIONS);
	CRect rect;
	wnd->GetWindowRect (&rect);
	this->ScreenToClient (&rect);
	
	
	bSuccess = m_rollup.Create(WS_CHILD | WS_DLGFRAME | WS_VISIBLE,rect, this, 1100);// CRect(220,0,220+300,300)
	ASSERT(bSuccess);
	// TODO:  Add extra initialization here
*/
	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}
void CObjectsTree::Reset()
{
if(m_objtree.m_hWnd )
	m_objtree.DeleteAllItems();
}

