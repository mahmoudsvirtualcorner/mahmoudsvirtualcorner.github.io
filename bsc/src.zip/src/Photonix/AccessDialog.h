#pragma once

#include "enggenclasses.h"
// CAccessDialog dialog

class CAccessDialog : public CDialog
{
	DECLARE_DYNAMIC(CAccessDialog)

public:
	CAccessDialog(UINT ,CWnd* pParent = NULL);   // standard constructor
	virtual ~CAccessDialog();

// Dialog Data
	
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	LPCTSTR GetTemplate(void);
	ISceneObject * m_Object;

};
