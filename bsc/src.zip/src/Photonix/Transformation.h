#if !defined(AFX_TRANSFORMATION_H__9D10B576_1B22_4EAE_8D02_AB8FA82F7160__INCLUDED_)
#define AFX_TRANSFORMATION_H__9D10B576_1B22_4EAE_8D02_AB8FA82F7160__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Transformation.h : header file
//
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CTransformation dialog

class CTransformation : public CAccessDialog//CDialog
{
// Construction
public:
	DECLARE_SERIAL(CTransformation)
	CTransformation(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTransformation)
	enum { IDD = IDD_TRANSFORMATION };
	float	m_rot_x;
	float	m_rot_y;
	float	m_rot_z;
	float	m_scale_x;
	float	m_scale_y;
	float	m_scale_z;
	float	m_trans_x;
	float	m_trans_y;
	float	m_trans_z;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTransformation)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
virtual void Serialize(CArchive &ar);

	// Generated message map functions
	//{{AFX_MSG(CTransformation)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRANSFORMATION_H__9D10B576_1B22_4EAE_8D02_AB8FA82F7160__INCLUDED_)
