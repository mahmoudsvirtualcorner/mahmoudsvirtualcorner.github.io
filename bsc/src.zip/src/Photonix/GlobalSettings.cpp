// GlobalSettings.cpp : implementation file
//

#include "stdafx.h"
#include "Photonix.h"
#include "GlobalSettings.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGlobalSettings dialog


CGlobalSettings::CGlobalSettings(CWnd* pParent /*=NULL*/)
	: CDialog(CGlobalSettings::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGlobalSettings)
	m_16bit_hfield = FALSE;
	m_adc_bailout = 0.00392f;
	m_assumed_gamma = 1.9f;
	m_max_intersect = 64;
	m_max_trace = 10;
	m_n_of_waves = 10;
	//}}AFX_DATA_INIT
	m_irid.SetColor (RGB(.25*255,.18*255,.14*255));
m_backcolor.SetColor (RGB(0,0,0));
m_ambient.SetColor (RGB(255,255,255));

}


void CGlobalSettings::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGlobalSettings)
	DDX_Check(pDX, IDC_16BIT_HEIGHTFIELD, m_16bit_hfield);
	DDX_Text(pDX, IDC_ADC_BAILOUT, m_adc_bailout);
	DDV_MinMaxFloat(pDX, m_adc_bailout, 0.f, 1.f);
	DDX_Text(pDX, IDC_ASSUMED_GAMMA, m_assumed_gamma);
	DDX_Text(pDX, IDC_MAX_INTERSECT, m_max_intersect);
	DDX_Text(pDX, IDC_MAX_TRACE, m_max_trace);
	DDX_Text(pDX, IDC_NUMBER_OF_WAVES, m_n_of_waves);
	DDX_Control(pDX, IDC_COL_AMBIENT, m_ambient);
	DDX_Control(pDX, IDC_IRID, m_irid);
	DDX_Control(pDX, IDC_BACKCOLOR, m_backcolor);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGlobalSettings, CDialog)
	//{{AFX_MSG_MAP(CGlobalSettings)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGlobalSettings message handlers

BOOL CGlobalSettings::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
//	m_ambient.SetRegSection();
//	m_irid.SetRegSection();
//m_backcolor.SetRegSection();


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
