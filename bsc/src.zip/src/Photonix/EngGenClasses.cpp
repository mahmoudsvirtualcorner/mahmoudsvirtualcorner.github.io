#include "stdafx.h"

#include "enggenclasses.h"
#include "Photonix.h"
#include "TextureTreeParser.h"

#include "matrices.h"
#include "SphereMesh.h"
#include "TorusMesh.h"
#include "BoxMesh.h"
#include "lightmesh.h"
#include "ConeMesh.h"
#include "Cylindermesh.h"
#include "cameramesh.h"
#include "SpotLightMesh.h"

extern CTextureTreeParser TreeParser;
/////////////////////////////////////////////////////////////////////
ISceneObject::ISceneObject()
{
	pRenderable=0;
	GenerateCaustics=false;
	RecieveCaustics=false;
	Reflection=false;
	Refraction=false;
	HasShadow=true;
	ObjectType=0;
}
ISceneObject::~ISceneObject()
{
	CMapStringToOb& hashtable =OptionDialogs;
	POSITION pos=hashtable.GetStartPosition ();
	while (pos!=NULL)
	{
		CObject *dlg;CString key;
		hashtable.GetNextAssoc (pos,key,dlg);
		((CDialog*)dlg)->DestroyWindow ();
		delete dlg;
	}
}
OBJECT* ISceneObject::Generate()
{
	if(obj)
	{
		TEXTURE * tex=TreeParser.GetTexture (RayTextureName);
		if(tex)
		{
			obj->Type |= TEXTURED_OBJECT;

			obj->Interior=TreeParser.GetInterior(RayTextureName);
			if(obj->Interior)
			{
				Set_Flag(obj,HOLLOW_FLAG);
				Set_Flag (obj, HOLLOW_SET_FLAG);
			}
			Link_Textures(&(obj->Texture),tex);
		}


		OBJECT * Object=obj;
		if(!HasShadow)
		{
			Set_Flag(Object, NO_SHADOW_FLAG);
		}
		if(GenerateCaustics)
		{
			//TARGET_TOKEN
			Object->Ph_Density=1;
			if (Object->Ph_Density > 0)
			{
				Set_Flag(Object,PH_TARGET_FLAG);
				CheckPassThru(Object, PH_TARGET_FLAG);
			}
			else
			{
				Clear_Flag(Object, PH_TARGET_FLAG);
			}
			//REFRACTION_TOKEN
			if(Refraction)
			{ 
				Set_Flag(Object, PH_RFR_ON_FLAG);
				Clear_Flag(Object, PH_RFR_OFF_FLAG);
				CheckPassThru(Object, PH_RFR_ON_FLAG);
			}
			else
			{ 
				Clear_Flag(Object, PH_RFR_ON_FLAG);
				Set_Flag(Object, PH_RFR_OFF_FLAG);
			}
			//REFLECTION_TOKEN
			if(Reflection)
			{ 
				Set_Flag(Object, PH_RFL_ON_FLAG); 
				Clear_Flag(Object, PH_RFL_OFF_FLAG); 
			}
			else
			{ 
				Clear_Flag(Object, PH_RFL_ON_FLAG); 
				Set_Flag(Object, PH_RFL_OFF_FLAG); 
			}

		}
		if(RecieveCaustics)
		{
			Bool_Flag (Object, PH_IGNORE_PHOTONS_FLAG, 0);
		}
		if(0)//PASS_THROUGH_TOKEN
		{
			Set_Flag(Object, PH_PASSTHRU_FLAG);
			CheckPassThru(Object, PH_PASSTHRU_FLAG);
		}
		else
		{
			Clear_Flag(Object, PH_PASSTHRU_FLAG);
		}
		OBJECT * ret=obj;
		obj=0;
		return ret;//obj->GetCopy ();
	}

	return 0;
}
/////////////////////////////////////////*sphere*//////////////////////////////////////////
SphereObj::SphereObj(void)
//:SphereMesh()
{
	RayTextureName="";
	obj=0;
	pRenderable=new SphereMesh ();
	pRenderable->pReserved=this;
}

SphereObj::~SphereObj(void)
{
	if(obj)
	{
		obj->Free ();
		delete obj;
	}
}

void SphereObj::UpdateObject()
{
	SphereMesh * mesh =(SphereMesh *)pRenderable;
	if(!obj)
	{
		obj=new SPHERE();
	}
	SPHERE *object=(SPHERE*)obj;
	//double vect[3]={-2,-1,-1};
object->Radius=.5;
	TRANSFORM *result=object->Trans;
	register int i;
	Matrix4 mat = mesh->Bounding.GetWorldTransform();
	for (i = 0; i < 4; i++)
	{
		(result->matrix)[i][0] = mat.m[i][0];//29-jan  //((Matrix4)(Bounding.Matrix))
		(result->matrix)[i][1] = mat.m[i][1];
		(result->matrix)[i][2] = mat.m[i][2];
		(result->matrix)[i][3] = mat.m[i][3];
	}
	MInvers(result->inverse, result->matrix);
	Compute_Sphere_BBox(object);
}
OBJECT* SphereObj::Generate()
{
	return ISceneObject ::Generate ();
}
/////////////////////////////////*torus*////////////////////////////////////
TorusObj::TorusObj(void)
//:TorusMesh()
{
	RayTextureName="";
	obj=0;
	pRenderable=new TorusMesh ();
		pRenderable->pReserved=this;

}

TorusObj::~TorusObj(void)
{
	if(obj)
	{
		obj->Free ();
		delete obj;
	}
}

void TorusObj::UpdateObject()
{
		TorusMesh * mesh =(TorusMesh *)pRenderable;

	if(!obj)
	{
		obj=new TORUS ();
	}
	TORUS *object=(TORUS*)obj;
	//double vect[3]={-2,-1,-1};
	object->R =mesh->BigRadius;
	object->r=mesh->SmallRadius;
	if(object->Trans==NULL)
		object->Trans = Create_Transform();

	TRANSFORM *result=object->Trans;
	register int i;
	Matrix4 mat = mesh->Bounding.GetWorldTransform();
	for (i = 0; i < 4; i++)
	{
		(result->matrix)[i][0] = mat.m[i][0];//29-jan  //((Matrix4)(Bounding.Matrix))
		(result->matrix)[i][1] = mat.m[i][1];
		(result->matrix)[i][2] = mat.m[i][2];
		(result->matrix)[i][3] = mat.m[i][3];
	}
	MInvers(result->inverse, result->matrix);
/*	VECTOR Local_Vector;
	Make_Vector(Local_Vector,-90,0,0);
	TRANSFORM Local_Trans;
	Compute_Rotation_Transform(&Local_Trans, Local_Vector);
	Rotate_Object (object, Local_Vector, &Local_Trans);
*/
	Compute_Torus_BBox(object);
}
OBJECT* TorusObj::Generate()
{
	return ISceneObject ::Generate ();
}
//////////////////////////////////*box*/////////////////////////////////////
BoxObj::BoxObj(void)
//:BoxMesh(0)
{
	RayTextureName="";
	obj=0;
	pRenderable=new BoxMesh (0);
		pRenderable->pReserved=this;

}

BoxObj::~BoxObj(void)
{
	if(obj)
	{
		obj->Free ();
		delete obj;
	}
}

void BoxObj::UpdateObject()
{
			BoxMesh * mesh =(BoxMesh *)pRenderable;

	if(!obj)
	{
		obj=new BOX ();
	}
	BOX *object=(BOX*)obj;

	{
		DBL temp;
	//	Make_Vector(object->bounds[0],-1,-1,1);
	//	Make_Vector(object->bounds[1],1,1,-1);
		Make_Vector(object->bounds[0],-.5,-.5,.5);
		Make_Vector(object->bounds[1],.5,.5,-.5);
		if (object->bounds[0][X] > object->bounds[1][X]) {
			temp = object->bounds[0][X];
			object->bounds[0][X] = object->bounds[1][X];
			object->bounds[1][X] = temp;
		}
		if (object->bounds[0][Y] > object->bounds[1][Y]) {
			temp = object->bounds[0][Y];
			object->bounds[0][Y] = object->bounds[1][Y];
			object->bounds[1][Y] = temp;
		}
		if (object->bounds[0][Z] > object->bounds[1][Z]) {
			temp = object->bounds[0][Z];
			object->bounds[0][Z] = object->bounds[1][Z];
			object->bounds[1][Z] = temp;
		}


	}
	if(object->Trans==NULL)
		object->Trans = Create_Transform();
	TRANSFORM *result=object->Trans;
	register int i;
	Matrix4 mat = mesh->Bounding.GetWorldTransform();
	for (i = 0; i < 4; i++)
	{
		(result->matrix)[i][0] = mat.m[i][0];//29-jan  //((Matrix4)(Bounding.Matrix))
		(result->matrix)[i][1] = mat.m[i][1];
		(result->matrix)[i][2] = mat.m[i][2];
		(result->matrix)[i][3] = mat.m[i][3];
	}
	MInvers(result->inverse, result->matrix);
	object->Compute_Box_BBox();
}
OBJECT* BoxObj::Generate()
{
	return ISceneObject ::Generate ();
}
/////////////////////////////////*light*//////////////////////////////////
PointLightObj::PointLightObj(void)
//:LightMesh()
{
	RayTextureName="";
	obj=0;
	MediaInteraction=1;
	MediaAttenuation=0;
	Multiplier=1;
	color=RGB(100,100,100);
	pRenderable=new LightMesh ();
		pRenderable->pReserved=this;
ObjectType =OBJ_POINT_LIGHT;
	//custom data
		m_enablearea = FALSE;
	m_samplesu = 10;
	m_samplesv = 10;
	m_axis1x = 1.0f;
	m_axis1y = 0.0f;
	m_axis1z = 0.0f;
	m_axis2x = 0.0f;
	m_axis2y = 1.0f;
	m_axis2z = 0.0f;
}

PointLightObj::~PointLightObj(void)
{
	if(obj)
	{
		obj->Free ();
		delete obj;
	}
}

void PointLightObj::UpdateObject()
{
	LightMesh * mesh =(LightMesh *)pRenderable;

	if(!obj)
	{
		obj=new LIGHT_SOURCE ();
	}
	LIGHT_SOURCE *object=(LIGHT_SOURCE*)obj;

	//double lightcenter[3]={2,2,- 2};
	//float lightcolor[5]={1,1,1,0,0};
		Vector3 pos ;
		Matrix4 mat=mesh->Bounding.GetWorldTransform();//.GetTranslation(pos);
pos.x=mat(3,0) ;pos.y=mat(3,1) ;pos.z=mat(3,2) ;
	DBL Len;
	//desc lights
	//			LIGHT_SOURCE *Object;
	//			Object = new LIGHT_SOURCE;//Create_Light_Source ();
	//Assign_Vector(object->Center,lightcenter);
	Make_Vector(object->Center,pos.x,pos.y,pos.z);
	
	//Assign_Colour(object->Colour,lightcolor);
Make_Colour (object->Colour,((float)GetRValue (color)/255)*Multiplier,((float)GetGValue (color)/255)*Multiplier,((float)GetBValue (color)/255)*Multiplier);
	//Object->Fade_Distance=20;
	//Object-> Fade_Power=2;				

	if(!HasShadow)
	{
		object->Light_Type = FILL_LIGHT_SOURCE;
	}

	VSub(object->Direction, object->Points_At, object->Center);

	VLength(Len, object->Direction);

	if (Len > EPSILON)
	{
		VInverseScaleEq(object->Direction, Len);
	}

	// Make sure that circular light sources are larger than 1 by x [ENB 9/97] 
	if (object->Circular)
	{
		if ((object->Area_Size1 <= 1) || (object->Area_Size2 <= 1))
		{
			Error("Circular area light must have more than 1 point per axis");
		}
	}

	
	object->Media_Interaction = MediaInteraction;
	object->Media_Attenuation =MediaAttenuation;

	//photon mapping instructions
	if(Refraction)// REFRACTION_TOKEN
	{ 
		Set_Flag(object, PH_RFR_ON_FLAG); 
		Clear_Flag(object, PH_RFR_OFF_FLAG); 
	}
	else
	{ 
		Clear_Flag(object, PH_RFR_ON_FLAG); 
		Set_Flag(object, PH_RFR_OFF_FLAG); 
	}
	if(Reflection)// REFLECTION_TOKEN
	{ 
		Set_Flag(object, PH_RFL_ON_FLAG); 
		Clear_Flag(object, PH_RFL_OFF_FLAG); 
	}
	else
	{
		Clear_Flag(object, PH_RFL_ON_FLAG); 
		Set_Flag(object, PH_RFL_OFF_FLAG); 
	}
	/*	if(0)// AREA_LIGHT_TOKEN
	Object->Photon_Area_Light = true;
	*/	
	//		Post_Process (Object, NULL);
	//		Link_To_Frame (Object);
//for the area light source
       object->Area_Light = m_enablearea;
		if(object->Area_Light)
		{
       Make_Vector (object->Axis1,m_axis1x,m_axis1y,m_axis1z); 
       Make_Vector (object->Axis2,m_axis2x,m_axis2y,m_axis2z); 
       object->Area_Size1 = m_samplesu;
       object->Area_Size2 = m_samplesv;
       object->Light_Grid = Create_Light_Grid (object->Area_Size1, object->Area_Size2);
		}
	///////////////



}
OBJECT* PointLightObj::Generate()
{
	//return IRenderable ::Generate ();
	OBJECT * ret=obj;
	obj=0;
	return ret;
}

//////////////////////////////////*spotlight*///////////////////////
SpotLightObj::SpotLightObj(void)
//:PointLightObj()
{
RayTextureName="";
	obj=0;
	MediaInteraction=1;
	MediaAttenuation=0;
	Multiplier=1;
	color=RGB(100,100,100);
	pRenderable=new SpotLightMesh ();
	pRenderable->pReserved=this;
ObjectType =OBJ_SPOT_LIGHT;
	//custom data
	m_enablearea = FALSE;
	m_samplesu = 10;
	m_samplesv = 10;
	m_axis1x = 1.0f;
	m_axis1y = 0.0f;
	m_axis1z = 0.0f;
	m_axis2x = 0.0f;
	m_axis2y = 1.0f;
	m_axis2z = 0.0f;
}

void SpotLightObj::UpdateObject()
{
	BoxMesh * source =&((SpotLightMesh *)pRenderable)->m_FromRend;
	BoxMesh * dest =&((SpotLightMesh *)pRenderable)->m_ToRend ;

	if(!obj)
	{
		obj=new LIGHT_SOURCE ();
	}
	LIGHT_SOURCE *object=(LIGHT_SOURCE*)obj;

	//stoplight properties
	object->Light_Type = SPOT_SOURCE;
	object->Radius =cos(RadiusAngle * M_PI_180);;// cos(30 * M_PI_180);
	object->Falloff = cos(FalloffAngle * M_PI_180);;//cos(45 * M_PI_180);
	object->Coeff = Tightness;
	//double lightcenter[3]={2,2,- 2};
	//float lightcolor[5]={1,1,1,0,0};
		Vector3 pos ;
		Matrix4 mat=source->Bounding.GetWorldTransform();//.GetTranslation(pos);
pos.x=mat(3,0) ;pos.y=mat(3,1) ;pos.z=mat(3,2) ;
	DBL Len;
	//desc lights
	//			LIGHT_SOURCE *Object;
	//			Object = new LIGHT_SOURCE;//Create_Light_Source ();
	//Assign_Vector(object->Center,lightcenter);
	Make_Vector(object->Center,pos.x,pos.y,pos.z);


		
		mat=dest->Bounding.GetWorldTransform();//.GetTranslation(pos);
pos.x=mat(3,0) ;pos.y=mat(3,1) ;pos.z=mat(3,2) ;
	Make_Vector(object->Points_At,pos.x,pos.y,pos.z);

	//Assign_Colour(object->Colour,lightcolor);
Make_Colour (object->Colour,((float)GetRValue (color)/255)*Multiplier,((float)GetGValue (color)/255)*Multiplier,((float)GetBValue (color)/255)*Multiplier);
	//Object->Fade_Distance=20;
	//Object-> Fade_Power=2;				


	if(!HasShadow)
	{
		object->Light_Type = FILL_LIGHT_SOURCE;
	}

	VSub(object->Direction, object->Points_At, object->Center);

	VLength(Len, object->Direction);

	if (Len > EPSILON)
	{
		VInverseScaleEq(object->Direction, Len);
	}

	// Make sure that circular light sources are larger than 1 by x [ENB 9/97] 
	if (object->Circular)
	{
		if ((object->Area_Size1 <= 1) || (object->Area_Size2 <= 1))
		{
			Error("Circular area light must have more than 1 point per axis");
		}
	}

	
	object->Media_Interaction = MediaInteraction;
	object->Media_Attenuation =MediaAttenuation;

	//photon mapping instructions
	if(Refraction)// REFRACTION_TOKEN
	{ 
		Set_Flag(object, PH_RFR_ON_FLAG); 
		Clear_Flag(object, PH_RFR_OFF_FLAG); 
	}
	else
	{ 
		Clear_Flag(object, PH_RFR_ON_FLAG); 
		Set_Flag(object, PH_RFR_OFF_FLAG); 
	}
	if(Reflection)// REFLECTION_TOKEN
	{ 
		Set_Flag(object, PH_RFL_ON_FLAG); 
		Clear_Flag(object, PH_RFL_OFF_FLAG); 
	}
	else
	{
		Clear_Flag(object, PH_RFL_ON_FLAG); 
		Set_Flag(object, PH_RFL_OFF_FLAG); 
	}
	/*	if(0)// AREA_LIGHT_TOKEN
	Object->Photon_Area_Light = true;
	*/	
	//		Post_Process (Object, NULL);
	//		Link_To_Frame (Object);
//for the area light source
	object->Area_Light = m_enablearea;
	if(object->Area_Light)
	{
		Make_Vector (object->Axis1,m_axis1x,m_axis1y,m_axis1z); 
		Make_Vector (object->Axis2,m_axis2x,m_axis2y,m_axis2z); 
		object->Area_Size1 = m_samplesu;
		object->Area_Size2 = m_samplesv;
		object->Light_Grid = Create_Light_Grid (object->Area_Size1, object->Area_Size2);
	}



}
OBJECT* SpotLightObj::Generate()
{
	//return IRenderable ::Generate ();
	OBJECT * ret=obj;
	obj=0;
	return ret;
}
SpotLightObj::~SpotLightObj(void)
{
	if(obj)
	{
		obj->Free ();
		delete obj;
	}
}
/////////////////////////////////*cone *//////////////////////////////////
ConeObj::ConeObj(void)
//:ConeMesh()
{
	RayTextureName="";
	obj=0;
	pRenderable=new ConeMesh ();
		pRenderable->pReserved=this;

}

ConeObj::~ConeObj(void)
{
	if(obj)
	{
		obj->Free ();
		delete obj;
	}
}

void ConeObj::UpdateObject()
{
			ConeMesh * mesh =(ConeMesh *)pRenderable;

	if(!obj)
	{
		obj=new CONE ();
	}
	CONE *object=(CONE*)obj;

	Make_Vector ( object->apex,0,-0.5,0);
	object->apex_radius=0.5;
	Make_Vector ( object->base,0,0.5,0);
	object->base_radius=0;


	if(object->Trans==NULL)
		object->Trans = Create_Transform();
	TRANSFORM *result=object->Trans;
	register int i;
	Matrix4 mat = mesh->Bounding.GetWorldTransform();
	for (i = 0; i < 4; i++)
	{
		(result->matrix)[i][0] = mat.m[i][0];//29-jan  //((Matrix4)(Bounding.Matrix))
		(result->matrix)[i][1] = mat.m[i][1];
		(result->matrix)[i][2] = mat.m[i][2];
		(result->matrix)[i][3] = mat.m[i][3];
	}
	MInvers(result->inverse, result->matrix);
//	object->Compute_Box_BBox();
		/* Compute run-time values for the cone */
   Compute_Cone_Data((OBJECT *)object);

   Compute_Cone_BBox(object);  

}
OBJECT* ConeObj::Generate()
{
	return ISceneObject ::Generate ();
}
///////////////////////////////cylinder//////////////////////////////////////////
CylinderObj::CylinderObj(void)
//:CylinderMesh()
{
	RayTextureName="";
	obj=0;
	pRenderable=new CylinderMesh();
		pRenderable->pReserved=this;

}

CylinderObj::~CylinderObj(void)
{
	if(obj)
	{
		obj->Free ();
		delete obj;
	}
}

void CylinderObj::UpdateObject()
{
			CylinderMesh  * mesh =(CylinderMesh *)pRenderable;

	if(!obj)
	{
		obj=new CYLINDER ();
	}
	CYLINDER *object=(CYLINDER*)obj;

	Make_Vector ( object->apex,0,-0.5,0);
	object->apex_radius=object->base_radius=0.5;
	Make_Vector ( object->base,0,0.5,0);


	if(object->Trans==NULL)
		object->Trans = Create_Transform();
	TRANSFORM *result=object->Trans;
	register int i;
	Matrix4 mat = mesh->Bounding.GetWorldTransform();
	for (i = 0; i < 4; i++)
	{
		(result->matrix)[i][0] = mat.m[i][0];//29-jan  //((Matrix4)(Bounding.Matrix))
		(result->matrix)[i][1] = mat.m[i][1];
		(result->matrix)[i][2] = mat.m[i][2];
		(result->matrix)[i][3] = mat.m[i][3];
	}
	MInvers(result->inverse, result->matrix);
//	object->Compute_Box_BBox();
		/* Compute run-time values for the cone */
   Compute_Cone_Data((OBJECT *)object);

   Compute_Cone_BBox(object);  

}
OBJECT* CylinderObj::Generate()
{
	return ISceneObject ::Generate ();
}
////////////////////////////////////*mesh*/////////////////////////////
MeshObj::MeshObj(void)
//:BoxMesh(0)
{
	RayTextureName="";
	obj=0;
	//pRenderable=new BoxMesh (0);
	//	pRenderable->pReserved=this;
pRenderable=NULL;
bSmooth=true;
}

MeshObj::~MeshObj(void)
{
	if(obj)
	{
		obj->Free ();
		delete obj;
	}
}
#include "source\mesh.h"

void MeshObj::UpdateObject()
{
	Mesh* mesh =(Mesh *)pRenderable;

	if(!obj)
	{
		obj=new MESH();
	}
	MESH*object=(MESH* )obj;
	int number_of_normals, number_of_textures, number_of_triangles, number_of_vertices;//, number_of_uvcoords;
	int max_normals, max_textures, max_triangles, max_vertices;//, max_uvcoords;
	int fully_textured=true;
	VECTOR Inside_Vect;
	//  TEXTURE *t2, *t3;
   DBL l1, l2, l3;

	VECTOR D1, D2, P1, P2, P3, N1, N2, N3, N;
	// UV_VECT UV1, UV2, UV3;

	bool foundZeroNormal=false;

	Make_Vector(Inside_Vect, 0, 0, 0);
	SNGL_VECT *Normals, *Vertices;
	TEXTURE **Textures;
	MESH_TRIANGLE *Triangles;

	/* Allocate temporary normals, textures, triangles and vertices. */

	max_normals = 256;

	max_vertices = 256;

	max_textures = 16;

	max_triangles = 256;

	Normals = (SNGL_VECT *)POV_MALLOC(max_normals*sizeof(SNGL_VECT), "temporary triangle mesh data");

	Textures = (TEXTURE **)POV_MALLOC(max_textures*sizeof(TEXTURE *), "temporary triangle mesh data");

	Triangles = (MESH_TRIANGLE *)POV_MALLOC(max_triangles*sizeof(MESH_TRIANGLE), "temporary triangle mesh data");

	Vertices = (SNGL_VECT *)POV_MALLOC(max_vertices*sizeof(SNGL_VECT), "temporary triangle mesh data");

	/* Read raw triangle file. */

	number_of_normals = 0;

	number_of_textures = 0;

	number_of_triangles = 0;

	number_of_vertices = 0;

	/* NK 1998 */
	/*  max_uvcoords = 256;
	UVCoords = (UV_VECT *)POV_MALLOC(max_uvcoords*sizeof(UV_VECT), "temporary triangle mesh data");
	number_of_uvcoords = 0;
	*/

	Create_Mesh_Hash_Tables();

	// b.readUInt32();
	//(*mesh)->m_rend.pIndexes = new uint16[numTris*3];
	int numTris =mesh->m_rend.numIndexes /3;
	for (int t = 0; t < numTris; ++t) 
	{
		// for flat triangles

		// vertex index
		int v0=mesh->m_rend.pIndexes[t*3+0];
		int v1=	mesh->m_rend.pIndexes[t*3+1];
		int v2=	mesh->m_rend.pIndexes[t*3+2];
		Real x0 = mesh->m_rend.pVertices[v0*3+0];Real y0 = mesh->m_rend.pVertices[v0*3+1];Real z0 = mesh->m_rend.pVertices[v0*3+2];
		Real x1 = mesh->m_rend.pVertices[v1*3+0];Real y1 = mesh->m_rend.pVertices[v1*3+1];Real z1 = mesh->m_rend.pVertices[v1*3+2];
		Real x2 = mesh->m_rend.pVertices[v2*3+0];Real y2 = mesh->m_rend.pVertices[v2*3+1];Real z2 = mesh->m_rend.pVertices[v2*3+2];
		Make_Vector(P1,x0,y0,z0);
		Make_Vector(P2,x1,y1,z1);
		Make_Vector(P3,x2,y2,z2);
		
		if(!bSmooth)
		{
			if (!Mesh_Degenerate(P1, P2, P3))
			{
				if (number_of_triangles >= max_triangles)
				{
					if (max_triangles >= INT_MAX/2)
					{
						Error("Too many triangles in triangle mesh.");
					}

					max_triangles *= 2;

					Triangles = (MESH_TRIANGLE *)POV_REALLOC(Triangles, max_triangles*sizeof(MESH_TRIANGLE), "triangle triangle mesh data");
				}
				// Init triangle. 

				Init_Mesh_Triangle(&Triangles[number_of_triangles]);

				Triangles[number_of_triangles].P1 = Mesh_Hash_Vertex(&number_of_vertices, &max_vertices, &Vertices, P1);
				Triangles[number_of_triangles].P2 = Mesh_Hash_Vertex(&number_of_vertices, &max_vertices, &Vertices, P2);
				Triangles[number_of_triangles].P3 = Mesh_Hash_Vertex(&number_of_vertices, &max_vertices, &Vertices, P3);

				Compute_Mesh_Triangle(&Triangles[number_of_triangles], false, P1, P2, P3, N);

				Triangles[number_of_triangles].Normal_Ind = Mesh_Hash_Normal(&number_of_normals, &max_normals, &Normals, N);


				if (Triangles[number_of_triangles].Texture < 0)
				{
					fully_textured = false;
				}

				number_of_triangles++;

			}
		}
		else

			//for smooth triangles
			//copy the normals
		{

			x0 = mesh->m_rend.pNormals[v0*3+0];y0 = mesh->m_rend.pNormals[v0*3+1];z0 = mesh->m_rend.pNormals[v0*3+2];
			x1 = mesh->m_rend.pNormals[v1*3+0];y1 = mesh->m_rend.pNormals[v1*3+1];z1 = mesh->m_rend.pNormals[v1*3+2];
			x2 = mesh->m_rend.pNormals[v2*3+0];y2 = mesh->m_rend.pNormals[v2*3+1];z2 = mesh->m_rend.pNormals[v2*3+2];
			Make_Vector(N1,x0,y0,z0);
			Make_Vector(N2,x1,y1,z1);
			Make_Vector(N3,x2,y2,z2);

			if(fabs(N1[X])<EPSILON && fabs(N1[Y])<EPSILON && fabs(N1[Z])<EPSILON)
			{
				N1[X] = 1.0;  // make it nonzero
				//	if(!foundZeroNormal)
				//		Warning(0,"Normal vector in mesh2 cannot be zero - changing it to <1,0,0>.");
				//	foundZeroNormal = true;
			}
			if(fabs(N2[X])<EPSILON && fabs(N2[Y])<EPSILON && fabs(N2[Z])<EPSILON)
			{
				N2[X] = 1.0;  // make it nonzero
				//  if(!foundZeroNormal)
				//    Warning(0,"Normal vector in mesh2 cannot be zero - changing it to <1,0,0>.");
				//  foundZeroNormal = true;
			}
			if(fabs(N3[X])<EPSILON && fabs(N3[Y])<EPSILON && fabs(N3[Z])<EPSILON)
			{
				N3[X] = 1.0;  // make it nonzero
				//   if(!foundZeroNormal)
				//     Warning(0,"Normal vector in mesh2 cannot be zero - changing it to <1,0,0>.");
				//   foundZeroNormal = true;
			}

			VLength(l1, N1);
			VLength(l2, N2);
			VLength(l3, N3);

			if ((l1 != 0.0) && (l2 != 0.0) && (l3 != 0.0) && (!Mesh_Degenerate(P1, P2, P3)))
			{
				if (number_of_triangles >= max_triangles)
				{
					if (max_triangles >= INT_MAX/2)
					{
						Error("Too many triangles in triangle mesh.");
					}

					max_triangles *= 2;

					Triangles = (MESH_TRIANGLE *)POV_REALLOC(Triangles, max_triangles*sizeof(MESH_TRIANGLE), "triangle triangle mesh data");
				}

				VInverseScaleEq(N1, l1);
				VInverseScaleEq(N2, l2);
				VInverseScaleEq(N3, l3);

				/* Init triangle. */

				Init_Mesh_Triangle(&Triangles[number_of_triangles]);

				Triangles[number_of_triangles].P1 = Mesh_Hash_Vertex(&number_of_vertices, &max_vertices, &Vertices, P1);
				Triangles[number_of_triangles].P2 = Mesh_Hash_Vertex(&number_of_vertices, &max_vertices, &Vertices, P2);
				Triangles[number_of_triangles].P3 = Mesh_Hash_Vertex(&number_of_vertices, &max_vertices, &Vertices, P3);

				/* Check for equal normals. */

				VSub(D1, N1, N2);
				VSub(D2, N1, N3);

				VDot(l1, D1, D1);
				VDot(l2, D2, D2);

				/* NK 1998 */
			/*	Parse_Three_UVCoords(UV1,UV2,UV3);
				Triangles[number_of_triangles].UV1 = Mesh_Hash_UV(&number_of_uvcoords, &max_uvcoords, &UVCoords,UV1);
				Triangles[number_of_triangles].UV2 = Mesh_Hash_UV(&number_of_uvcoords, &max_uvcoords, &UVCoords,UV2);
				Triangles[number_of_triangles].UV3 = Mesh_Hash_UV(&number_of_uvcoords, &max_uvcoords, &UVCoords,UV3);
*/
				/* read possibly three instead of only one texture */
				/* read these before compute!!! */
			/*	t2 = t3 = NULL;
				Triangles[number_of_triangles].Texture = Mesh_Hash_Texture(&number_of_textures, &max_textures, &Textures, Parse_Mesh_Texture(&t2,&t3));
				if (t2) Triangles[number_of_triangles].Texture2 = Mesh_Hash_Texture(&number_of_textures, &max_textures, &Textures, t2);
				if (t3) Triangles[number_of_triangles].Texture3 = Mesh_Hash_Texture(&number_of_textures, &max_textures, &Textures, t3);
				if (t2 || t3) Triangles[number_of_triangles].ThreeTex = true;
*/
				if ((fabs(l1) > EPSILON) || (fabs(l2) > EPSILON))
				{
					/* Smooth triangle. */

					Triangles[number_of_triangles].N1 = Mesh_Hash_Normal(&number_of_normals, &max_normals, &Normals, N1);
					Triangles[number_of_triangles].N2 = Mesh_Hash_Normal(&number_of_normals, &max_normals, &Normals, N2);
					Triangles[number_of_triangles].N3 = Mesh_Hash_Normal(&number_of_normals, &max_normals, &Normals, N3);

					Compute_Mesh_Triangle(&Triangles[number_of_triangles], true, P1, P2, P3, N);
				}
				else
				{
					/* Flat triangle. */

					Compute_Mesh_Triangle(&Triangles[number_of_triangles], false, P1, P2, P3, N);
				}

				Triangles[number_of_triangles].Normal_Ind = Mesh_Hash_Normal(&number_of_normals, &max_normals, &Normals, N);

				if (Triangles[number_of_triangles].Texture < 0)
				{
					fully_textured = false;
				}

				number_of_triangles++;
			}
		}

	}//endfor

	// Destroy hash tables. 

	Destroy_Mesh_Hash_Tables();

	// If there are no triangles something went wrong. 

	if (number_of_triangles == 0)
	{
		Error("No triangles in triangle mesh.");
	}

	// Init triangle mesh data. 

	object->Data = (MESH_DATA *)POV_MALLOC(sizeof(MESH_DATA), "triangle mesh data");


	object->Data->References = 1;

	object->Data->Tree = NULL;
	// NK 1998 

	if( (fabs(Inside_Vect[X]) < EPSILON) &&  (fabs(Inside_Vect[Y]) < EPSILON) &&  (fabs(Inside_Vect[Z]) < EPSILON))
		object->has_inside_vector=false;
	else
	{
		VNormalize(object->Data->Inside_Vect, Inside_Vect);
		object->has_inside_vector=true;
	}

	object->Data->Normals   = NULL;
	object->Data->UVCoords = NULL;//aizm
	// [LSK] Removed "Data->" 
	object->Textures  = NULL;

	object->Data->Triangles = NULL;
	object->Data->Vertices  = NULL;

	// Allocate memory for normals, textures, triangles and vertices. 

	object->Number_Of_Textures = number_of_textures;

	object->Data->Number_Of_Normals = number_of_normals;

	object->Data->Number_Of_Triangles = number_of_triangles;

	object->Data->Number_Of_Vertices = number_of_vertices;

	object->Data->Normals = (SNGL_VECT *)POV_MALLOC(number_of_normals*sizeof(SNGL_VECT), "triangle mesh data");

	if (number_of_textures)
	{
		Set_Flag(object, MULTITEXTURE_FLAG);

		// [LSK] Removed "Data->" 
		object->Textures = (TEXTURE **)POV_MALLOC(number_of_textures*sizeof(TEXTURE *), "triangle mesh data");
	}

	object->Data->Triangles = (MESH_TRIANGLE *)POV_MALLOC(number_of_triangles*sizeof(MESH_TRIANGLE), "triangle mesh data");

	object->Data->Vertices = (SNGL_VECT *)POV_MALLOC(number_of_vertices*sizeof(SNGL_VECT), "triangle mesh data");

	// Copy normals, textures, triangles and vertices into mesh. 

	for (int i = 0; i < number_of_normals; i++)
	{
		Assign_SNGL_Vect(object->Data->Normals[i], Normals[i]);
	}

	/*	for (i = 0; i < number_of_textures; i++)
	{
	// [LSK] Removed "Data->" 
	object->Textures[i] = Copy_Textures(Textures[i]);
	Post_Textures(object->Textures[i]);

	// now free the texture, in order to decrement the reference count 
	Destroy_Textures(Textures[i]);
	}

	if (fully_textured)
	{
	object->Type |= TEXTURED_OBJECT;
	}*/

	for (i = 0; i < number_of_triangles; i++)
	{
		object->Data->Triangles[i] = Triangles[i];
	}

	for (i = 0; i < number_of_vertices; i++)
	{
		Assign_SNGL_Vect(object->Data->Vertices[i], Vertices[i]);
	}

	// NK 1998 
	// do the four steps above, but for UV coordinates
	/*object->Data->UVCoords  = NULL;
	object->Data->Number_Of_UVCoords = number_of_uvcoords;
	object->Data->UVCoords = (UV_VECT *)POV_MALLOC(number_of_uvcoords*sizeof(UV_VECT), "triangle mesh data");
	for (i = 0; i < number_of_uvcoords; i++)
	{
	Assign_UV_Vect(object->Data->UVCoords[i], UVCoords[i]);
	}
	POV_FREE(UVCoords);
	*/
	// NK ---- 

	// Free temporary memory. 

	POV_FREE(Normals);
	POV_FREE(Textures);
	POV_FREE(Triangles);
	POV_FREE(Vertices);


	///transformations
	if(object->Trans==NULL)
		object->Trans = Create_Transform();
	TRANSFORM *result=object->Trans;
	//	register int i;
	Matrix4 mat = mesh->Bounding.GetWorldTransform();
	for (i = 0; i < 4; i++)
	{
		(result->matrix)[i][0] = mat.m[i][0];//29-jan  //((Matrix4)(Bounding.Matrix))
		(result->matrix)[i][1] = mat.m[i][1];
		(result->matrix)[i][2] = mat.m[i][2];
		(result->matrix)[i][3] = mat.m[i][3];
	}
	MInvers(result->inverse, result->matrix);
	// Create bounding box. 

	Compute_Mesh_BBox(object);

	// Parse object modifiers. 

	//	Parse_Object_Mods((OBJECT *)object);

	// Create bounding box tree. 

	Build_Mesh_BBox_Tree(object);

}
OBJECT* MeshObj::Generate()
{
	return ISceneObject ::Generate ();
}
///////////////////////////////////*camera*//////////////////////////////
CameraObj::CameraObj(bool bCreateMesh,CString CameraName)
//:Camera(Name)
:ISceneObject ()
{
	Blur_Samples=Aperture=Confidence=Variance=0;
	if(bCreateMesh)
	{
	pRenderable =new CameraMesh();
	camera=new Camera (pRenderable->Name);
	((CameraMesh*)pRenderable)->m_UpdateCamera =camera;
	}
	else
	{
	camera=new Camera (CameraName);
	}
	ObjectType =OBJ_CAMERA;
}
CameraObj::~CameraObj()
{
delete camera;
}
Camera *CameraObj::GetCamera()
{
	return camera;//((CameraMesh *)pRenderable)->m_UpdateCamera;
}
void CameraObj::UpdateObject()
{

}
CAMERA* CameraObj::GenerateCamera()
{
	///////////////////////////////////
	DBL k1, k2, k3;
	DBL Direction_Length = 1.0, Up_Length, Right_Length, Handedness;
	VECTOR tempv;
	//	TRANSFORM Local_Trans;
	//	CAMERA *New;
	//	bool only_mods = false;
	/////////////////////////////////////////
	//#defing New
	double camlocation[3]={camera->m_Location.x,camera->m_Location.y,camera->m_Location.z};//{0,1,-4};
	//	double camdir[3]={0,0,1.6542};
	Vector3 look=camera->m_Location+camera->m_Direction ;

	double camdlook[3]={look.x,look.y,look.z};//{0,2,0};
	//Compute_Translation_Transform
		double up[3]={0,0,1};

	//setting properties
	//	ThisCamera=Create_Camera();
	CAMERA *ThisCamera=new CAMERA();
	ThisCamera->Type=PERSPECTIVE_CAMERA;
	if(camera->mProjType==PT_PERSPECTIVE)
	{
		ThisCamera->Angle= this->camera->m_UpFovDegrees*2;

	}
	else if(camera->mProjType==PT_ORTHOGRAPHIC)
	{
	//	ThisCamera->Type=ORTHOGRAPHIC_CAMERA;
		ThisCamera->Angle= 5;

	}
	Make_Vector (ThisCamera->Right,(float)-4/3,0,0);
VNormalize(ThisCamera->Direction, ThisCamera->Direction);
	VLength (Right_Length, ThisCamera->Right);
	Direction_Length = Right_Length / tan(ThisCamera->Angle * M_PI_360)/2.0;
	VScaleEq(ThisCamera->Direction, Direction_Length);
	///	Assign_Vector(ThisCamera->Direction,camdir);
	Assign_Vector(ThisCamera->Location,camlocation);
		Assign_Vector(ThisCamera->Up,up);
		Assign_Vector(ThisCamera->Sky ,up);


	///setting up look at
	VLength (Direction_Length, ThisCamera->Direction);
	VLength (Up_Length,        ThisCamera->Up);
	VLength (Right_Length,     ThisCamera->Right);
	VCross  (tempv,            ThisCamera->Up, ThisCamera->Direction);
	VDot    (Handedness,       tempv,   ThisCamera->Right);

	//	Parse_Vector (ThisCamera->Direction);
	Assign_Vector(ThisCamera->Direction,camdlook);

	Assign_Vector(ThisCamera->Look_At, ThisCamera->Direction);

	VSub          (ThisCamera->Direction, ThisCamera->Direction, ThisCamera->Location);

	// Check for zero length direction vector.
	if (VSumSqr(ThisCamera->Direction) < EPSILON)
		Error("Camera location and look_at point must be different.");

	VNormalize (ThisCamera->Direction, ThisCamera->Direction);

	// Save Right vector
	Assign_Vector (tempv, ThisCamera->Right);

	VCross        (ThisCamera->Right, ThisCamera->Sky, ThisCamera->Direction);

	// Avoid DOMAIN error (from Terry Kanakis)
	if((fabs(ThisCamera->Right[X]) < EPSILON) &&
		(fabs(ThisCamera->Right[Y]) < EPSILON) &&
		(fabs(ThisCamera->Right[Z]) < EPSILON))
	{
		// Restore Right vector
		Assign_Vector (ThisCamera->Right, tempv);
	}

	VNormalize (ThisCamera->Right,     ThisCamera->Right);
	VCross     (ThisCamera->Up,        ThisCamera->Direction, ThisCamera->Right);
	VScale     (ThisCamera->Direction, ThisCamera->Direction, Direction_Length);

	if (Handedness > 0.0)
		VScaleEq (ThisCamera->Right, Right_Length)
	else
	VScaleEq (ThisCamera->Right, -Right_Length);

	VScaleEq(ThisCamera->Up, Up_Length);
	


	//focal blur data			
/*	ThisCamera->Blur_Samples =30;//	Blur_Samples;
	ThisCamera->Aperture=	.4;//	Aperture;
	ThisCamera->Confidence =	Confidence;
	ThisCamera->Variance =		Variance;
	Make_Vector(ThisCamera->Focal_Point,Focal_Point.x,Focal_Point.y,Focal_Point.z);
*/
	// apply "focal_point"
	Assign_Vector(tempv, ThisCamera->Focal_Point);
	VSubEq(tempv, ThisCamera->Location);
	VLength (ThisCamera->Focal_Distance, tempv);

	////post
	// Make sure the focal distance hasn't been explicitly given
	if (ThisCamera->Focal_Distance < 0.0)
		ThisCamera->Focal_Distance = Direction_Length;
	if (ThisCamera->Focal_Distance == 0.0)
		ThisCamera->Focal_Distance = 1.0;

	// Print a warning message if vectors are not perpendicular. [DB 10/94]
	VDot(k1, ThisCamera->Right, ThisCamera->Up);
	VDot(k2, ThisCamera->Right, ThisCamera->Direction);
	VDot(k3, ThisCamera->Up, ThisCamera->Direction);

	if ((fabs(k1) > EPSILON) || (fabs(k2) > EPSILON) || (fabs(k3) > EPSILON))
	{
		Warning(0, "Camera vectors are not perpendicular.\n"
			"Making look_at the last statement may help.");
	}




	return ThisCamera;
}

