#if !defined(AFX_MAPENTRY_H__07316D54_5336_4EE9_9A2B_1B4B3EC07F78__INCLUDED_)
#define AFX_MAPENTRY_H__07316D54_5336_4EE9_9A2B_1B4B3EC07F78__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MapEntry.h : header file
//
#include "AccessDialog.h"

/////////////////////////////////////////////////////////////////////////////
// CMapEntry dialog

class CMapEntry : public CAccessDialog//CDialog
{
// Construction
public:
	DECLARE_SERIAL(CMapEntry)
	CMapEntry(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMapEntry)
	enum { IDD = IDD_MAP_ENTRY };
	double	m_pos;
	//}}AFX_DATA

virtual void Serialize(CArchive &ar);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMapEntry)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMapEntry)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAPENTRY_H__07316D54_5336_4EE9_9A2B_1B4B3EC07F78__INCLUDED_)
