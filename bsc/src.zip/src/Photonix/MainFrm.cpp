// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Photonix.h"

#include "MainFrm.h"
#include "SplashScreenEx.h"
#include "photonixview.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_VIEW_AUTOMATICSPLIT, OnAutomaticsplit)
	ON_WM_SIZE()
	ON_COMMAND(ID_VIEW_ALIGNVIEW, OnViewAlignview)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_bSplitterCreated=false;
	m_Commandpanel.m_hWnd=0;
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	// Demo 1, the simplest use of the class
	CSplashScreenEx *pSplash=new CSplashScreenEx();
	pSplash->Create(this,NULL,3000,CSS_FADE |CSS_HIDEONCLICK| CSS_CENTERSCREEN | CSS_SHADOW);
	pSplash->SetBitmap(IDB_SPLASH,255,0,255);
	pSplash->Show();


	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
/*	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
*/
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
/*if (!m_AnimationDialogBar.Create(this, IDD_DIALOGBAR,
		CBRS_TOP|CBRS_TOOLTIPS|CBRS_FLYBY, IDD_DIALOGBAR))
	{
		TRACE0("Failed to create DlgBar\n");
		return -1;      // fail to create
	}*/
if (!m_CreateToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_CreateToolBar.LoadToolBar(IDR_CREATE_TOOLBAR ))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	if (!m_Commandpanel.Create(_T("Options"),WS_CHILD | WS_VISIBLE, this, 0x996))//
    {
        TRACE0("Failed to create OptionsControl\n");
        return -1;      
	}
//m_Commandpanel.SetWindowPos (0,0,0,200,200,0);
//m_Commandpanel.CalcDynamicLayout (
	m_Commandpanel.SetBarStyle(m_Commandpanel.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	

{
	// Set up hot bar image lists.
	CImageList	imageList;
	CBitmap		bitmap;
	// Create and set the normal toolbar image list.
	bitmap.LoadBitmap(IDB_CREATE_TOOLBAR );
	imageList.Create(32, 32, ILC_COLORDDB|ILC_MASK, 13, 1);
	imageList.Add(&bitmap, RGB(197,197,197));
	m_CreateToolBar.SendMessage(TB_SETIMAGELIST, 0, (LPARAM)imageList.m_hImageList);
	imageList.Detach();
	bitmap.Detach();

	// Create and set the hot toolbar image list.
	bitmap.LoadBitmap(IDB_CREATE_TOOLBAR);
	imageList.Create(32, 32, ILC_COLORDDB|ILC_MASK, 13, 1);
	imageList.Add(&bitmap, RGB(197,197,197));
	m_CreateToolBar.SendMessage(TB_SETHOTIMAGELIST, 0, (LPARAM)imageList.m_hImageList);
	imageList.Detach();
	bitmap.Detach();
}


// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	EnableDocking(CBRS_ALIGN_ANY);
//	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
//	DockControlBar(&m_wndToolBar);
/*	m_AnimationDialogBar.EnableDocking(CBRS_ALIGN_BOTTOM);
	DockControlBar(&m_AnimationDialogBar);
*/
	m_CreateToolBar.EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_CreateToolBar);

	m_Commandpanel.EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_Commandpanel,AFX_IDW_DOCKBAR_RIGHT);

//	sProfile = _T("Photonix");
//	LoadBars();
	//	m_sizeHorz.cx=pApp->GetProfileInt(szSection, "sizeHorz.cx",200 );
//	m_sizeHorz.cy=pApp->GetProfileInt(szSection, "sizeHorz.cy",100 );
//	m_sizeVert.cx=pApp->GetProfileInt(szSection, "sizeVert.cx",200 );
//	m_sizeVert.cy=pApp->GetProfileInt(szSection, "sizeVert.cy",100 );
//m_Commandpanel.m_sizeVert.cx=200;

	return 0;
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT /*lpcs*/,
								CCreateContext* pContext)
{
	BOOL Ret=m_wndSplitter.CreateStatic (this,
		2, 2,               // TODO: adjust the number of rows, columns
		//	CSize(10, 10),      // TODO: adjust the minimum pane size
		//	pContext,
		WS_CHILD | WS_VISIBLE);// |SPLS_DYNAMIC_SPLIT
	m_wndSplitter.CreateView (0,0,RUNTIME_CLASS(CPhotonixView),CSize(10, 10),	pContext);
	m_wndSplitter.CreateView (0,1,RUNTIME_CLASS(CPhotonixView),CSize(10, 10),	pContext);
	m_wndSplitter.CreateView (1,0,RUNTIME_CLASS(CPhotonixView),CSize(10, 10),	pContext);
	m_wndSplitter.CreateView (1,1,RUNTIME_CLASS(CPhotonixView),CSize(10, 10),	pContext);
CPhotonixView *cview=(CPhotonixView *) m_wndSplitter.GetPane(0,0);
cview->InitCameraName="Top";
cview->mInitialSceneDetail=SDL_WIREFRAME;
	cview=(CPhotonixView *) m_wndSplitter.GetPane(0,1);
cview->InitCameraName="Front";
cview->mInitialSceneDetail=SDL_WIREFRAME;
cview=(CPhotonixView *) m_wndSplitter.GetPane(1,0);
cview->InitCameraName="Left";
cview->mInitialSceneDetail=SDL_WIREFRAME;
cview=(CPhotonixView *) m_wndSplitter.GetPane(1,1);
cview->InitCameraName="Prespective";
cview->mInitialSceneDetail=SDL_SOLID;
	/*	CPhotonixDoc *pDoc=(CPhotonixDoc *)pContext->m_pCurrentDoc ;
	CPhotonixView *cview=(CPhotonixView *) m_wndSplitter.GetPane(0,0);
	cview->RenderWnd .SetViewportCamera ((Camera*)pDoc->MainApp ->mCameras ["Top"]);
	cview=(CPhotonixView *) m_wndSplitter.GetPane(0,1);
	cview->RenderWnd .SetViewportCamera ((Camera*)pDoc->MainApp ->mCameras ["Front"]);
	cview=(CPhotonixView *) m_wndSplitter.GetPane(1,0);
	cview->RenderWnd .SetViewportCamera ((Camera*)pDoc->MainApp ->mCameras ["Left"]);
	cview=(CPhotonixView *) m_wndSplitter.GetPane(1,1);
	cview->RenderWnd .SetViewportCamera ((Camera*)pDoc->MainApp ->mCameras ["Prespective"]);
*/

CPhotonixDoc* pDoc=(CPhotonixDoc*)pContext->m_pCurrentDoc ;
pDoc->mainfrm=this;
		CWnd* mwnd=this;
		CPhotonixDoc::RenderDlg.m_Window.SetPictureRect(CRect (0,0,200 ,200));
		CPhotonixDoc::RenderDlg.Create (IDD_DIALOG1,mwnd);
		CPhotonixDoc::TextureEditor.Create (IDD_TEXMAKER_DIALOG,mwnd);
		pDoc->m_ObjectsTree.Create (IDD_OBJTREE,mwnd);
		pDoc->m_ObjectsTree.pDoc=pDoc;
		//finished creating dialogs
	//	this->GetDocument ()->DialogsCreated=true;
	/*	CMainFrame * mainfrm=this;
		CSliderCtrl * pCtrl=(CSliderCtrl *)mainfrm->m_AnimationDialogBar .GetDlgItem (IDC_KEYFRAMES);
		pCtrl->SetRange (0,100);
*/
	m_bSplitterCreated=true;
	//	m_wndSplitter.DoAutomaticSplit();
	//I SHOULD USE static splitter and use CreateView for every view

	return Ret;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnAutomaticsplit()
{
m_wndSplitter.DoAutomaticSplit();

}

void CMainFrame::OnSize(UINT nType, int cx, int cy)
{
	CFrameWnd::OnSize(nType, cx, cy);
	//if(this->m_hWnd !=NULL)
	//	m_wndSplitter.DoKeyboardSplit();
	// TODO: Add your message handler code here
	if( m_bSplitterCreated )  // m_bSplitterCreated set in OnCreateClient
	{	

		AlignViews();
	}

}
void CMainFrame::AlignViews()
{
	CRect rect;
	m_wndSplitter.GetClientRect( &rect );
		m_wndSplitter.SetRowInfo(0, (rect.Height()/2)-5, 0);
		m_wndSplitter.SetColumnInfo(0, (rect.Width()/2)-5, 0);
	//	m_wndSplitter.SetRowInfo(1, rect.Height()/2, 10);
	//	m_wndSplitter.SetColumnInfo(1, rect.Width()/2, 10);

		m_wndSplitter.RecalcLayout();
}
void CMainFrame::OnViewAlignview()
{
	AlignViews();
}
