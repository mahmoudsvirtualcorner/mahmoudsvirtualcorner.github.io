#if !defined(AFX_RADIOSITYOPTIONS_H__47CFACCF_35F8_494B_95F0_9B6739E86C9D__INCLUDED_)
#define AFX_RADIOSITYOPTIONS_H__47CFACCF_35F8_494B_95F0_9B6739E86C9D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RadiosityOptions.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRadiosityOptions dialog

class CRadiosityOptions : public CDialog
{
// Construction
public:
	CRadiosityOptions(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRadiosityOptions)
	enum { IDD = IDD_RADIOSITY };
	float	m_brightness;
	UINT	m_count;
	float	m_dist_max;
	float	m_err_bound;
	float	m_gray_threshold;
	float	m_lowerror_factor;
	float	m_min_reuse;
	UINT	m_nearest_count;
	UINT	m_rec_limit;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRadiosityOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRadiosityOptions)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RADIOSITYOPTIONS_H__47CFACCF_35F8_494B_95F0_9B6739E86C9D__INCLUDED_)
